package com.wickedsik.personalworlds.mixin;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.chat.ChatCommandHandler;
import com.wickedsik.personalworlds.network.ModNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_5836;
import net.minecraft.class_7470;
import net.minecraft.class_7595;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin для перехвата чат-сообщений.
 * Используется для обработки команд Prunus и Malus без использования /.
 */
@Mixin(class_3222.class_7648.class) // ServerGamePacketListenerImpl
public class ChatMixin {

    /**
     * Перехват обработки чата.
     * Вызывается когда игрок отправляет сообщение в чат.
     */
    @Inject(method = "method_45064", at = @At("HEAD"), cancellable = true)
    private void onChatMessage(String message, class_7470.class_7648 acknowledgement, CallbackInfo ci) {
        // Проверяем, является ли сообщение командой
        if (ChatCommandHandler.isCommand(message)) {
            PersonalWorldsMod.LOGGER.info("Intercepted chat command: {}", message);

            // Отменяем стандартную обработку (сообщение не отправляется в чат)
            ci.cancel();

            // Обрабатываем команду
            String command = ChatCommandHandler.getCommand(message);
            if ("Prunus".equals(command)) {
                // Получаем игрока из контекста и выполняем команду
                // Это упрощённая версия, в реальности нужно получить ссылку на игрока
                PersonalWorldsMod.LOGGER.info("Executing Prunus command");
            } else if ("Malus".equals(command)) {
                PersonalWorldsMod.LOGGER.info("Executing Malus command");
            }
        }
    }
}
