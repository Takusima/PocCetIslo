package com.wickedsik.personalworlds.command;

import net.minecraft.class_2168;
import net.minecraft.class_2561;

public record CommandResult(boolean success, class_2561 message, boolean broadcast) {
   public static final int SUCCESS = 1;
   public static final int FAILURE = 0;

   public static CommandResult success(class_2561 message) {
      return new CommandResult(true, message, false);
   }

   public static CommandResult successBroadcast(class_2561 message) {
      return new CommandResult(true, message, true);
   }

   public static CommandResult error(class_2561 message) {
      return new CommandResult(false, message, false);
   }

   public static CommandResult silent() {
      return new CommandResult(true, (class_2561)null, false);
   }

   public int toCommandReturn() {
      return this.success ? 1 : 0;
   }

   public int applyTo(class_2168 source) {
      if (this.message != null) {
         if (this.success) {
            class_2561 msg = this.message;
            source.method_9226(() -> msg, this.broadcast);
         } else {
            source.method_9213(this.message);
         }
      }

      return this.toCommandReturn();
   }
}
