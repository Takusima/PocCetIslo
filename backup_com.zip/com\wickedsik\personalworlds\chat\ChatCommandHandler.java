package com.wickedsik.personalworlds.chat;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.network.ModNetworking;
import com.wickedsik.personalworlds.network.NetworkHandler;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Обработчик чат-команд Prunus и Malus.
 *
 * Перехватывает текстовые сообщения игрока в чате и проверяет,
 * соответствуют ли они командам:
 * - "Prunus" - телепортация в карманное измерение
 * - "Malus" - телепортация обратно в Overworld
 *
 * Стоимость команд:
 * - 2 единицы опыта (levels)
 * - 3 единицы голода (food)
 */
public final class ChatCommandHandler {

    // Ключевые слова команд
    private static final String COMMAND_PRUNUS = "Prunus";
    private static final String COMMAND_MALUS = "Malus";

    private ChatCommandHandler() {
        // Utility class
    }

    /**
     * Регистрация обработчика чат-сообщений.
     */
    public static void register() {
        PersonalWorldsMod.LOGGER.info("Registering chat command handler...");

        // Перехват сообщений в чате
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String content = message.getContent().getString();
            handleChatMessage(sender, content);
        });

        PersonalWorldsMod.LOGGER.info("Chat command handler registered");
    }

    /**
     * Обработка входящего сообщения в чате.
     *
     * @param player Отправитель сообщения
     * @param message Текст сообщения
     */
    private static void handleChatMessage(class_3222 player, String message) {
        // Убираем лишние пробелы
        String trimmedMessage = message.trim();

        // Проверка команды Prunus
        if (trimmedMessage.equalsIgnoreCase(COMMAND_PRUNUS)) {
            PersonalWorldsMod.LOGGER.info("Player {} used Prunus command via chat", player.method_5477().getString());

            // Отменяем отправку сообщения в чат
            // (сообщение не должно быть видимо другим игрокам)

            // Отправляем команду на сервер через сетевой пакет
            class_2540 buf = ModNetworking.createBuf();
            NetworkHandler.handlePrunusCommand(player);

            return;
        }

        // Проверка команды Malus
        if (trimmedMessage.equalsIgnoreCase(COMMAND_MALUS)) {
            PersonalWorldsMod.LOGGER.info("Player {} used Malus command via chat", player.method_5477().getString());

            // Отправляем команду на сервер через сетевой пакет
            class_2540 buf = ModNetworking.createBuf();
            NetworkHandler.handleMalusCommand(player);

            return;
        }
    }

    /**
     * Альтернативный метод регистрации через Mixin.
     * Используется если нужно полностью перехватить сообщение.
     */
    public static void registerViaMixin() {
        PersonalWorldsMod.LOGGER.info("Chat command handler registered via Mixin");
    }

    /**
     * Проверка, является ли сообщение командой.
     *
     * @param message Текст сообщения
     * @return true если это команда Prunus или Malus
     */
    public static boolean isCommand(String message) {
        if (message == null || message.isEmpty()) {
            return false;
        }
        String trimmed = message.trim();
        return trimmed.equalsIgnoreCase(COMMAND_PRUNUS) || trimmed.equalsIgnoreCase(COMMAND_MALUS);
    }

    /**
     * Получение команды из сообщения.
     *
     * @param message Текст сообщения
     * @return Имя команды или null
     */
    public static String getCommand(String message) {
        if (message == null || message.isEmpty()) {
            return null;
        }
        String trimmed = message.trim();
        if (trimmed.equalsIgnoreCase(COMMAND_PRUNUS)) {
            return COMMAND_PRUNUS;
        }
        if (trimmed.equalsIgnoreCase(COMMAND_MALUS)) {
            return COMMAND_MALUS;
        }
        return null;
    }
}
