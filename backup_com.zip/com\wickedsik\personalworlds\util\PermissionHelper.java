package com.wickedsik.personalworlds.util;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.CommandCompat;
import java.util.function.Predicate;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;

public final class PermissionHelper {
   public static final String ADMIN_LIST = "pocketislands.admin.list";
   public static final String ADMIN_INFO = "pocketislands.admin.info";
   public static final String ADMIN_DELETE = "pocketislands.admin.delete";
   public static final String ADMIN_TELEPORT = "pocketislands.admin.teleport";
   public static final String ADMIN_RELOAD = "pocketislands.admin.reload";
   public static final String PLAYER_CREATE = "pocketislands.player.create";
   public static final String PLAYER_INVITE = "pocketislands.player.invite";
   public static final String PLAYER_VISIT = "pocketislands.player.visit";
   public static final int DEFAULT_ADMIN_LIST_LEVEL = 2;
   public static final int DEFAULT_ADMIN_INFO_LEVEL = 2;
   public static final int DEFAULT_ADMIN_DELETE_LEVEL = 4;
   public static final int DEFAULT_ADMIN_TELEPORT_LEVEL = 2;
   public static final int DEFAULT_ADMIN_RELOAD_LEVEL = 3;
   public static final int DEFAULT_PLAYER_CREATE_LEVEL = 0;
   public static final int DEFAULT_PLAYER_INVITE_LEVEL = 0;
   public static final int DEFAULT_PLAYER_VISIT_LEVEL = 0;
   private static Boolean permissionsApiAvailable = null;

   public static boolean check(class_2168 source, String permission, int fallbackLevel) {
      if (isPermissionsApiAvailable()) {
         try {
            return Permissions.check(source, permission, fallbackLevel);
         } catch (Exception e) {
            PersonalWorldsMod.LOGGER.debug("Permissions API check failed, falling back to OP level", e);
            return CommandCompat.hasPermissionLevel(source, fallbackLevel);
         }
      } else {
         return CommandCompat.hasPermissionLevel(source, fallbackLevel);
      }
   }

   public static Predicate<class_2168> require(String permission, int fallbackLevel) {
      return (source) -> check(source, permission, fallbackLevel);
   }

   public static boolean canAdminList(class_2168 source) {
      return check(source, "pocketislands.admin.list", 2);
   }

   public static boolean canAdminInfo(class_2168 source) {
      return check(source, "pocketislands.admin.info", 2);
   }

   public static boolean canAdminDelete(class_2168 source) {
      return check(source, "pocketislands.admin.delete", 4);
   }

   public static boolean canAdminTeleport(class_2168 source) {
      return check(source, "pocketislands.admin.teleport", 2);
   }

   public static boolean canAdminReload(class_2168 source) {
      return check(source, "pocketislands.admin.reload", 3);
   }

   private static boolean isPermissionsApiAvailable() {
      if (permissionsApiAvailable == null) {
         try {
            Class.forName("me.lucko.fabric.api.permissions.v0.Permissions");
            permissionsApiAvailable = true;
            PersonalWorldsMod.LOGGER.info("fabric-permissions-api detected, using permission nodes");
         } catch (ClassNotFoundException var1) {
            permissionsApiAvailable = false;
            PersonalWorldsMod.LOGGER.info("fabric-permissions-api not found, using vanilla OP levels");
         }
      }

      return permissionsApiAvailable;
   }

   public static void resetCache() {
      permissionsApiAvailable = null;
   }

   private PermissionHelper() {
   }
}
