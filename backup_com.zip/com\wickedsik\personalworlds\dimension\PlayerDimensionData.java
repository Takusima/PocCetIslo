package com.wickedsik.personalworlds.dimension;

import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.compat.NbtCompat;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public record PlayerDimensionData(UUID ownerUuid, String ownerName, class_2960 dimensionId, long createdAt, class_2338 spawnPoint, WorldGenType generatorType, int portalTypeIndex) {
   public class_2487 toNbt() {
      class_2487 nbt = new class_2487();
      NbtCompat.putUuid(nbt, "OwnerUuid", this.ownerUuid);
      nbt.method_10582("OwnerName", this.ownerName);
      nbt.method_10582("DimensionId", this.dimensionId.toString());
      nbt.method_10544("CreatedAt", this.createdAt);
      nbt.method_10569("SpawnX", this.spawnPoint.method_10263());
      nbt.method_10569("SpawnY", this.spawnPoint.method_10264());
      nbt.method_10569("SpawnZ", this.spawnPoint.method_10260());
      nbt.method_10582("GeneratorType", this.generatorType.name());
      nbt.method_10569("PortalTypeIndex", this.portalTypeIndex);
      return nbt;
   }

   public static PlayerDimensionData fromNbt(class_2487 nbt) {
      int portalTypeIndex = NbtCompat.getInt(nbt, "PortalTypeIndex", 0);
      return new PlayerDimensionData(NbtCompat.getUuid(nbt, "OwnerUuid"), NbtCompat.getString(nbt, "OwnerName", "Unknown"), IdentifierCompat.fromNbtString(NbtCompat.getString(nbt, "DimensionId", "")), NbtCompat.getLong(nbt, "CreatedAt", 0L), new class_2338(NbtCompat.getInt(nbt, "SpawnX", 0), NbtCompat.getInt(nbt, "SpawnY", 64), NbtCompat.getInt(nbt, "SpawnZ", 0)), WorldGenType.fromString(NbtCompat.getString(nbt, "GeneratorType", "VOID")), portalTypeIndex);
   }
}
