package com.wickedsik.personalworlds.registry;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItems {
   private static class_1792[] cachedActivationItems = null;

   public static void register() {
      PersonalWorldsMod.LOGGER.info("Registered items");
   }

   public static class_1792 getActivationItem(int portalTypeIndex) {
      if (cachedActivationItems == null) {
         List<ModConfig.PortalConfig> configs = ModConfig.get().portalTypes;
         cachedActivationItems = new class_1792[configs.size()];

         for(int i = 0; i < configs.size(); ++i) {
            String itemId = ((ModConfig.PortalConfig)configs.get(i)).activationItem;
            class_2960 id = IdentifierCompat.tryParse(itemId);
            class_1792 item = id != null ? (class_1792)class_7923.field_41178.method_10223(id) : class_1802.field_8162;
            if (item == class_1802.field_8162 && !itemId.equals("minecraft:air")) {
               PersonalWorldsMod.LOGGER.warn("Invalid activation item '{}' for portal type {}, using emerald", itemId, i);
               item = class_1802.field_8687;
            }

            cachedActivationItems[i] = item;
            PersonalWorldsMod.LOGGER.debug("Portal type {} activation item set to: {}", i, class_7923.field_41178.method_10221(item));
         }
      }

      if (portalTypeIndex >= 0 && portalTypeIndex < cachedActivationItems.length) {
         return cachedActivationItems[portalTypeIndex];
      } else {
         PersonalWorldsMod.LOGGER.warn("Portal type index {} out of bounds (0-{}), using 0", portalTypeIndex, cachedActivationItems.length - 1);
         return cachedActivationItems[0];
      }
   }

   public static void clearCache() {
      cachedActivationItems = null;
      PersonalWorldsMod.LOGGER.debug("Item cache cleared");
   }
}
