package com.wickedsik.personalworlds.compat;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.config.ModConfig;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1928;
import net.minecraft.server.MinecraftServer;
import xyz.nucleoid.fantasy.RuntimeWorldConfig;

public final class GameRulesCompat {
   private static Map<String, class_1928.class_4313<?>> ruleKeysByName;

   private GameRulesCompat() {
   }

   public static void applyGameRules(RuntimeWorldConfig config, MinecraftServer server) {
      class_1928 overworldRules = server.method_30002().method_8450();
      copyAllRules(config, overworldRules);
      Map<String, Object> overrides = ModConfig.get().dimensionGameRules;
      if (overrides != null && !overrides.isEmpty()) {
         applyOverrides(config, overworldRules, overrides);
      }
   }

   private static void copyAllRules(final RuntimeWorldConfig config, final class_1928 overworldRules) {
      class_1928.method_20744(new class_1928.class_4311() {
         public void method_27329(class_1928.class_4313<class_1928.class_4310> key, class_1928.class_4314<class_1928.class_4310> type) {
            config.setGameRule(key, ((class_1928.class_4310)overworldRules.method_20746(key)).method_20753());
         }

         public void method_27330(class_1928.class_4313<class_1928.class_4312> key, class_1928.class_4314<class_1928.class_4312> type) {
            config.setGameRule(key, ((class_1928.class_4312)overworldRules.method_20746(key)).method_20763());
         }
      });
   }

   private static void applyOverrides(RuntimeWorldConfig config, class_1928 overworldRules, Map<String, Object> overrides) {
      Map<String, class_1928.class_4313<?>> keyMap = getOrBuildKeyMap(overworldRules);

      for(Map.Entry<String, Object> entry : overrides.entrySet()) {
         String ruleName = (String)entry.getKey();
         Object value = entry.getValue();
         class_1928.class_4313<?> key = (class_1928.class_4313)keyMap.get(ruleName);
         if (key == null) {
            PersonalWorldsMod.LOGGER.warn("Unknown game rule '{}' in dimensionGameRules config, skipping", ruleName);
         } else if (value instanceof Boolean) {
            Boolean boolVal = (Boolean)value;
            config.setGameRule(key, boolVal);
         } else if (value instanceof Number) {
            Number numVal = (Number)value;
            config.setGameRule(key, numVal.intValue());
         } else {
            PersonalWorldsMod.LOGGER.warn("Game rule '{}' has unsupported value type: {}", ruleName, value.getClass().getSimpleName());
         }
      }

   }

   private static Map<String, class_1928.class_4313<?>> getOrBuildKeyMap(class_1928 rules) {
      if (ruleKeysByName != null) {
         return ruleKeysByName;
      } else {
         final Map<String, class_1928.class_4313<?>> map = new HashMap();
         class_1928.method_20744(new class_1928.class_4311() {
            public void method_27329(class_1928.class_4313<class_1928.class_4310> key, class_1928.class_4314<class_1928.class_4310> type) {
               map.put(key.method_20771(), key);
            }

            public void method_27330(class_1928.class_4313<class_1928.class_4312> key, class_1928.class_4314<class_1928.class_4312> type) {
               map.put(key.method_20771(), key);
            }
         });
         ruleKeysByName = map;
         PersonalWorldsMod.LOGGER.debug("Built game rule key map with {} entries", map.size());
         return map;
      }
   }
}
