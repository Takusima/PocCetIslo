package com.wickedsik.personalworlds.command.executor;

import com.wickedsik.personalworlds.command.CommandResult;
import com.wickedsik.personalworlds.util.PerformanceMonitor;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;

public class DebugCommandExecutor {
   public CommandResult enablePerf() {
      PerformanceMonitor.enable();
      return CommandResult.successBroadcast(class_2561.method_43471("pocketislands.command.perf.enabled").method_27692(class_124.field_1060));
   }

   public CommandResult disablePerf() {
      PerformanceMonitor.disable();
      return CommandResult.successBroadcast(class_2561.method_43471("pocketislands.command.perf.disabled").method_27692(class_124.field_1054));
   }

   public void showStatus(class_2168 source, MinecraftServer server) {
      String status = PerformanceMonitor.getStatusSummary(server);

      for(String line : status.split("\n")) {
         source.method_9226(() -> class_2561.method_43470(line), false);
      }

   }

   public CommandResult resetCounters() {
      PerformanceMonitor.resetCounters();
      return CommandResult.successBroadcast(class_2561.method_43471("pocketislands.command.perf.reset").method_27692(class_124.field_1054));
   }
}
