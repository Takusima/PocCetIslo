package com.wickedsik.personalworlds.command.executor;

import com.wickedsik.personalworlds.command.CommandResult;
import com.wickedsik.personalworlds.command.service.PlayerLookupService;
import com.wickedsik.personalworlds.command.service.TeleportHelper;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionManager;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import com.wickedsik.personalworlds.player.ReturnData;
import com.wickedsik.personalworlds.portal.PortalOwnershipManager;
import com.wickedsik.personalworlds.registry.ModBlocks;
import com.wickedsik.personalworlds.registry.ModItems;
import com.wickedsik.personalworlds.util.VisualEffects;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

public class AdminCommandExecutor {
   private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm");
   private final PlayerLookupService playerLookup;

   public AdminCommandExecutor(PlayerLookupService playerLookup) {
      this.playerLookup = playerLookup;
   }

   public void list(class_2168 source) {
      MinecraftServer server = source.method_9211();
      DimensionRegistry registry = DimensionRegistry.get(server);
      Map<UUID, PlayerDimensionData> dimensions = registry.getAllDimensions();
      if (dimensions.isEmpty()) {
         source.method_9226(() -> class_2561.method_43471("pocketislands.command.list.empty").method_27692(class_124.field_1080), false);
      } else {
         class_5250 header = class_2561.method_43471("pocketislands.command.list.header").method_27692(class_124.field_1065);
         source.method_9226(() -> header, false);

         for(PlayerDimensionData data : dimensions.values()) {
            boolean loaded = DimensionManager.isDimensionLoaded(data.ownerUuid());
            class_3218 world = loaded ? DimensionManager.getLoadedDimension(data.ownerUuid()) : null;
            int playerCount = world != null ? world.method_18456().size() : 0;
            class_5250 line = class_2561.method_43470(" - ").method_10852(class_2561.method_43470(data.ownerName()).method_27692(loaded ? class_124.field_1060 : class_124.field_1080)).method_10852(class_2561.method_43470(" (").method_27692(class_124.field_1063)).method_10852(class_2561.method_43470(data.generatorType().name()).method_27692(class_124.field_1075)).method_10852(class_2561.method_43470(") ").method_27692(class_124.field_1063));
            if (loaded) {
               line.method_10852(class_2561.method_43471("pocketislands.command.list.loaded").method_27692(class_124.field_1060));
               if (playerCount > 0) {
                  line.method_10852(class_2561.method_43470(", " + playerCount + " player" + (playerCount > 1 ? "s" : "")).method_27692(class_124.field_1054));
               }

               line.method_10852(class_2561.method_43470("]").method_27692(class_124.field_1060));
            } else {
               line.method_10852(class_2561.method_43471("pocketislands.command.list.unloaded").method_27692(class_124.field_1080));
            }

            source.method_9226(() -> line, false);
         }

      }
   }

   public CommandResult info(class_2168 source, String playerName) {
      MinecraftServer server = source.method_9211();
      Optional<PlayerDimensionData> optData = this.playerLookup.findDimensionByOwnerName(server, playerName);
      if (optData.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.no_dimension_for_player", new Object[]{playerName}));
      } else {
         PlayerDimensionData data = (PlayerDimensionData)optData.get();
         boolean loaded = DimensionManager.isDimensionLoaded(data.ownerUuid());
         class_3218 world = loaded ? DimensionManager.getLoadedDimension(data.ownerUuid()) : null;
         int playerCount = world != null ? world.method_18456().size() : 0;
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         Set<UUID> sentInvites = dataManager.getSentInvitations(data.ownerUuid());
         int inviteCount = sentInvites.size();
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.header", new Object[]{data.ownerName()}).method_27692(class_124.field_1065), false);
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.owner", new Object[]{data.ownerName()}), false);
         String createdStr = DATE_FORMAT.format(new Date(data.createdAt()));
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.created", new Object[]{createdStr}), false);
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.world_type", new Object[]{data.generatorType().name()}), false);
         if (loaded) {
            source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.status_loaded", new Object[]{playerCount}), false);
         } else {
            source.method_9226(() -> class_2561.method_43471("pocketislands.command.info.status_unloaded"), false);
         }

         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.invitations", new Object[]{inviteCount}), false);
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.spawn", new Object[]{data.spawnPoint().method_10263(), data.spawnPoint().method_10264(), data.spawnPoint().method_10260()}), false);
         return CommandResult.silent();
      }
   }

   public CommandResult deletePrompt(class_2168 source, String playerName) {
      MinecraftServer server = source.method_9211();
      Optional<PlayerDimensionData> optData = this.playerLookup.findDimensionByOwnerName(server, playerName);
      if (optData.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.no_dimension_for_player", new Object[]{playerName}));
      } else {
         PlayerDimensionData data = (PlayerDimensionData)optData.get();
         class_1297 var7 = source.method_9228();
         if (var7 instanceof class_3222) {
            class_3222 admin = (class_3222)var7;
            VisualEffects.playAdminWarningEffect(admin);
         }

         boolean loaded = DimensionManager.isDimensionLoaded(data.ownerUuid());
         class_3218 world = loaded ? DimensionManager.getLoadedDimension(data.ownerUuid()) : null;
         int playerCount = world != null ? world.method_18456().size() : 0;
         source.method_9226(() -> class_2561.method_43469("pocketislands.command.delete.warning", new Object[]{data.ownerName()}), false);
         if (playerCount > 0) {
            source.method_9226(() -> class_2561.method_43469("pocketislands.command.delete.players_ejected", new Object[]{playerCount}).method_27692(class_124.field_1065), false);
         }

         source.method_9226(() -> class_2561.method_43469("pocketislands.command.delete.confirm", new Object[]{data.ownerName()}), false);
         return CommandResult.silent();
      }
   }

   public CommandResult deleteConfirm(class_2168 source, String playerName) {
      MinecraftServer server = source.method_9211();
      Optional<PlayerDimensionData> optData = this.playerLookup.findDimensionByOwnerName(server, playerName);
      if (optData.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.no_dimension_for_player", new Object[]{playerName}));
      } else {
         PlayerDimensionData data = (PlayerDimensionData)optData.get();
         UUID ownerUuid = data.ownerUuid();
         String ownerName = data.ownerName();
         if (DimensionManager.isDimensionLoaded(ownerUuid)) {
            class_3218 dimWorld = DimensionManager.getLoadedDimension(ownerUuid);
            if (dimWorld != null) {
               class_3218 overworld = server.method_30002();

               for(class_3222 player : new ArrayList(dimWorld.method_18456())) {
                  TeleportCompat.teleport(player, overworld, TeleportHelper.toWorldSpawn(overworld, player));
                  player.method_7353(class_2561.method_43471("pocketislands.message.admin_ejected").method_27692(class_124.field_1061), false);
               }
            }
         }

         DimensionRegistry registry = DimensionRegistry.get(server);
         registry.removeDimension(ownerUuid);
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         dataManager.clearAllInvitationsFor(ownerUuid);
         PortalOwnershipManager portalManager = PortalOwnershipManager.get(server);
         int portalsCleared = portalManager.clearPortalsOwnedBy(ownerUuid);
         if (portalsCleared > 0) {
            source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.cleared_portals", new Object[]{portalsCleared}).method_27692(class_124.field_1080), false);
         }

         DimensionManager.deleteDimension(server, ownerUuid);
         class_1297 var13 = source.method_9228();
         if (var13 instanceof class_3222) {
            class_3222 admin = (class_3222)var13;
            VisualEffects.playAdminSuccessEffect(admin);
         }

         return CommandResult.successBroadcast(class_2561.method_43469("pocketislands.command.info.deleted", new Object[]{ownerName}).method_27692(class_124.field_1060));
      }
   }

   public CommandResult teleport(class_3222 admin, String playerName) {
      MinecraftServer server = EntityCompat.getServer(admin);
      Optional<PlayerDimensionData> optData = this.playerLookup.findDimensionByOwnerName(server, playerName);
      if (optData.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.no_dimension_for_player", new Object[]{playerName}));
      } else {
         PlayerDimensionData data = (PlayerDimensionData)optData.get();
         class_3218 dimension = DimensionManager.getOrCreatePlayerDimension(server, data.ownerUuid(), data.ownerName(), data.generatorType(), data.portalTypeIndex());
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         dataManager.setReturnData(admin.method_5667(), new ReturnData(EntityCompat.getServerWorld(admin).method_27983(), admin.method_24515(), admin.method_36454(), admin.method_36455()));
         VisualEffects.playTeleportDepartureEffects(admin);
         TeleportCompat.teleport(admin, dimension, TeleportHelper.toBlockPos(dimension, data.spawnPoint(), admin));
         VisualEffects.playTeleportArrivalEffects(admin);
         return CommandResult.successBroadcast(class_2561.method_43469("pocketislands.command.info.teleported", new Object[]{data.ownerName()}).method_27692(class_124.field_1060));
      }
   }

   public CommandResult reload(class_2168 source) {
      ModConfig.reload();
      ModBlocks.clearCache();
      ModItems.clearCache();
      source.method_9226(() -> class_2561.method_43471("pocketislands.command.info.config_reloaded").method_27692(class_124.field_1060), true);
      source.method_9226(() -> class_2561.method_43469("pocketislands.command.info.config_path", new Object[]{ModConfig.getConfigPath()}).method_27692(class_124.field_1080), false);
      return CommandResult.silent();
   }
}
