package com.wickedsik.personalworlds.player;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.compat.NbtCompat;
import com.wickedsik.personalworlds.compat.PersistentStateCompat;
import com.wickedsik.personalworlds.util.DataValidator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_26;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public class PlayerDataManager extends class_18 {
   private static final String DATA_NAME = "personalworlds_player_data";
   private final Map<UUID, ReturnData> returnPositions = new HashMap();
   private final Map<UUID, List<InvitationData>> receivedInvitations = new HashMap();
   private final Map<UUID, Set<UUID>> sentInvitations = new HashMap();
   private final Map<UUID, class_5321<class_1937>> currentPocketDimensions = new HashMap();

   public void setReturnData(UUID playerUuid, ReturnData data) {
      if (data != null && DataValidator.isValidUuid(playerUuid)) {
         this.returnPositions.put(playerUuid, data);
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Stored return data for player: {}", playerUuid);
      } else {
         PersonalWorldsMod.LOGGER.warn("Attempted to set invalid return data for {}", playerUuid);
      }
   }

   public Optional<ReturnData> getReturnData(UUID playerUuid) {
      return Optional.ofNullable((ReturnData)this.returnPositions.get(playerUuid));
   }

   public void clearReturnData(UUID playerUuid) {
      if (this.returnPositions.remove(playerUuid) != null) {
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Cleared return data for player: {}", playerUuid);
      }

   }

   public boolean hasReturnData(UUID playerUuid) {
      return this.returnPositions.containsKey(playerUuid);
   }

   public boolean addInvitation(UUID ownerUuid, String ownerName, UUID guestUuid) {
      return this.addInvitation(ownerUuid, ownerName, guestUuid, false);
   }

   public boolean addInvitation(UUID ownerUuid, String ownerName, UUID guestUuid, boolean alwaysWelcome) {
      ownerName = DataValidator.sanitizePlayerName(ownerName);
      if (this.hasInvitationFrom(guestUuid, ownerUuid)) {
         return false;
      } else {
         InvitationData invitation = new InvitationData(ownerUuid, ownerName, System.currentTimeMillis(), alwaysWelcome);
         ((List)this.receivedInvitations.computeIfAbsent(guestUuid, (k) -> new ArrayList())).add(invitation);
         ((Set)this.sentInvitations.computeIfAbsent(ownerUuid, (k) -> new HashSet())).add(guestUuid);
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Added invitation: {} invited {} to their dimension (alwaysWelcome={})", new Object[]{ownerName, guestUuid, alwaysWelcome});
         return true;
      }
   }

   public boolean removeInvitation(UUID ownerUuid, UUID guestUuid) {
      boolean removed = false;
      List<InvitationData> guestInvitations = (List)this.receivedInvitations.get(guestUuid);
      if (guestInvitations != null) {
         removed = guestInvitations.removeIf((inv) -> inv.ownerUuid().equals(ownerUuid));
         if (guestInvitations.isEmpty()) {
            this.receivedInvitations.remove(guestUuid);
         }
      }

      Set<UUID> ownerSent = (Set)this.sentInvitations.get(ownerUuid);
      if (ownerSent != null) {
         ownerSent.remove(guestUuid);
         if (ownerSent.isEmpty()) {
            this.sentInvitations.remove(ownerUuid);
         }
      }

      if (removed) {
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Removed invitation: {} revoked invitation to {}", ownerUuid, guestUuid);
      }

      return removed;
   }

   public boolean hasInvitationFrom(UUID guestUuid, UUID ownerUuid) {
      return this.getInvitationFrom(guestUuid, ownerUuid).isPresent();
   }

   public Optional<InvitationData> getInvitationFrom(UUID guestUuid, UUID ownerUuid) {
      List<InvitationData> guestInvitations = (List)this.receivedInvitations.get(guestUuid);
      return guestInvitations == null ? Optional.empty() : guestInvitations.stream().filter((inv) -> inv.ownerUuid().equals(ownerUuid)).findFirst();
   }

   public boolean isAlwaysWelcome(UUID ownerUuid, UUID guestUuid) {
      return (Boolean)this.getInvitationFrom(guestUuid, ownerUuid).map(InvitationData::alwaysWelcome).orElse(false);
   }

   public Optional<Boolean> toggleAlwaysWelcome(UUID ownerUuid, UUID guestUuid) {
      Optional<InvitationData> current = this.getInvitationFrom(guestUuid, ownerUuid);
      if (current.isEmpty()) {
         return Optional.empty();
      } else {
         InvitationData updated = ((InvitationData)current.get()).withToggledAlwaysWelcome();
         this.updateInvitation(guestUuid, ownerUuid, updated);
         return Optional.of(updated.alwaysWelcome());
      }
   }

   private void updateInvitation(UUID guestUuid, UUID ownerUuid, InvitationData updated) {
      List<InvitationData> guestInvitations = (List)this.receivedInvitations.get(guestUuid);
      if (guestInvitations != null) {
         for(int i = 0; i < guestInvitations.size(); ++i) {
            if (((InvitationData)guestInvitations.get(i)).ownerUuid().equals(ownerUuid)) {
               guestInvitations.set(i, updated);
               this.method_80();
               PersonalWorldsMod.LOGGER.debug("Updated invitation from {} to {}: alwaysWelcome={}", new Object[]{ownerUuid, guestUuid, updated.alwaysWelcome()});
               return;
            }
         }

      }
   }

   public List<InvitationData> getReceivedInvitations(UUID guestUuid) {
      return (List)this.receivedInvitations.getOrDefault(guestUuid, Collections.emptyList());
   }

   public Set<UUID> getSentInvitations(UUID ownerUuid) {
      return (Set)this.sentInvitations.getOrDefault(ownerUuid, Collections.emptySet());
   }

   public void clearAllInvitationsFor(UUID playerUuid) {
      boolean changed = false;
      Set<UUID> guests = (Set)this.sentInvitations.remove(playerUuid);
      if (guests != null && !guests.isEmpty()) {
         for(UUID guestUuid : guests) {
            List<InvitationData> guestInvitations = (List)this.receivedInvitations.get(guestUuid);
            if (guestInvitations != null) {
               guestInvitations.removeIf((invx) -> invx.ownerUuid().equals(playerUuid));
               if (guestInvitations.isEmpty()) {
                  this.receivedInvitations.remove(guestUuid);
               }
            }
         }

         changed = true;
         PersonalWorldsMod.LOGGER.debug("Cleared {} sent invitations for {}", guests.size(), playerUuid);
      }

      List<InvitationData> received = (List)this.receivedInvitations.remove(playerUuid);
      if (received != null && !received.isEmpty()) {
         for(InvitationData inv : received) {
            Set<UUID> ownerSent = (Set)this.sentInvitations.get(inv.ownerUuid());
            if (ownerSent != null) {
               ownerSent.remove(playerUuid);
               if (ownerSent.isEmpty()) {
                  this.sentInvitations.remove(inv.ownerUuid());
               }
            }
         }

         changed = true;
         PersonalWorldsMod.LOGGER.debug("Cleared {} received invitations for {}", received.size(), playerUuid);
      }

      if (changed) {
         this.method_80();
      }

   }

   public void setCurrentPocketDimension(UUID playerUuid, class_5321<class_1937> dimension) {
      if (DataValidator.isValidUuid(playerUuid) && dimension != null) {
         this.currentPocketDimensions.put(playerUuid, dimension);
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Tracking player {} in pocket dimension: {}", playerUuid, dimension.method_29177());
      } else {
         PersonalWorldsMod.LOGGER.warn("Attempted to set invalid pocket dimension tracking for {}", playerUuid);
      }
   }

   public Optional<class_5321<class_1937>> getCurrentPocketDimension(UUID playerUuid) {
      return Optional.ofNullable((class_5321)this.currentPocketDimensions.get(playerUuid));
   }

   public void clearCurrentPocketDimension(UUID playerUuid) {
      if (this.currentPocketDimensions.remove(playerUuid) != null) {
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Cleared pocket dimension tracking for player: {}", playerUuid);
      }

   }

   public boolean isInPocketDimension(UUID playerUuid) {
      return this.currentPocketDimensions.containsKey(playerUuid);
   }

   public class_2487 method_75(class_2487 nbt) {
      return this.writeNbtData(nbt);
   }

   private class_2487 writeNbtData(class_2487 nbt) {
      class_2487 returnDataNbt = new class_2487();

      for(Map.Entry<UUID, ReturnData> entry : this.returnPositions.entrySet()) {
         returnDataNbt.method_10566(((UUID)entry.getKey()).toString(), ((ReturnData)entry.getValue()).toNbt());
      }

      nbt.method_10566("ReturnPositions", returnDataNbt);
      class_2487 receivedNbt = new class_2487();

      for(Map.Entry<UUID, List<InvitationData>> entry : this.receivedInvitations.entrySet()) {
         class_2499 invList = new class_2499();

         for(InvitationData inv : (List)entry.getValue()) {
            invList.add(inv.toNbt());
         }

         receivedNbt.method_10566(((UUID)entry.getKey()).toString(), invList);
      }

      nbt.method_10566("ReceivedInvitations", receivedNbt);
      class_2487 sentNbt = new class_2487();

      for(Map.Entry<UUID, Set<UUID>> entry : this.sentInvitations.entrySet()) {
         class_2499 guestList = new class_2499();

         for(UUID guestUuid : (Set)entry.getValue()) {
            class_2487 guestNbt = new class_2487();
            NbtCompat.putUuid(guestNbt, "Uuid", guestUuid);
            guestList.add(guestNbt);
         }

         sentNbt.method_10566(((UUID)entry.getKey()).toString(), guestList);
      }

      nbt.method_10566("SentInvitations", sentNbt);
      class_2487 pocketDimNbt = new class_2487();

      for(Map.Entry<UUID, class_5321<class_1937>> entry : this.currentPocketDimensions.entrySet()) {
         pocketDimNbt.method_10582(((UUID)entry.getKey()).toString(), ((class_5321)entry.getValue()).method_29177().toString());
      }

      nbt.method_10566("CurrentPocketDimensions", pocketDimNbt);
      return nbt;
   }

   public static PlayerDataManager fromNbt(class_2487 nbt) {
      PlayerDataManager manager = new PlayerDataManager();
      if (NbtCompat.contains(nbt, "ReturnPositions", 10)) {
         class_2487 returnDataNbt = NbtCompat.getCompound(nbt, "ReturnPositions");

         for(String key : returnDataNbt.method_10541()) {
            try {
               UUID uuid = UUID.fromString(key);
               ReturnData data = ReturnData.fromNbt(NbtCompat.getCompound(returnDataNbt, key));
               manager.returnPositions.put(uuid, data);
            } catch (IllegalArgumentException var12) {
               PersonalWorldsMod.LOGGER.warn("Invalid UUID in return positions: {}", key);
            }
         }
      }

      if (NbtCompat.contains(nbt, "ReceivedInvitations", 10)) {
         class_2487 receivedNbt = NbtCompat.getCompound(nbt, "ReceivedInvitations");

         for(String key : receivedNbt.method_10541()) {
            try {
               UUID guestUuid = UUID.fromString(key);
               class_2499 invList = NbtCompat.getList(receivedNbt, key, 10);
               List<InvitationData> invitations = new ArrayList();

               for(int i = 0; i < invList.size(); ++i) {
                  invitations.add(InvitationData.fromNbt(NbtCompat.getCompound(invList, i)));
               }

               if (!invitations.isEmpty()) {
                  manager.receivedInvitations.put(guestUuid, invitations);
               }
            } catch (IllegalArgumentException var14) {
               PersonalWorldsMod.LOGGER.warn("Invalid UUID in received invitations: {}", key);
            }
         }
      }

      if (NbtCompat.contains(nbt, "SentInvitations", 10)) {
         class_2487 sentNbt = NbtCompat.getCompound(nbt, "SentInvitations");

         for(String key : sentNbt.method_10541()) {
            try {
               UUID ownerUuid = UUID.fromString(key);
               class_2499 guestList = NbtCompat.getList(sentNbt, key, 10);
               Set<UUID> guests = new HashSet();

               for(int i = 0; i < guestList.size(); ++i) {
                  class_2487 guestNbt = NbtCompat.getCompound(guestList, i);
                  UUID guestUuid = NbtCompat.getUuid(guestNbt, "Uuid");
                  if (guestUuid != null) {
                     guests.add(guestUuid);
                  }
               }

               if (!guests.isEmpty()) {
                  manager.sentInvitations.put(ownerUuid, guests);
               }
            } catch (IllegalArgumentException var13) {
               PersonalWorldsMod.LOGGER.warn("Invalid UUID in sent invitations: {}", key);
            }
         }
      }

      if (NbtCompat.contains(nbt, "CurrentPocketDimensions", 10)) {
         class_2487 pocketDimNbt = NbtCompat.getCompound(nbt, "CurrentPocketDimensions");

         for(String key : pocketDimNbt.method_10541()) {
            try {
               UUID playerUuid = UUID.fromString(key);
               class_2960 dimId = IdentifierCompat.fromNbtString(NbtCompat.getString(pocketDimNbt, key, ""));
               if (dimId != null) {
                  class_5321<class_1937> dimension = class_5321.method_29179(class_7924.field_41223, dimId);
                  manager.currentPocketDimensions.put(playerUuid, dimension);
               }
            } catch (IllegalArgumentException var11) {
               PersonalWorldsMod.LOGGER.warn("Invalid UUID or dimension in pocket dimensions: {}", key);
            }
         }
      }

      PersonalWorldsMod.LOGGER.debug("Loaded {} return positions, {} players with received invitations, {} owners with sent invitations, {} pocket dimension trackings", new Object[]{manager.returnPositions.size(), manager.receivedInvitations.size(), manager.sentInvitations.size(), manager.currentPocketDimensions.size()});
      return manager;
   }

   public static PlayerDataManager get(MinecraftServer server) {
      class_26 stateManager = server.method_30002().method_17983();
      return (PlayerDataManager)PersistentStateCompat.getOrCreate(stateManager, "personalworlds_player_data", PlayerDataManager::new, PlayerDataManager::fromNbt);
   }
}
