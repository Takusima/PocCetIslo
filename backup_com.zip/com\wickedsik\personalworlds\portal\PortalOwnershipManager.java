package com.wickedsik.personalworlds.portal;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.NbtCompat;
import com.wickedsik.personalworlds.compat.PersistentStateCompat;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class PortalOwnershipManager extends class_18 {
   private static final String DATA_NAME = "personalworlds_portal_ownership";
   private final Map<String, PortalOwnershipData> portalOwners = new HashMap();

   public void registerPortal(class_1937 world, class_2338 pos, UUID ownerUuid, int portalTypeIndex) {
      String key = this.makeKey(world, pos);
      this.portalOwners.put(key, new PortalOwnershipData(ownerUuid, portalTypeIndex));
      this.method_80();
      PersonalWorldsMod.LOGGER.debug("Registered portal type {} at {} owned by {}", new Object[]{portalTypeIndex, key, ownerUuid});
   }

   public Optional<UUID> getOwner(class_1937 world, class_2338 pos) {
      String key = this.makeKey(world, pos);
      PortalOwnershipData data = (PortalOwnershipData)this.portalOwners.get(key);
      return data != null ? Optional.of(data.ownerUuid) : Optional.empty();
   }

   public Optional<Integer> getPortalType(class_1937 world, class_2338 pos) {
      String key = this.makeKey(world, pos);
      PortalOwnershipData data = (PortalOwnershipData)this.portalOwners.get(key);
      return data != null ? Optional.of(data.portalTypeIndex) : Optional.empty();
   }

   public void removePortal(class_1937 world, class_2338 pos) {
      String key = this.makeKey(world, pos);
      if (this.portalOwners.remove(key) != null) {
         this.method_80();
         PersonalWorldsMod.LOGGER.debug("Removed portal ownership at {}", key);
      }

   }

   public boolean hasOwner(class_1937 world, class_2338 pos) {
      String key = this.makeKey(world, pos);
      return this.portalOwners.containsKey(key);
   }

   public int clearPortalsOwnedBy(UUID ownerUuid) {
      int removed = 0;
      Iterator<Map.Entry<String, PortalOwnershipData>> iterator = this.portalOwners.entrySet().iterator();

      while(iterator.hasNext()) {
         Map.Entry<String, PortalOwnershipData> entry = (Map.Entry)iterator.next();
         if (((PortalOwnershipData)entry.getValue()).ownerUuid.equals(ownerUuid)) {
            iterator.remove();
            ++removed;
         }
      }

      if (removed > 0) {
         this.method_80();
         PersonalWorldsMod.LOGGER.info("Cleared {} portal ownership records for {}", removed, ownerUuid);
      }

      return removed;
   }

   public String getOwnerName(MinecraftServer server, UUID ownerUuid) {
      class_3222 player = server.method_3760().method_14602(ownerUuid);
      if (player != null) {
         return player.method_5477().getString();
      } else {
         DimensionRegistry registry = DimensionRegistry.get(server);
         Optional<PlayerDimensionData> data = registry.getDimensionData(ownerUuid);
         return data.isPresent() ? ((PlayerDimensionData)data.get()).ownerName() : ownerUuid.toString().substring(0, 8);
      }
   }

   private String makeKey(class_1937 world, class_2338 pos) {
      String var10000 = world.method_27983().method_29177().toString();
      return var10000 + ":" + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
   }

   public class_2487 method_75(class_2487 nbt) {
      class_2487 portalsNbt = new class_2487();

      for(Map.Entry<String, PortalOwnershipData> entry : this.portalOwners.entrySet()) {
         class_2487 portalData = new class_2487();
         portalData.method_25927("OwnerUuid", ((PortalOwnershipData)entry.getValue()).ownerUuid);
         portalData.method_10569("PortalTypeIndex", ((PortalOwnershipData)entry.getValue()).portalTypeIndex);
         portalsNbt.method_10566((String)entry.getKey(), portalData);
      }

      nbt.method_10566("PortalOwners", portalsNbt);
      return nbt;
   }

   public static PortalOwnershipManager fromNbt(class_2487 nbt) {
      PortalOwnershipManager manager = new PortalOwnershipManager();
      if (NbtCompat.contains(nbt, "PortalOwners", 10)) {
         class_2487 portalsNbt = NbtCompat.getCompound(nbt, "PortalOwners");

         for(String key : portalsNbt.method_10541()) {
            try {
               class_2520 element = portalsNbt.method_10580(key);
               if (element instanceof class_2487) {
                  class_2487 portalData = (class_2487)element;
                  UUID uuid = NbtCompat.getUuid(portalData, "OwnerUuid");
                  int portalTypeIndex = NbtCompat.getInt(portalData, "PortalTypeIndex", 0);
                  if (uuid != null) {
                     manager.portalOwners.put(key, new PortalOwnershipData(uuid, portalTypeIndex));
                  }
               } else {
                  UUID uuid = NbtCompat.getUuid(portalsNbt, key);
                  if (uuid != null) {
                     manager.portalOwners.put(key, new PortalOwnershipData(uuid, 0));
                     PersonalWorldsMod.LOGGER.debug("Migrated old portal ownership data for key: {}", key);
                  }
               }
            } catch (Exception var9) {
               PersonalWorldsMod.LOGGER.warn("Invalid portal ownership data for key: {}", key);
            }
         }
      }

      PersonalWorldsMod.LOGGER.debug("Loaded {} portal ownership records", manager.portalOwners.size());
      return manager;
   }

   public static PortalOwnershipManager get(MinecraftServer server) {
      class_26 stateManager = server.method_30002().method_17983();
      return (PortalOwnershipManager)PersistentStateCompat.getOrCreate(stateManager, "personalworlds_portal_ownership", PortalOwnershipManager::new, PortalOwnershipManager::fromNbt);
   }

   private static class PortalOwnershipData {
      UUID ownerUuid;
      int portalTypeIndex;

      PortalOwnershipData(UUID ownerUuid, int portalTypeIndex) {
         this.ownerUuid = ownerUuid;
         this.portalTypeIndex = portalTypeIndex;
      }
   }
}
