package com.wickedsik.personalworlds.dimension;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.NbtCompat;
import com.wickedsik.personalworlds.compat.PersistentStateCompat;
import com.wickedsik.personalworlds.util.DataValidator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_26;
import net.minecraft.server.MinecraftServer;

public class DimensionRegistry extends class_18 {
   private static final String DATA_NAME = "personalworlds_registry";
   private final Map<UUID, PlayerDimensionData> dimensions = new HashMap();

   public void registerDimension(PlayerDimensionData data) {
      if (!DataValidator.isValidDimensionData(data)) {
         PersonalWorldsMod.LOGGER.error("Attempted to register invalid dimension data for {}", data.ownerUuid());
         data = DataValidator.sanitizeDimensionData(data, data.ownerUuid());
      }

      this.dimensions.put(data.ownerUuid(), data);
      this.method_80();
      PersonalWorldsMod.LOGGER.info("Registered dimension for player: {} ({})", data.ownerName(), data.ownerUuid());
   }

   public boolean hasDimension(UUID playerUuid) {
      return this.dimensions.containsKey(playerUuid);
   }

   public Optional<PlayerDimensionData> getDimensionData(UUID playerUuid) {
      return Optional.ofNullable((PlayerDimensionData)this.dimensions.get(playerUuid));
   }

   public Map<UUID, PlayerDimensionData> getAllDimensions() {
      return Map.copyOf(this.dimensions);
   }

   public void removeDimension(UUID playerUuid) {
      if (this.dimensions.remove(playerUuid) != null) {
         this.method_80();
         PersonalWorldsMod.LOGGER.info("Removed dimension for player: {}", playerUuid);
      }

   }

   public void restoreAllDimensions(MinecraftServer server) {
      PersonalWorldsMod.LOGGER.info("Restoring {} player dimensions...", this.dimensions.size());

      for(PlayerDimensionData data : this.dimensions.values()) {
         try {
            DimensionManager.loadExistingDimension(server, data);
         } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to restore dimension for {}: {}", data.ownerName(), e.getMessage());
         }
      }

      PersonalWorldsMod.LOGGER.info("Dimension restoration complete!");
   }

   public class_2487 method_75(class_2487 nbt) {
      class_2499 dimensionList = new class_2499();

      for(PlayerDimensionData data : this.dimensions.values()) {
         dimensionList.add(data.toNbt());
      }

      nbt.method_10566("Dimensions", dimensionList);
      return nbt;
   }

   public static DimensionRegistry fromNbt(class_2487 nbt) {
      DimensionRegistry registry = new DimensionRegistry();
      class_2499 dimensionList = NbtCompat.getList(nbt, "Dimensions", 10);
      int skipped = 0;

      for(int i = 0; i < dimensionList.size(); ++i) {
         try {
            PlayerDimensionData data = PlayerDimensionData.fromNbt(NbtCompat.getCompound(dimensionList, i));
            if (!DataValidator.isValidDimensionData(data)) {
               PersonalWorldsMod.LOGGER.warn("Skipping invalid dimension data for {}", data.ownerUuid());
               ++skipped;
            } else {
               registry.dimensions.put(data.ownerUuid(), data);
            }
         } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to load dimension data at index {}: {}", i, e.getMessage());
            ++skipped;
         }
      }

      PersonalWorldsMod.LOGGER.info("Loaded {} dimensions from registry ({} skipped)", registry.dimensions.size(), skipped);
      return registry;
   }

   public static DimensionRegistry get(MinecraftServer server) {
      class_26 stateManager = server.method_30002().method_17983();
      return (DimensionRegistry)PersistentStateCompat.getOrCreate(stateManager, "personalworlds_registry", DimensionRegistry::new, DimensionRegistry::fromNbt);
   }
}
