package com.wickedsik.personalworlds.compat;

import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import org.jetbrains.annotations.Nullable;

public final class NbtCompat {
   private NbtCompat() {
   }

   public static int getInt(class_2487 nbt, String key, int defaultValue) {
      return nbt.method_10573(key, 3) ? nbt.method_10550(key) : defaultValue;
   }

   public static String getString(class_2487 nbt, String key, String defaultValue) {
      return nbt.method_10573(key, 8) ? nbt.method_10558(key) : defaultValue;
   }

   public static float getFloat(class_2487 nbt, String key, float defaultValue) {
      return nbt.method_10573(key, 5) ? nbt.method_10583(key) : defaultValue;
   }

   public static boolean getBoolean(class_2487 nbt, String key, boolean defaultValue) {
      return nbt.method_10573(key, 1) ? nbt.method_10577(key) : defaultValue;
   }

   public static void putUuid(class_2487 nbt, String key, UUID uuid) {
      nbt.method_25927(key, uuid);
   }

   public static @Nullable UUID getUuid(class_2487 nbt, String key) {
      return nbt.method_25928(key) ? nbt.method_25926(key) : null;
   }

   public static boolean containsUuid(class_2487 nbt, String key) {
      return nbt.method_25928(key);
   }

   public static boolean contains(class_2487 nbt, String key, int type) {
      return nbt.method_10573(key, type);
   }

   public static class_2487 getCompound(class_2487 nbt, String key) {
      return nbt.method_10562(key);
   }

   public static long getLong(class_2487 nbt, String key, long defaultValue) {
      return nbt.method_10573(key, 4) ? nbt.method_10537(key) : defaultValue;
   }

   public static class_2499 getList(class_2487 nbt, String key, int type) {
      return nbt.method_10554(key, type);
   }

   public static class_2487 getCompound(class_2499 list, int index) {
      return list.method_10602(index);
   }
}
