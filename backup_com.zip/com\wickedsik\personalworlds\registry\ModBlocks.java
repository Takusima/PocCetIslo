package com.wickedsik.personalworlds.registry;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.BlockSettingsCompat;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.portal.PersonalPortalBlock;
import com.wickedsik.personalworlds.portal.PortalColor;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_7923;

public class ModBlocks {
   private static final class_2960 PERSONAL_PORTAL_ID = IdentifierCompat.modId("personal_portal");
   public static final class_2248 PERSONAL_PORTAL;
   private static class_2248[] cachedFrameBlocks;
   private static PortalColor[] cachedPortalColors;

   public static void register() {
      class_2378.method_10230(class_7923.field_41175, PERSONAL_PORTAL_ID, PERSONAL_PORTAL);
      PersonalWorldsMod.LOGGER.info("Registered blocks");
   }

   public static class_2248 getFrameBlock(int portalTypeIndex) {
      if (cachedFrameBlocks == null) {
         List<ModConfig.PortalConfig> configs = ModConfig.get().portalTypes;
         cachedFrameBlocks = new class_2248[configs.size()];

         for(int i = 0; i < configs.size(); ++i) {
            String blockId = ((ModConfig.PortalConfig)configs.get(i)).frameBlock;
            class_2960 id = IdentifierCompat.tryParse(blockId);
            class_2248 block = id != null ? (class_2248)class_7923.field_41175.method_10223(id) : class_2246.field_10124;
            if (block == class_2246.field_10124 && !blockId.equals("minecraft:air")) {
               PersonalWorldsMod.LOGGER.warn("Invalid frame block '{}' for portal type {}, using nether_bricks", blockId, i);
               block = class_2246.field_10266;
            }

            cachedFrameBlocks[i] = block;
            PersonalWorldsMod.LOGGER.debug("Portal type {} frame block set to: {}", i, class_7923.field_41175.method_10221(block));
         }
      }

      if (portalTypeIndex >= 0 && portalTypeIndex < cachedFrameBlocks.length) {
         return cachedFrameBlocks[portalTypeIndex];
      } else {
         PersonalWorldsMod.LOGGER.warn("Portal type index {} out of bounds (0-{}), using 0", portalTypeIndex, cachedFrameBlocks.length - 1);
         return cachedFrameBlocks[0];
      }
   }

   public static PortalColor getPortalColor(int portalTypeIndex) {
      if (cachedPortalColors == null) {
         List<ModConfig.PortalConfig> configs = ModConfig.get().portalTypes;
         cachedPortalColors = new PortalColor[configs.size()];

         for(int i = 0; i < configs.size(); ++i) {
            String colorStr = ((ModConfig.PortalConfig)configs.get(i)).portalColor;
            cachedPortalColors[i] = PortalColor.fromString(colorStr);
            PersonalWorldsMod.LOGGER.debug("Portal type {} color set to: {}", i, cachedPortalColors[i].method_15434());
         }
      }

      if (portalTypeIndex >= 0 && portalTypeIndex < cachedPortalColors.length) {
         return cachedPortalColors[portalTypeIndex];
      } else {
         PersonalWorldsMod.LOGGER.warn("Portal type index {} out of bounds (0-{}), using RED", portalTypeIndex, cachedPortalColors.length - 1);
         return PortalColor.RED;
      }
   }

   public static void clearCache() {
      cachedFrameBlocks = null;
      cachedPortalColors = null;
      PersonalWorldsMod.LOGGER.debug("Block cache cleared");
   }

   static {
      PERSONAL_PORTAL = new PersonalPortalBlock(BlockSettingsCompat.create(PERSONAL_PORTAL_ID).mapColor(class_3620.field_16026).noCollision().strength(-1.0F).sounds(class_2498.field_11537).luminance((state) -> 11).dropsNothing());
      cachedFrameBlocks = null;
      cachedPortalColors = null;
   }
}
