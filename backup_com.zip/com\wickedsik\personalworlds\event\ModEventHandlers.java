package com.wickedsik.personalworlds.event;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionManager;
import com.wickedsik.personalworlds.dimension.DimensionRecoveryScanner;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.portal.ConcurrentPortalGuard;
import com.wickedsik.personalworlds.portal.PortalHelper;
import com.wickedsik.personalworlds.recovery.CrashRecoveryHandler;
import com.wickedsik.personalworlds.registry.ModBlocks;
import com.wickedsik.personalworlds.util.PerformanceMonitor;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.server.MinecraftServer;

public class ModEventHandlers {
   private static int tickCounter = 0;
   private static final int UNLOAD_CHECK_INTERVAL = 600;
   private static int guardCleanupCounter = 0;
   private static final int GUARD_CLEANUP_INTERVAL = 200;
   private static final int VOID_EJECTION_THRESHOLD = 0;

   public static void register() {
      ServerLifecycleEvents.SERVER_STARTED.register(ModEventHandlers::onServerStarted);
      ServerLifecycleEvents.SERVER_STOPPING.register(ModEventHandlers::onServerStopping);
      ServerTickEvents.END_SERVER_TICK.register(ModEventHandlers::onServerTick);
      UseBlockCallback.EVENT.register(ModEventHandlers::onUseBlock);
      ServerPlayConnectionEvents.JOIN.register((ServerPlayConnectionEvents.Join)(handler, sender, server) -> CrashRecoveryHandler.onPlayerJoin(handler.method_32311()));
      ServerPlayConnectionEvents.DISCONNECT.register((ServerPlayConnectionEvents.Disconnect)(handler, server) -> ConcurrentPortalGuard.forceRelease(handler.method_32311().method_5667()));
      PersonalWorldsMod.LOGGER.info("Event handlers registered");
   }

   private static void onServerStarted(MinecraftServer server) {
      PersonalWorldsMod.LOGGER.info("Server started - scanning for orphaned dimensions");
      DimensionRecoveryScanner.scanAndRecover(server);
      PersonalWorldsMod.LOGGER.info("Restoring player dimensions from registry");
      DimensionRegistry.get(server).restoreAllDimensions(server);
   }

   private static void onServerStopping(MinecraftServer server) {
      PersonalWorldsMod.LOGGER.info("Server stopping - unloading all dimensions");
      DimensionManager.unloadAll();
   }

   private static void onServerTick(MinecraftServer server) {
      checkVoidFalling(server);
      ++tickCounter;
      if (tickCounter >= 600) {
         tickCounter = 0;
         DimensionManager.unloadEmptyDimensions();
         PerformanceMonitor.logStatus(server);
      }

      ++guardCleanupCounter;
      if (guardCleanupCounter >= 200) {
         guardCleanupCounter = 0;
         ConcurrentPortalGuard.cleanup();
      }

   }

   private static void checkVoidFalling(MinecraftServer server) {
      for(class_3222 player : server.method_3760().method_14571()) {
         class_3218 world = EntityCompat.getServerWorld(player);
         if (PortalHelper.isInPersonalDimension(world) && player.method_23318() <= (double)0.0F) {
            player.field_6017 = 0.0F;
            PortalHelper.teleportToReturnPosition(player, server);
            player.method_7353(class_2561.method_43471("pocketislands.void_ejection"), false);
            PersonalWorldsMod.LOGGER.info("Player {} fell off island and was ejected at Y={}", player.method_5477().getString(), player.method_23318());
         }
      }

   }

   private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
      if (world.method_8608()) {
         return class_1269.field_5811;
      } else if (!(player instanceof class_3222)) {
         return class_1269.field_5811;
      } else {
         class_3222 serverPlayer = (class_3222)player;
         class_1799 heldItem = player.method_5998(hand);
         class_2338 clickedPos = hitResult.method_17777();
         class_2680 clickedState = world.method_8320(clickedPos);
         boolean clickedOnFrame = false;

         for(int i = 0; i < ModConfig.get().portalTypes.size(); ++i) {
            if (clickedState.method_26204() == ModBlocks.getFrameBlock(i)) {
               clickedOnFrame = true;
               break;
            }
         }

         class_2338 targetPos;
         if (clickedOnFrame) {
            targetPos = clickedPos.method_10093(hitResult.method_17780());
         } else {
            targetPos = clickedPos;
         }

         if (!world.method_8320(targetPos).method_26215()) {
            return class_1269.field_5811;
         } else {
            return PortalHelper.tryActivatePortal(world, targetPos, serverPlayer, heldItem.method_7909()) ? class_1269.field_5812 : class_1269.field_5811;
         }
      }
   }
}
