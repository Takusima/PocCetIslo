package com.wickedsik.personalworlds.dimension;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.server.MinecraftServer;

public class DimensionRecoveryScanner {
   private static final String FOLDER_PREFIX = "pw_";

   public static ScanResult scanAndRecover(MinecraftServer server) {
      Path dimensionsRoot = DimensionMetadataFile.getDimensionsRootPath(server);
      if (Files.exists(dimensionsRoot, new LinkOption[0]) && Files.isDirectory(dimensionsRoot, new LinkOption[0])) {
         List<UUID> discoveredUuids = discoverDimensionFolders(dimensionsRoot);
         if (discoveredUuids.isEmpty()) {
            PersonalWorldsMod.LOGGER.debug("No dimension folders found in {}", dimensionsRoot);
            return new ScanResult(0, 0, 0, 0, 0);
         } else {
            PersonalWorldsMod.LOGGER.info("Found {} dimension folder(s) on disk, checking registry...", discoveredUuids.size());
            DimensionRegistry registry = DimensionRegistry.get(server);
            int alreadyRegistered = 0;
            int recoveredFromMetadata = 0;
            int recoveredMinimal = 0;
            int failedRecovery = 0;

            for(UUID playerUuid : discoveredUuids) {
               if (registry.hasDimension(playerUuid)) {
                  ++alreadyRegistered;
               } else {
                  PersonalWorldsMod.LOGGER.info("Found orphaned dimension for UUID: {}", playerUuid);
                  RecoveryResult result = recoverDimension(server, registry, playerUuid);
                  switch (result.ordinal()) {
                     case 0:
                        ++recoveredFromMetadata;
                        break;
                     case 1:
                        ++recoveredMinimal;
                        break;
                     case 2:
                        ++failedRecovery;
                  }
               }
            }

            ScanResult scanResult = new ScanResult(discoveredUuids.size(), alreadyRegistered, recoveredFromMetadata, recoveredMinimal, failedRecovery);
            logScanResults(scanResult);
            return scanResult;
         }
      } else {
         PersonalWorldsMod.LOGGER.debug("No personalworlds dimensions folder found at {}", dimensionsRoot);
         return new ScanResult(0, 0, 0, 0, 0);
      }
   }

   private static List<UUID> discoverDimensionFolders(Path dimensionsRoot) {
      List<UUID> uuids = new ArrayList();

      try {
         DirectoryStream<Path> stream = Files.newDirectoryStream(dimensionsRoot);

         try {
            for(Path folder : stream) {
               if (Files.isDirectory(folder, new LinkOption[0])) {
                  String folderName = folder.getFileName().toString();
                  if (!folderName.startsWith("pw_")) {
                     PersonalWorldsMod.LOGGER.debug("Skipping non-dimension folder: {}", folderName);
                  } else {
                     Optional<UUID> uuid = parseFolderUuid(folderName);
                     if (uuid.isPresent()) {
                        uuids.add((UUID)uuid.get());
                     } else {
                        PersonalWorldsMod.LOGGER.warn("Could not parse UUID from folder name: {}", folderName);
                     }
                  }
               }
            }
         } catch (Throwable var8) {
            if (stream != null) {
               try {
                  stream.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stream != null) {
            stream.close();
         }
      } catch (IOException e) {
         PersonalWorldsMod.LOGGER.error("Failed to scan dimensions folder: {}", e.getMessage());
      }

      return uuids;
   }

   private static Optional<UUID> parseFolderUuid(String folderName) {
      if (!folderName.startsWith("pw_")) {
         return Optional.empty();
      } else {
         String hexPart = folderName.substring("pw_".length());
         if (hexPart.length() != 32) {
            return Optional.empty();
         } else if (!hexPart.matches("[0-9a-fA-F]+")) {
            return Optional.empty();
         } else {
            try {
               String var10000 = hexPart.substring(0, 8);
               String uuidString = var10000 + "-" + hexPart.substring(8, 12) + "-" + hexPart.substring(12, 16) + "-" + hexPart.substring(16, 20) + "-" + hexPart.substring(20);
               return Optional.of(UUID.fromString(uuidString));
            } catch (IllegalArgumentException var3) {
               return Optional.empty();
            }
         }
      }
   }

   private static RecoveryResult recoverDimension(MinecraftServer server, DimensionRegistry registry, UUID playerUuid) {
      Optional<PlayerDimensionData> metadataOpt = DimensionMetadataFile.read(server, playerUuid);
      if (metadataOpt.isPresent()) {
         PlayerDimensionData data = (PlayerDimensionData)metadataOpt.get();
         registry.registerDimension(data);
         PersonalWorldsMod.LOGGER.info("Recovered dimension for {} ({}) from metadata file", data.ownerName(), playerUuid);
         return DimensionRecoveryScanner.RecoveryResult.FROM_METADATA;
      } else {
         PersonalWorldsMod.LOGGER.warn("No metadata file for {}, creating minimal recovery entry", playerUuid);

         try {
            PlayerDimensionData minimalData = createMinimalRecoveryData(server, playerUuid);
            registry.registerDimension(minimalData);
            PersonalWorldsMod.LOGGER.info("Created minimal recovery entry for {} (owner name unknown)", playerUuid);
            return DimensionRecoveryScanner.RecoveryResult.MINIMAL;
         } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to create recovery entry for {}: {}", playerUuid, e.getMessage());
            return DimensionRecoveryScanner.RecoveryResult.FAILED;
         }
      }
   }

   private static PlayerDimensionData createMinimalRecoveryData(MinecraftServer server, UUID playerUuid) {
      long createdAt = getApproximateCreationTime(server, playerUuid);
      String shortUuid = playerUuid.toString().substring(0, 8);
      String unknownName = "Unknown (" + shortUuid + ")";
      String var10000 = playerUuid.toString();
      String dimIdPath = "pw_" + var10000.replace("-", "");
      class_2960 dimensionId = IdentifierCompat.modId(dimIdPath);
      class_2338 spawnPoint = new class_2338(0, 65, 0);
      WorldGenType genType = WorldGenType.VOID;
      return new PlayerDimensionData(playerUuid, unknownName, dimensionId, createdAt, spawnPoint, genType, 0);
   }

   private static long getApproximateCreationTime(MinecraftServer server, UUID playerUuid) {
      Path folderPath = DimensionMetadataFile.getDimensionFolderPath(server, playerUuid);

      try {
         BasicFileAttributes attrs = Files.readAttributes(folderPath, BasicFileAttributes.class);
         return attrs.creationTime().toMillis();
      } catch (IOException var4) {
         return System.currentTimeMillis();
      }
   }

   private static void logScanResults(ScanResult result) {
      if (result.totalFoldersFound() != 0) {
         if (result.hasRecoveries()) {
            PersonalWorldsMod.LOGGER.info("Dimension recovery complete: {} recovered ({} from metadata, {} minimal), {} already registered, {} failed", new Object[]{result.totalRecovered(), result.recoveredFromMetadata(), result.recoveredMinimal(), result.alreadyRegistered(), result.failedRecovery()});
            if (result.recoveredMinimal() > 0) {
               PersonalWorldsMod.LOGGER.warn("{} dimension(s) were recovered with minimal data (owner unknown, defaulted to VOID type). Players may need to reclaim these dimensions.", result.recoveredMinimal());
            }
         } else {
            PersonalWorldsMod.LOGGER.debug("Dimension scan: {} folder(s) found, all {} already registered", result.totalFoldersFound(), result.alreadyRegistered());
         }

      }
   }

   public static record ScanResult(int totalFoldersFound, int alreadyRegistered, int recoveredFromMetadata, int recoveredMinimal, int failedRecovery) {
      public int totalRecovered() {
         return this.recoveredFromMetadata + this.recoveredMinimal;
      }

      public boolean hasRecoveries() {
         return this.totalRecovered() > 0;
      }
   }

   private static enum RecoveryResult {
      FROM_METADATA,
      MINIMAL,
      FAILED;

      // $FF: synthetic method
      private static RecoveryResult[] $values() {
         return new RecoveryResult[]{FROM_METADATA, MINIMAL, FAILED};
      }
   }
}
