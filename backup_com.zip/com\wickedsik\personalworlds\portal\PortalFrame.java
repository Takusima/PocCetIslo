package com.wickedsik.personalworlds.portal;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;

public record PortalFrame(class_2338 bottomLeft, int width, int height, class_2350.class_2351 axis) {
   public List<class_2338> getInteriorPositions() {
      List<class_2338> positions = new ArrayList();
      class_2350 horizontal = this.axis == class_2351.field_11048 ? class_2350.field_11034 : class_2350.field_11035;
      class_2338 start = this.bottomLeft.method_10084().method_10093(horizontal);

      for(int h = 0; h < this.height; ++h) {
         for(int w = 0; w < this.width; ++w) {
            class_2338 pos = start.method_10086(h).method_10079(horizontal, w);
            positions.add(pos);
         }
      }

      return positions;
   }

   public List<class_2338> getFramePositions() {
      List<class_2338> positions = new ArrayList();
      class_2350 horizontal = this.axis == class_2351.field_11048 ? class_2350.field_11034 : class_2350.field_11035;
      int frameWidth = this.width + 2;
      int frameHeight = this.height + 2;

      for(int w = 0; w < frameWidth; ++w) {
         positions.add(this.bottomLeft.method_10079(horizontal, w));
      }

      for(int w = 0; w < frameWidth; ++w) {
         positions.add(this.bottomLeft.method_10086(frameHeight - 1).method_10079(horizontal, w));
      }

      for(int h = 1; h < frameHeight - 1; ++h) {
         positions.add(this.bottomLeft.method_10086(h));
      }

      for(int h = 1; h < frameHeight - 1; ++h) {
         positions.add(this.bottomLeft.method_10079(horizontal, frameWidth - 1).method_10086(h));
      }

      return positions;
   }

   public class_2338 getCenter() {
      class_2350 horizontal = this.axis == class_2351.field_11048 ? class_2350.field_11034 : class_2350.field_11035;
      return this.bottomLeft.method_10086(1 + this.height / 2).method_10079(horizontal, 1 + this.width / 2);
   }
}
