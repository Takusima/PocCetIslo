package com.wickedsik.personalworlds.network;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.command.service.PlayerLookupService;
import com.wickedsik.personalworlds.command.service.TeleportHelper;
import com.wickedsik.personalworlds.compat.CommandCompat;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.compat.TextCompat;
import com.wickedsik.personalworlds.compat.VoiceChatCompatibility;
import com.wickedsik.personalworlds.compat.WorldCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import com.wickedsik.personalworlds.player.ReturnData;
import com.wickedsik.personalworlds.portal.PortalColor;
import com.wickedsik.personalworlds.portal.PortalHelper;
import com.wickedsik.personalworlds.util.VisualEffects;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

import java.util.Optional;
import java.util.UUID;

/**
 * Обработчик серверных сетевых пакетов.
 * Содержит логику обработки команд Prunus/Malus, смены цвета портала,
 * отправки и ответа на приглашения.
 */
public final class NetworkHandler {

    // Стоимость команд
    private static final int PRUNUS_XP_COST = 2;
    private static final int PRUNUS_FOOD_COST = 3;
    private static final int MALUS_XP_COST = 2;
    private static final int MALUS_FOOD_COST = 3;

    private NetworkHandler() {
        // Utility class
    }

    // ============================================================
    //  Обработка команды Prunus (вход в карманное измерение)
    // ============================================================

    public static void handlePrunusCommand(class_3222 player) {
        PersonalWorldsMod.LOGGER.info("Player {} attempting Prunus command", player.method_5477().getString());

        // Проверка стоимости команды
        if (!canAffordCommand(player, PRUNUS_XP_COST, PRUNUS_FOOD_COST)) {
            sendCommandResult(player, false, "pocketislands.command.prunus.not_enough_resources");
            return;
        }

        // Проверка, что игрок не в карманном измерении
        class_3218 currentWorld = EntityCompat.getServerWorld(player);
        if (PortalHelper.isInPersonalDimension(currentWorld)) {
            sendCommandResult(player, false, "pocketislands.command.prunus.already_in_dimension");
            return;
        }

        // Списание ресурсов (2 уровня опыта, 3 единицы голода)
        deductCommandCost(player, PRUNUS_XP_COST, PRUNUS_FOOD_COST);

        // Сохранение данных для возврата
        saveReturnData(player);

        // Кинематографическая последовательность начала телепортации:
        // 1. Красные редстоун-частицы (магический туман)
        // 2. Эффект Blindness III (затемнение экрана)
        // 3. Звук телепортации
        VisualEffects.playTeleportSequenceStart(player);

        // Телепортация в карманное измерение
        MinecraftServer server = EntityCompat.getServer(player);
        if (server != null) {
            DimensionRegistry registry = DimensionRegistry.get(server);
            Optional<class_3218> dimensionOpt = registry.getPlayerDimension(server, player.method_5667());

            if (dimensionOpt.isPresent()) {
                class_3218 targetWorld = dimensionOpt.get();
                class_243 spawnPos = class_243.method_24953(WorldCompat.getSpawnPos(targetWorld));

                TeleportCompat.teleport(player, targetWorld, spawnPos, player.method_36454(), player.method_36455());

                // Кинематографическая последовательность завершения телепортации:
                // 1. Красные редстоун-частицы (магический туман)
                // 2. Удаление эффекта Blindness (игрок снова видит)
                // 3. Эффект Nausea на 10 секунд (налог за телепортацию)
                // 4. Звук прибытия
                VisualEffects.playTeleportSequenceEnd(player);
                VisualEffects.playDimensionEntryEffect(player);

                sendCommandResult(player, true, "pocketislands.command.prunus.success");
                PersonalWorldsMod.LOGGER.info("Player {} entered their pocket dimension via Prunus", player.method_5477().getString());
            } else {
                // Восстанавливаем ресурсы при ошибке
                refundCommandCost(player, PRUNUS_XP_COST, PRUNUS_FOOD_COST);
                // Удаляем эффект слепоты при ошибке
                VisualEffects.removeBlindnessEffect(player);
                sendCommandResult(player, false, "pocketislands.command.prunus.no_dimension");
                PersonalWorldsMod.LOGGER.warn("Player {} has no pocket dimension", player.method_5477().getString());
            }
        }
    }

    // ============================================================
    //  Обработка команды Malus (выход из карманного измерения)
    // ============================================================

    public static void handleMalusCommand(class_3222 player) {
        PersonalWorldsMod.LOGGER.info("Player {} attempting Malus command", player.method_5477().getString());

        // Проверка стоимости команды
        if (!canAffordCommand(player, MALUS_XP_COST, MALUS_FOOD_COST)) {
            sendCommandResult(player, false, "pocketislands.command.malus.not_enough_resources");
            return;
        }

        // Проверка, что игрок в карманном измерении
        class_3218 currentWorld = EntityCompat.getServerWorld(player);
        if (!PortalHelper.isInPersonalDimension(currentWorld)) {
            sendCommandResult(player, false, "pocketislands.command.malus.not_in_dimension");
            return;
        }

        // Списание ресурсов (2 уровня опыта, 3 единицы голода)
        deductCommandCost(player, MALUS_XP_COST, MALUS_FOOD_COST);

        // Кинематографическая последовательность начала телепортации:
        // 1. Красные редстоун-частицы (магический туман)
        // 2. Эффект Blindness III (затемнение экрана)
        // 3. Звук телепортации
        VisualEffects.playTeleportSequenceStart(player);

        // Загрузка данных для возврата
        MinecraftServer server = EntityCompat.getServer(player);
        if (server != null) {
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            Optional<ReturnData> returnDataOpt = dataManager.getReturnData(player.method_5667());

            class_3218 targetWorld;
            class_243 targetPos;
            float yaw;
            float pitch;

            if (returnDataOpt.isPresent()) {
                ReturnData returnData = returnDataOpt.get();
                targetWorld = server.method_3847(returnData.dimension());
                if (targetWorld == null) {
                    targetWorld = server.method_30002(); // Overworld
                    targetPos = class_243.method_24953(WorldCompat.getSpawnPos(targetWorld));
                } else {
                    targetPos = class_243.method_24953(returnData.position());
                }
                yaw = returnData.yaw();
                pitch = returnData.pitch();
                dataManager.clearReturnData(player.method_5667());
            } else {
                targetWorld = server.method_30002(); // Overworld
                targetPos = class_243.method_24953(WorldCompat.getSpawnPos(targetWorld));
                yaw = player.method_36454();
                pitch = player.method_36455();
            }

            TeleportCompat.teleport(player, targetWorld, targetPos, yaw, pitch);

            // Кинематографическая последовательность завершения телепортации:
            // 1. Красные редстоун-частицы (магический туман)
            // 2. Удаление эффекта Blindness (игрок снова видит)
            // 3. Эффект Nausea на 10 секунд (налог за телепортацию)
            // 4. Звук прибытия
            VisualEffects.playTeleportSequenceEnd(player);
            VisualEffects.playDimensionExitEffect(player);

            // Удаляем игрока из всех групп голосового чата
            VoiceChatCompatibility.removePlayerFromAllVoiceGroups(player.method_5667());

            sendCommandResult(player, true, "pocketislands.command.malus.success");
            PersonalWorldsMod.LOGGER.info("Player {} returned to overworld via Malus", player.method_5477().getString());
        }
    }

    // ============================================================
    //  Обработка смены цвета портала
    // ============================================================

    public static void handleChangePortalColor(class_3222 player, String colorName) {
        PersonalWorldsMod.LOGGER.info("Player {} changing portal color to {}", player.method_5477().getString(), colorName);

        PortalColor newColor = PortalColor.fromString(colorName);
        if (newColor == null) {
            PersonalWorldsMod.LOGGER.warn("Invalid portal color: {}", colorName);
            return;
        }

        // Сохранение цвета в данных игрока
        MinecraftServer server = EntityCompat.getServer(player);
        if (server != null) {
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            dataManager.setPortalColor(player.method_5667(), newColor);

            // Уведомление игрока
            class_2561 message = class_2561.method_43469("pocketislands.gui.color_changed", new Object[]{
                class_2561.method_43471("pocketislands.portal.color." + newColor.method_15434())
            }).method_27692(class_124.field_1060);
            player.method_7353(message, true);

            // Синхронизация с клиентом
            syncPortalColorToClient(player, newColor, player.method_5477().getString());

            PersonalWorldsMod.LOGGER.info("Portal color changed to {} for player {}", newColor.method_15434(), player.method_5477().getString());
        }
    }

    // ============================================================
    //  Обработка отправки приглашения
    // ============================================================

    public static void handleInvitationRequest(class_3222 sender, String targetName) {
        PersonalWorldsMod.LOGGER.info("Player {} sending invitation request to {}", sender.method_5477().getString(), targetName);

        MinecraftServer server = EntityCompat.getServer(sender);
        if (server == null) return;

        Optional<class_3222> targetOpt = PlayerLookupService.findPlayer(server, targetName);
        if (targetOpt.isEmpty()) {
            sendCommandResult(sender, false, "pocketislands.invitation.target_not_found");
            return;
        }

        class_3222 target = targetOpt.get();
        String senderName = sender.method_5477().getString();

        // Нельзя пригласить самого себя
        if (sender.method_5667().equals(target.method_5667())) {
            sendCommandResult(sender, false, "pocketislands.invitation.cannot_invite_self");
            return;
        }

        // Отправка запроса целевому игроку
        sendVisitRequest(target, senderName);

        // Уведомление отправителя
        sendCommandResult(sender, true, "pocketislands.invitation.request_sent");
    }

    // ============================================================
    //  Обработка ответа на приглашение
    // ============================================================

    public static void handleInvitationResponse(class_3222 responder, String senderName, boolean accepted) {
        PersonalWorldsMod.LOGGER.info("Player {} responding to invitation from {}: {}",
            responder.method_5477().getString(), senderName, accepted ? "ACCEPTED" : "DENIED");

        MinecraftServer server = EntityCompat.getServer(responder);
        if (server == null) return;

        Optional<class_3222> senderOpt = PlayerLookupService.findPlayer(server, senderName);
        if (senderOpt.isEmpty()) {
            sendCommandResult(responder, false, "pocketislands.invitation.sender_not_found");
            return;
        }

        class_3222 sender = senderOpt.get();

        if (accepted) {
            // Телепортация отправителя к хозяину измерения
            class_3218 responderWorld = EntityCompat.getServerWorld(responder);
            class_243 responderPos = EntityCompat.getPos(responder);

            // Сохранение данных для возврата
            saveReturnData(sender);

            // Кинематографическая последовательность начала телепортации
            VisualEffects.playTeleportSequenceStart(sender);

            // Телепортация
            TeleportCompat.teleport(sender, responderWorld, responderPos, sender.method_36454(), sender.method_36455());

            // Кинематографическая последовательность завершения телепортации
            VisualEffects.playTeleportSequenceEnd(sender);

            // Интеграция с Simple Voice Chat - создание аудио-группы
            boolean voiceGroupCreated = VoiceChatCompatibility.createVoiceGroup(responder, sender);
            if (voiceGroupCreated) {
                PersonalWorldsMod.LOGGER.info("Created voice chat group for players {} and {}",
                    responder.method_5477().getString(), sender.method_5477().getString());
            } else {
                PersonalWorldsMod.LOGGER.debug("Voice chat group not created (Simple Voice Chat may not be installed)");
            }

            // Уведомления
            sendCommandResult(sender, true, "pocketislands.invitation.teleported_to_owner");
            sendCommandResult(responder, true, "pocketislands.invitation.accepted_sender");

            PersonalWorldsMod.LOGGER.info("Player {} teleported to {}'s location",
                sender.method_5477().getString(), responder.method_5477().getString());
        } else {
            // Уведомление отправителя об отказе
            sendVisitDenied(sender, responder.method_5477().getString(), "pocketislands.invitation.denied");
            sendCommandResult(responder, true, "pocketislands.invitation.declined");
        }
    }

    // ============================================================
    //  Обработка открытия GUI
    // ============================================================

    public static void handleOpenGui(class_3222 player) {
        PersonalWorldsMod.LOGGER.info("Player {} opening Pocket Dimension GUI", player.method_5477().getString());

        MinecraftServer server = EntityCompat.getServer(player);
        if (server == null) return;

        // Получение списка онлайн игроков
        java.util.List<String> playerNames = new java.util.ArrayList<>();
        for (class_3222 onlinePlayer : server.method_3760().method_14571()) {
            if (!onlinePlayer.method_5667().equals(player.method_5667())) {
                playerNames.add(onlinePlayer.method_5477().getString());
            }
        }

        // Отправка списка игроку
        sendPlayerListSync(player, playerNames);

        // Открытие GUI на клиенте
        sendOpenGui(player);
    }

    // ============================================================
    //  Вспомогательные методы
    // ============================================================

    private static boolean canAffordCommand(class_3222 player, int xpCost, int foodCost) {
        return player.field_7503 >= xpCost && player.method_7344().method_7586() >= foodCost;
    }

    private static void deductCommandCost(class_3222 player, int xpCost, int foodCost) {
        // Списание уровней опыта (2 уровня)
        player.method_7272(-xpCost); // addLevels
        // Списание единиц голода (3 единицы)
        player.method_7344().method_7580(player.method_7344().method_7586() - foodCost); // setFoodLevel
    }

    /**
     * Возвращает ресурсы игроку при ошибке телепортации.
     *
     * @param player Игрок
     * @param xpCost Количество уровней опыта для возврата
     * @param foodCost Количество единиц голода для возврата
     */
    private static void refundCommandCost(class_3222 player, int xpCost, int foodCost) {
        // Возврат уровней опыта
        player.method_7272(xpCost); // addLevels
        // Возврат единиц голода
        player.method_7344().method_7580(player.method_7344().method_7586() + foodCost); // setFoodLevel
    }

    private static void saveReturnData(class_3222 player) {
        MinecraftServer server = EntityCompat.getServer(player);
        if (server != null) {
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            class_3218 world = EntityCompat.getServerWorld(player);
            class_243 pos = EntityCompat.getPos(player);
            ReturnData returnData = new ReturnData(
                world.method_27983().method_29177(),
                new net.minecraft.class_2338((int) pos.field_1352, (int) pos.field_1351, (int) pos.field_1350),
                player.method_36454(),
                player.method_36455()
            );
            dataManager.setReturnData(player.method_5667(), returnData);
        }
    }

    // ============================================================
    //  Отправка пакетов клиенту
    // ============================================================

    private static void sendCommandResult(class_3222 player, boolean success, String messageKey) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10794(success); // writeBoolean
        buf.method_10804(messageKey); // writeString
        ServerPlayNetworking.send(player, ModNetworking.COMMAND_RESULT, buf);
    }

    private static void sendVisitRequest(class_3222 target, String requesterName) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(requesterName); // writeString
        ServerPlayNetworking.send(target, ModNetworking.VISIT_REQUEST, buf);
    }

    private static void sendVisitDenied(class_3222 target, String ownerName, String reasonKey) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(ownerName); // writeString
        buf.method_10804(reasonKey); // writeString
        ServerPlayNetworking.send(target, ModNetworking.VISIT_DENIED, buf);
    }

    private static void sendPlayerListSync(class_3222 player, java.util.List<String> playerNames) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10819(playerNames.size()); // writeVarInt
        for (String name : playerNames) {
            buf.method_10804(name); // writeString
        }
        ServerPlayNetworking.send(player, ModNetworking.SYNC_PLAYER_LIST, buf);
    }

    private static void syncPortalColorToClient(class_3222 player, PortalColor color, String playerName) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(color.method_15434()); // writeString
        buf.method_10804(playerName); // writeString
        ServerPlayNetworking.send(player, ModNetworking.PORTAL_COLOR_CHANGED, buf);
    }

    private static void sendOpenGui(class_3222 player) {
        class_2540 buf = ModNetworking.createBuf();
        ServerPlayNetworking.send(player, ModNetworking.OPEN_GUI, buf);
    }
}
