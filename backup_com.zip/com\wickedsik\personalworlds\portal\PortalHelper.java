package com.wickedsik.personalworlds.portal;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.compat.WorldCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionManager;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.dimension.WorldGenType;
import com.wickedsik.personalworlds.player.InvitationManager;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import com.wickedsik.personalworlds.player.ReturnData;
import com.wickedsik.personalworlds.player.VisitDenialReason;
import com.wickedsik.personalworlds.registry.ModBlocks;
import com.wickedsik.personalworlds.registry.ModItems;
import com.wickedsik.personalworlds.util.SafeSpawnFinder;
import com.wickedsik.personalworlds.util.VisualEffects;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_2350.class_2351;
import net.minecraft.server.MinecraftServer;

public class PortalHelper {
   private static final int PORTAL_WIDTH = 2;
   private static final int PORTAL_HEIGHT = 3;
   private static final int PLATFORM_RADIUS = 2;
   private static final int PLATFORM_Y = 64;
   private static final int PORTAL_SEARCH_RADIUS = 128;

   public static boolean tryActivatePortal(class_1937 world, class_2338 clickedPos, class_3222 player, class_1792 activationItem) {
      if (world.method_8608()) {
         return false;
      } else {
         MinecraftServer server = EntityCompat.getServer(player);
         if (server == null) {
            return false;
         } else {
            Optional<Integer> portalTypeOpt = detectPortalType(world, clickedPos, activationItem);
            if (portalTypeOpt.isEmpty()) {
               return false;
            } else {
               int portalTypeIndex = (Integer)portalTypeOpt.get();
               Optional<PortalFrame> frame = detectFrame(world, clickedPos, portalTypeIndex);
               if (frame.isEmpty()) {
                  return false;
               } else {
                  PortalFrame portalFrame = (PortalFrame)frame.get();
                  PortalColor color = ModBlocks.getPortalColor(portalTypeIndex);
                  class_2680 portalState = (class_2680)((class_2680)ModBlocks.PERSONAL_PORTAL.method_9564().method_11657(PersonalPortalBlock.AXIS, portalFrame.axis())).method_11657(PersonalPortalBlock.COLOR, color);

                  for(class_2338 pos : portalFrame.getInteriorPositions()) {
                     world.method_8501(pos, portalState);
                  }

                  PortalOwnershipManager ownershipManager = PortalOwnershipManager.get(server);

                  for(class_2338 pos : portalFrame.getInteriorPositions()) {
                     ownershipManager.registerPortal(world, pos, player.method_5667(), portalTypeIndex);
                  }

                  world.method_8396((class_1657)null, portalFrame.getCenter(), class_3417.field_14981, class_3419.field_15245, 1.0F, 1.0F);
                  VisualEffects.playPortalActivationEffects(world, portalFrame.getCenter());
                  PersonalWorldsMod.LOGGER.info("Portal type {} activated at {} by {} (ownership registered)", new Object[]{portalTypeIndex, clickedPos, player.method_5477().getString()});
                  return true;
               }
            }
         }
      }
   }

   public static void handlePortalEntry(class_3222 player, class_2338 portalPos) {
      MinecraftServer server = EntityCompat.getServer(player);
      if (server != null) {
         if (ConcurrentPortalGuard.tryAcquire(player, portalPos)) {
            try {
               class_3218 currentWorld = EntityCompat.getServerWorld(player);
               if (isInPersonalDimension(currentWorld)) {
                  teleportToReturnPosition(player, server);
               } else {
                  handleForwardPortalEntry(player, server, currentWorld, portalPos);
               }
            } finally {
               ConcurrentPortalGuard.release(player, portalPos);
            }

         }
      }
   }

   private static void handleForwardPortalEntry(class_3222 player, MinecraftServer server, class_3218 fromWorld, class_2338 portalPos) {
      PortalOwnershipManager ownershipManager = PortalOwnershipManager.get(server);
      Optional<UUID> portalOwnerOpt = ownershipManager.getOwner(fromWorld, portalPos);
      if (portalOwnerOpt.isEmpty()) {
         PersonalWorldsMod.LOGGER.warn("Unclaimed portal at {} - auto-claiming for {} with default portal type", portalPos, player.method_5477().getString());
         ownershipManager.registerPortal(fromWorld, portalPos, player.method_5667(), 0);
         teleportToOwnerDimension(player, server, fromWorld, player.method_5667(), 0);
      } else {
         UUID portalOwner = (UUID)portalOwnerOpt.get();
         int portalTypeIndex = (Integer)ownershipManager.getPortalType(fromWorld, portalPos).orElse(0);
         VisitDenialReason denialReason = InvitationManager.checkVisitAccess(server, player, portalOwner);
         if (denialReason.isAllowed()) {
            teleportToOwnerDimension(player, server, fromWorld, portalOwner, portalTypeIndex);
         } else {
            String ownerName = ownershipManager.getOwnerName(server, portalOwner);
            InvitationManager.notifyHostOfVisitAttempt(server, portalOwner, player.method_5477().getString(), denialReason);
            class_5250 var10000;
            switch (denialReason) {
               case NOT_INVITED -> var10000 = class_2561.method_43469("pocketislands.command.error.not_invited", new Object[]{ownerName});
               case HOST_OFFLINE -> var10000 = class_2561.method_43469("pocketislands.visit.denied.offline", new Object[]{ownerName});
               case HOST_NOT_HOME -> var10000 = class_2561.method_43469("pocketislands.visit.denied.not_home", new Object[]{ownerName});
               case ALLOWED -> var10000 = class_2561.method_43473();
               default -> throw new IncompatibleClassChangeError();
            }

            class_2561 denialMessage = var10000;
            player.method_7353(denialMessage.method_27661().method_27692(class_124.field_1061), false);
            PersonalWorldsMod.LOGGER.debug("{} denied entry to {}'s portal at {} (reason: {})", new Object[]{player.method_5477().getString(), ownerName, portalPos, denialReason});
         }

      }
   }

   private static boolean teleportToOwnerDimension(class_3222 player, MinecraftServer server, class_3218 fromWorld, UUID ownerUuid, int portalTypeIndex) {
      UUID playerUuid = player.method_5667();
      boolean isOwnDimension = playerUuid.equals(ownerUuid);
      DimensionRegistry registry = DimensionRegistry.get(server);
      Optional<PlayerDimensionData> dimDataOpt = registry.getDimensionData(ownerUuid);
      String ownerName;
      WorldGenType genType;
      if (dimDataOpt.isPresent()) {
         PlayerDimensionData dimData = (PlayerDimensionData)dimDataOpt.get();
         ownerName = dimData.ownerName();
         genType = dimData.generatorType();
      } else {
         if (!isOwnDimension) {
            PortalOwnershipManager ownershipManager = PortalOwnershipManager.get(server);
            String deletedOwnerName = ownershipManager.getOwnerName(server, ownerUuid);
            player.method_7353(class_2561.method_43470("This portal's dimension no longer exists. ").method_10852(class_2561.method_43470(deletedOwnerName).method_27692(class_124.field_1054)).method_27693("'s world was deleted.").method_27692(class_124.field_1061), false);
            PersonalWorldsMod.LOGGER.info("Player {} tried to enter deleted dimension of {}", player.method_5477().getString(), deletedOwnerName);
            return false;
         }

         ownerName = player.method_5477().getString();
         genType = WorldGenType.VOID;
      }

      PlayerDataManager dataManager = PlayerDataManager.get(server);
      if (!isInPersonalDimension(fromWorld)) {
         class_2338 returnPos = player.method_24515().method_10093(player.method_5735().method_10153());
         ReturnData returnData = new ReturnData(fromWorld.method_27983(), returnPos, player.method_36454(), player.method_36455());
         dataManager.setReturnData(playerUuid, returnData);
      }

      class_3218 targetWorld = DimensionManager.getOrCreatePlayerDimension(server, ownerUuid, ownerName, genType, portalTypeIndex);
      class_2338 destinationPos = (class_2338)findExistingPortal(targetWorld).map((portalPos) -> findSafePositionNearPortal(targetWorld, portalPos)).orElseGet(() -> getOrCreateSpawnPlatform(targetWorld, genType, portalTypeIndex));
      dataManager.setCurrentPocketDimension(playerUuid, targetWorld.method_27983());
      VisualEffects.playTeleportDepartureEffects(player);
      TeleportCompat.teleportToBlockPreserveRotation(player, targetWorld, destinationPos);
      VisualEffects.playTeleportArrivalEffects(player);
      VisualEffects.playDimensionEntryEffect(player);
      if (isOwnDimension) {
         player.method_7353(class_2561.method_43470("Welcome to your pocket island!"), true);
         PersonalWorldsMod.LOGGER.info("Player {} entered their personal dimension", player.method_5477().getString());
      } else {
         player.method_7353(class_2561.method_43470("Entering ").method_10852(class_2561.method_43470(ownerName).method_27692(class_124.field_1054)).method_27693("'s island"), true);
         PersonalWorldsMod.LOGGER.info("Player {} entered {}'s personal dimension", player.method_5477().getString(), ownerName);
      }

      return true;
   }

   private static String getPlayerName(MinecraftServer server, UUID playerUuid) {
      class_3222 player = server.method_3760().method_14602(playerUuid);
      return player != null ? player.method_5477().getString() : playerUuid.toString().substring(0, 8);
   }

   public static void teleportToReturnPosition(class_3222 player, MinecraftServer server) {
      UUID playerUuid = player.method_5667();
      PlayerDataManager dataManager = PlayerDataManager.get(server);
      Optional<ReturnData> returnDataOpt = dataManager.getReturnData(playerUuid);
      class_3218 targetWorld;
      class_243 targetPos;
      float yaw;
      float pitch;
      if (returnDataOpt.isPresent()) {
         ReturnData returnData = (ReturnData)returnDataOpt.get();
         targetWorld = server.method_3847(returnData.dimension());
         if (targetWorld == null) {
            PersonalWorldsMod.LOGGER.warn("Return dimension not found for player {}, using overworld", player.method_5477().getString());
            targetWorld = server.method_30002();
            targetPos = class_243.method_24953(SafeSpawnFinder.findSafePosition(targetWorld, WorldCompat.getSpawnPos(targetWorld)));
            yaw = player.method_36454();
            pitch = player.method_36455();
         } else if (!SafeSpawnFinder.isSafeSpawn(targetWorld, returnData.position())) {
            class_2338 safePos = SafeSpawnFinder.findSafePosition(targetWorld, returnData.position());
            targetPos = class_243.method_24953(safePos);
            yaw = returnData.yaw();
            pitch = returnData.pitch();
            PersonalWorldsMod.LOGGER.info("Return position unsafe, relocated player {} to {}", player.method_5477().getString(), safePos);
         } else {
            targetPos = class_243.method_24953(returnData.position());
            yaw = returnData.yaw();
            pitch = returnData.pitch();
         }

         dataManager.clearReturnData(playerUuid);
      } else {
         class_2338 bedPos = EntityCompat.getSpawnPointPosition(player);
         class_3218 bedWorld = null;
         if (bedPos != null) {
            bedWorld = server.method_3847(EntityCompat.getSpawnPointDimension(player));
         }

         if (bedWorld != null) {
            class_2338 safePos = SafeSpawnFinder.findSafePosition(bedWorld, bedPos);
            targetWorld = bedWorld;
            targetPos = class_243.method_24953(safePos);
            yaw = player.method_36454();
            pitch = player.method_36455();
            PersonalWorldsMod.LOGGER.debug("No return data for player {}, using bed spawn at {}", player.method_5477().getString(), safePos);
         } else {
            PersonalWorldsMod.LOGGER.debug("No return data for player {}, using overworld spawn", player.method_5477().getString());
            targetWorld = server.method_30002();
            targetPos = class_243.method_24953(SafeSpawnFinder.findSafePosition(targetWorld, WorldCompat.getSpawnPos(targetWorld)));
            yaw = player.method_36454();
            pitch = player.method_36455();
         }
      }

      dataManager.clearCurrentPocketDimension(playerUuid);
      VisualEffects.playTeleportDepartureEffects(player);
      VisualEffects.playDimensionExitEffect(player);
      TeleportCompat.teleport(player, targetWorld, targetPos, yaw, pitch);
      VisualEffects.playTeleportArrivalEffects(player);
      player.method_7353(class_2561.method_43470("Returned to the overworld"), true);
      PersonalWorldsMod.LOGGER.info("Player {} left personal dimension", player.method_5477().getString());
   }

   public static boolean teleportToDimension(class_3222 player, MinecraftServer server, UUID ownerUuid) {
      class_3218 currentWorld = EntityCompat.getServerWorld(player);
      if (isInPersonalDimension(currentWorld)) {
         String dimPath = currentWorld.method_27983().method_29177().method_12832();
         String targetPath = "pw_" + ownerUuid.toString();
         if (dimPath.equals(targetPath)) {
            player.method_7353(class_2561.method_43470("You are already in this dimension!").method_27692(class_124.field_1061), false);
            return false;
         }
      }

      DimensionRegistry registry = DimensionRegistry.get(server);
      int portalTypeIndex = (Integer)registry.getDimensionData(ownerUuid).map(PlayerDimensionData::portalTypeIndex).orElse(0);
      return teleportToOwnerDimension(player, server, currentWorld, ownerUuid, portalTypeIndex);
   }

   public static boolean isInPersonalDimension(class_3218 world) {
      String namespace = world.method_27983().method_29177().method_12836();
      String path = world.method_27983().method_29177().method_12832();
      return "personalworlds".equals(namespace) && path.startsWith("pw_");
   }

   public static Optional<UUID> getDimensionOwner(class_3218 world) {
      if (!isInPersonalDimension(world)) {
         return Optional.empty();
      } else {
         String path = world.method_27983().method_29177().method_12832();
         String uuidStr = path.substring(3);
         if (uuidStr.length() == 32 && !uuidStr.contains("-")) {
            String var10000 = uuidStr.substring(0, 8);
            uuidStr = var10000 + "-" + uuidStr.substring(8, 12) + "-" + uuidStr.substring(12, 16) + "-" + uuidStr.substring(16, 20) + "-" + uuidStr.substring(20);
         }

         try {
            return Optional.of(UUID.fromString(uuidStr));
         } catch (IllegalArgumentException var4) {
            PersonalWorldsMod.LOGGER.warn("Invalid UUID in dimension path: {}", path);
            return Optional.empty();
         }
      }
   }

   public static Optional<UUID> getDimensionOwner(class_5321<class_1937> dimensionKey) {
      if (!dimensionKey.method_29177().method_12836().equals("personalworlds")) {
         return Optional.empty();
      } else {
         String path = dimensionKey.method_29177().method_12832();
         if (!path.startsWith("pw_")) {
            return Optional.empty();
         } else {
            String uuidStr = path.substring(3);
            if (uuidStr.length() == 32 && !uuidStr.contains("-")) {
               String var10000 = uuidStr.substring(0, 8);
               uuidStr = var10000 + "-" + uuidStr.substring(8, 12) + "-" + uuidStr.substring(12, 16) + "-" + uuidStr.substring(16, 20) + "-" + uuidStr.substring(20);
            }

            try {
               return Optional.of(UUID.fromString(uuidStr));
            } catch (IllegalArgumentException var4) {
               PersonalWorldsMod.LOGGER.warn("Invalid UUID in dimension key path: {}", path);
               return Optional.empty();
            }
         }
      }
   }

   private static Optional<class_2338> findExistingPortal(class_3218 world) {
      class_2338 center = new class_2338(0, 64, 0);

      for(int y = -128; y <= 128; ++y) {
         for(int x = -128; x <= 128; ++x) {
            for(int z = -128; z <= 128; ++z) {
               class_2338 checkPos = center.method_10069(x, y, z);
               if (checkPos.method_10264() >= world.method_31607() && checkPos.method_10264() < WorldCompat.getTopY(world) && world.method_8320(checkPos).method_26204() == ModBlocks.PERSONAL_PORTAL) {
                  PersonalWorldsMod.LOGGER.debug("Found existing portal at {}", checkPos);
                  return Optional.of(checkPos);
               }
            }
         }
      }

      PersonalWorldsMod.LOGGER.debug("No existing portal found in {}", world.method_27983().method_29177());
      return Optional.empty();
   }

   private static class_2338 findSafePositionNearPortal(class_3218 world, class_2338 portalPos) {
      class_2680 portalState = world.method_8320(portalPos);
      class_2350.class_2351 axis = (class_2350.class_2351)portalState.method_11654(PersonalPortalBlock.AXIS);
      class_2350[] checkDirections;
      if (axis == class_2351.field_11048) {
         checkDirections = new class_2350[]{class_2350.field_11043, class_2350.field_11035};
      } else {
         checkDirections = new class_2350[]{class_2350.field_11034, class_2350.field_11039};
      }

      class_2338 bottomPortal;
      for(bottomPortal = portalPos; world.method_8320(bottomPortal.method_10074()).method_26204() == ModBlocks.PERSONAL_PORTAL; bottomPortal = bottomPortal.method_10074()) {
      }

      for(class_2350 dir : checkDirections) {
         class_2338 sidePos = bottomPortal.method_10093(dir);

         for(int yOffset = 0; yOffset >= -3; --yOffset) {
            class_2338 groundCheck = sidePos.method_10069(0, yOffset - 1, 0);
            class_2338 feetPos = sidePos.method_10069(0, yOffset, 0);
            class_2338 headPos = sidePos.method_10069(0, yOffset + 1, 0);
            if (!world.method_8320(groundCheck).method_26215() && world.method_8320(feetPos).method_26215() && world.method_8320(headPos).method_26215()) {
               PersonalWorldsMod.LOGGER.debug("Found safe position near portal: {}", feetPos);
               return feetPos;
            }
         }
      }

      PersonalWorldsMod.LOGGER.debug("No safe position found near portal, using portal position");
      return bottomPortal;
   }

   private static class_2338 getOrCreateSpawnPlatform(class_3218 world, WorldGenType genType, int portalTypeIndex) {
      class_2338 spawnPos = new class_2338(0, 65, 0);
      if (genType == WorldGenType.VOID) {
         class_2338 groundCheck = spawnPos.method_10074();
         if (world.method_8320(groundCheck).method_26215()) {
            createStarterPlatform(world, new class_2338(0, 64, 0), portalTypeIndex);
         }
      }

      return spawnPos;
   }

   private static void createStarterPlatform(class_3218 world, class_2338 center, int portalTypeIndex) {
      PersonalWorldsMod.LOGGER.info("Creating starter platform at {} with portal type {}", center, portalTypeIndex);
      class_2680 platformMaterial = class_2246.field_10219.method_9564();
      ModConfig.PortalConfig config = (ModConfig.PortalConfig)ModConfig.get().portalTypes.get(portalTypeIndex);
      if (config.islandLayers.length > 0) {
         String blockId = config.islandLayers[0];
         class_2960 id = IdentifierCompat.tryParse(blockId);
         class_2248 block = id != null ? (class_2248)class_7923.field_41175.method_10223(id) : class_2246.field_10219;
         if (block != class_2246.field_10124 || blockId.equals("minecraft:air")) {
            platformMaterial = block.method_9564();
         }
      }

      for(int x = -2; x <= 2; ++x) {
         for(int z = -2; z <= 2; ++z) {
            class_2338 pos = center.method_10069(x, 0, z);
            world.method_8501(pos, platformMaterial);
         }
      }

      createReturnPortalFrame(world, center.method_10069(4, 1, 0));
   }

   private static void createReturnPortalFrame(class_3218 world, class_2338 bottomLeft) {
      class_2248 frameBlock = ModBlocks.getFrameBlock(0);
      class_2680 frameState = frameBlock.method_9564();
      int frameWidth = 4;
      int frameHeight = 5;

      for(int x = 0; x < frameWidth; ++x) {
         world.method_8501(bottomLeft.method_10069(x, 0, 0), frameState);
      }

      for(int x = 0; x < frameWidth; ++x) {
         world.method_8501(bottomLeft.method_10069(x, frameHeight - 1, 0), frameState);
      }

      for(int y = 1; y < frameHeight - 1; ++y) {
         world.method_8501(bottomLeft.method_10069(0, y, 0), frameState);
      }

      for(int y = 1; y < frameHeight - 1; ++y) {
         world.method_8501(bottomLeft.method_10069(frameWidth - 1, y, 0), frameState);
      }

      PersonalWorldsMod.LOGGER.debug("Created return portal frame at {}", bottomLeft);
   }

   private static Optional<Integer> detectPortalType(class_1937 world, class_2338 clickedPos, class_1792 activationItem) {
      List<ModConfig.PortalConfig> portalTypes = ModConfig.get().portalTypes;

      for(int i = 0; i < portalTypes.size(); ++i) {
         class_1792 configItem = ModItems.getActivationItem(i);
         if (configItem == activationItem) {
            class_2248 configFrame = ModBlocks.getFrameBlock(i);
            Optional<PortalFrame> frame = detectFrameForAxis(world, clickedPos, configFrame, class_2351.field_11048);
            if (frame.isEmpty()) {
               frame = detectFrameForAxis(world, clickedPos, configFrame, class_2351.field_11051);
            }

            if (frame.isPresent()) {
               return Optional.of(i);
            }
         }
      }

      return Optional.empty();
   }

   public static Optional<PortalFrame> detectFrame(class_1937 world, class_2338 clickedPos, int portalTypeIndex) {
      class_2248 frameBlock = ModBlocks.getFrameBlock(portalTypeIndex);
      Optional<PortalFrame> xFrame = detectFrameForAxis(world, clickedPos, frameBlock, class_2351.field_11048);
      return xFrame.isPresent() ? xFrame : detectFrameForAxis(world, clickedPos, frameBlock, class_2351.field_11051);
   }

   private static Optional<PortalFrame> detectFrameForAxis(class_1937 world, class_2338 clickedPos, class_2248 frameBlock, class_2350.class_2351 axis) {
      class_2350 horizontal = axis == class_2351.field_11048 ? class_2350.field_11039 : class_2350.field_11043;
      class_2338 searchPos = clickedPos;

      for(int i = 0; i < 3; ++i) {
         class_2338 nextPos = searchPos.method_10093(horizontal);
         if (world.method_8320(nextPos).method_26204() == frameBlock) {
            break;
         }

         searchPos = nextPos;
      }

      for(int i = 0; i < 4; ++i) {
         class_2338 downPos = searchPos.method_10074();
         if (world.method_8320(downPos).method_26204() == frameBlock) {
            break;
         }

         searchPos = downPos;
      }

      class_2338 bottomLeftFrame = searchPos.method_10093(horizontal).method_10074();
      PortalFrame frame = new PortalFrame(bottomLeftFrame, 2, 3, axis);
      return isValidFrame(world, frame, frameBlock) ? Optional.of(frame) : Optional.empty();
   }

   private static boolean isValidFrame(class_1937 world, PortalFrame frame, class_2248 frameBlock) {
      for(class_2338 pos : frame.getFramePositions()) {
         if (world.method_8320(pos).method_26204() != frameBlock) {
            return false;
         }
      }

      for(class_2338 pos : frame.getInteriorPositions()) {
         class_2680 state = world.method_8320(pos);
         if (!state.method_26215() && state.method_26204() != ModBlocks.PERSONAL_PORTAL) {
            return false;
         }
      }

      return true;
   }

   public static boolean isFrameValidForPortal(class_1937 world, class_2338 portalPos, class_2350.class_2351 axis) {
      for(int i = 0; i < ModConfig.get().portalTypes.size(); ++i) {
         class_2248 frameBlock = ModBlocks.getFrameBlock(i);
         Optional<PortalFrame> frame = detectFrameForAxis(world, portalPos, frameBlock, axis);
         if (frame.isPresent()) {
            return true;
         }
      }

      return false;
   }
}
