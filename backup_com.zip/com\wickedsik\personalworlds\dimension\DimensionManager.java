package com.wickedsik.personalworlds.dimension;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.GameRulesCompat;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.generator.VoidIslandChunkGenerator;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_1992;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import xyz.nucleoid.fantasy.Fantasy;
import xyz.nucleoid.fantasy.RuntimeWorldConfig;
import xyz.nucleoid.fantasy.RuntimeWorldHandle;

public class DimensionManager {
   private static final Map<UUID, RuntimeWorldHandle> activeHandles = new HashMap();

   public static class_3218 getOrCreatePlayerDimension(MinecraftServer server, UUID playerUuid, String playerName, WorldGenType genType, int portalTypeIndex) {
      Fantasy fantasy = Fantasy.get(server);
      class_2960 dimId = createDimensionId(playerUuid);
      if (activeHandles.containsKey(playerUuid)) {
         return ((RuntimeWorldHandle)activeHandles.get(playerUuid)).asWorld();
      } else {
         RuntimeWorldConfig config = createWorldConfig(server, genType, playerUuid, portalTypeIndex);
         RuntimeWorldHandle handle = fantasy.getOrOpenPersistentWorld(dimId, config);
         activeHandles.put(playerUuid, handle);
         PersonalWorldsMod.LOGGER.info("Loaded/created dimension for player: {} ({}) with portal type {}", new Object[]{playerName, playerUuid, portalTypeIndex});
         DimensionRegistry registry = DimensionRegistry.get(server);
         PlayerDimensionData data;
         if (!registry.hasDimension(playerUuid)) {
            data = new PlayerDimensionData(playerUuid, playerName, dimId, System.currentTimeMillis(), getSpawnPoint(genType), genType, portalTypeIndex);
            registry.registerDimension(data);
         } else {
            data = (PlayerDimensionData)registry.getDimensionData(playerUuid).orElseThrow();
            if (!data.ownerName().equals(playerName)) {
               data = new PlayerDimensionData(data.ownerUuid(), playerName, data.dimensionId(), data.createdAt(), data.spawnPoint(), data.generatorType(), data.portalTypeIndex());
               registry.registerDimension(data);
               PersonalWorldsMod.LOGGER.info("Updated owner name for dimension: {} -> {}", data.ownerUuid(), playerName);
            }
         }

         DimensionMetadataFile.write(server, data);
         return handle.asWorld();
      }
   }

   public static void loadExistingDimension(MinecraftServer server, PlayerDimensionData data) {
      Fantasy fantasy = Fantasy.get(server);
      if (!activeHandles.containsKey(data.ownerUuid())) {
         RuntimeWorldConfig config = createWorldConfig(server, data.generatorType(), data.ownerUuid(), data.portalTypeIndex());
         RuntimeWorldHandle handle = fantasy.getOrOpenPersistentWorld(data.dimensionId(), config);
         activeHandles.put(data.ownerUuid(), handle);
         PersonalWorldsMod.LOGGER.debug("Restored dimension: {} with portal type {}", data.dimensionId(), data.portalTypeIndex());
      }
   }

   public static boolean unloadIfEmpty(UUID playerUuid) {
      RuntimeWorldHandle handle = (RuntimeWorldHandle)activeHandles.get(playerUuid);
      if (handle != null && handle.asWorld().method_18456().isEmpty()) {
         handle.unload();
         activeHandles.remove(playerUuid);
         PersonalWorldsMod.LOGGER.info("Unloaded empty dimension for player: {}", playerUuid);
         return true;
      } else {
         return false;
      }
   }

   public static boolean deleteDimension(MinecraftServer server, UUID playerUuid) {
      RuntimeWorldHandle handle = (RuntimeWorldHandle)activeHandles.get(playerUuid);
      if (handle != null) {
         handle.delete();
         activeHandles.remove(playerUuid);
         PersonalWorldsMod.LOGGER.info("Queued loaded dimension for deletion: {}", playerUuid);
         return true;
      } else {
         boolean deleted = DimensionMetadataFile.deleteDimensionFolder(server, playerUuid);
         if (deleted) {
            PersonalWorldsMod.LOGGER.info("Deleted unloaded dimension folder for: {}", playerUuid);
         } else {
            PersonalWorldsMod.LOGGER.warn("No dimension folder found to delete for: {}", playerUuid);
         }

         return deleted;
      }
   }

   public static void unloadEmptyDimensions() {
      activeHandles.entrySet().removeIf((entry) -> {
         RuntimeWorldHandle handle = (RuntimeWorldHandle)entry.getValue();
         if (handle.asWorld().method_18456().isEmpty()) {
            handle.unload();
            PersonalWorldsMod.LOGGER.debug("Unloaded empty dimension: {}", entry.getKey());
            return true;
         } else {
            return false;
         }
      });
   }

   public static void unloadAll() {
      for(RuntimeWorldHandle handle : activeHandles.values()) {
         handle.unload();
      }

      activeHandles.clear();
      PersonalWorldsMod.LOGGER.info("Unloaded all player dimensions");
   }

   public static boolean isDimensionLoaded(UUID playerUuid) {
      return activeHandles.containsKey(playerUuid);
   }

   public static class_3218 getLoadedDimension(UUID playerUuid) {
      RuntimeWorldHandle handle = (RuntimeWorldHandle)activeHandles.get(playerUuid);
      return handle != null ? handle.asWorld() : null;
   }

   public static int getLoadedDimensionCount() {
      return activeHandles.size();
   }

   private static class_2960 createDimensionId(UUID playerUuid) {
      String var10000 = playerUuid.toString();
      return IdentifierCompat.modId("pw_" + var10000.replace("-", ""));
   }

   private static RuntimeWorldConfig createWorldConfig(MinecraftServer server, WorldGenType genType, UUID playerUuid, int portalTypeIndex) {
      RuntimeWorldConfig config = (new RuntimeWorldConfig()).setDimensionType(class_7134.field_37666).setSeed((long)playerUuid.hashCode()).setDifficulty(server.method_27728().method_207()).setShouldTickTime(true).setTimeOfDay(server.method_30002().method_8532());
      config.setGenerator(createChunkGenerator(server, genType, portalTypeIndex));
      GameRulesCompat.applyGameRules(config, server);
      return config;
   }

   private static class_2794 createChunkGenerator(MinecraftServer server, WorldGenType genType, int portalTypeIndex) {
      Object var10000;
      switch (genType) {
         case VOID:
            class_2378<class_1959> biomeRegistry = server.method_30611().method_30530(class_7924.field_41236);
            class_6880<class_1959> voidBiome = (class_6880)biomeRegistry.method_40264(class_1972.field_9473).orElseThrow(() -> new IllegalStateException("The Void biome not found"));
            class_2680[] islandLayers = convertIslandLayers(portalTypeIndex);
            var10000 = new VoidIslandChunkGenerator(new class_1992(voidBiome), islandLayers);
            break;
         case OVERWORLD:
            var10000 = server.method_30002().method_14178().method_12129();
            break;
         case FLAT:
            var10000 = server.method_30002().method_14178().method_12129();
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return (class_2794)var10000;
   }

   private static class_2680[] convertIslandLayers(int portalTypeIndex) {
      ModConfig.PortalConfig config = (ModConfig.PortalConfig)ModConfig.get().portalTypes.get(portalTypeIndex);
      String[] layerIds = config.islandLayers;
      int layerCount = Math.min(layerIds.length, 5);
      if (layerCount == 0) {
         PersonalWorldsMod.LOGGER.warn("Portal type {} has no island layers, using grass", portalTypeIndex);
         return new class_2680[]{class_2246.field_10219.method_9564()};
      } else {
         class_2680[] islandLayers = new class_2680[layerCount];

         for(int i = 0; i < layerCount; ++i) {
            String blockId = layerIds[i];
            class_2960 id = IdentifierCompat.tryParse(blockId);
            class_2248 block = id != null ? (class_2248)class_7923.field_41175.method_10223(id) : class_2246.field_10124;
            if (block == class_2246.field_10124 && !blockId.equals("minecraft:air")) {
               PersonalWorldsMod.LOGGER.warn("Invalid island layer block '{}' for portal type {}, using grass_block", blockId, portalTypeIndex);
               block = class_2246.field_10219;
            }

            islandLayers[i] = block.method_9564();
         }

         return islandLayers;
      }
   }

   private static class_2338 getSpawnPoint(WorldGenType genType) {
      class_2338 var10000;
      switch (genType) {
         case VOID:
            var10000 = new class_2338(0, 65, 0);
            break;
         case OVERWORLD:
         case FLAT:
            var10000 = new class_2338(0, 64, 0);
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return var10000;
   }
}
