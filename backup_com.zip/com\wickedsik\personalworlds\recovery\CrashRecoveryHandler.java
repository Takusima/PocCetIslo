package com.wickedsik.personalworlds.recovery;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.compat.WorldCompat;
import com.wickedsik.personalworlds.dimension.DimensionManager;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.player.InvitationManager;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import com.wickedsik.personalworlds.player.ReturnData;
import com.wickedsik.personalworlds.portal.PortalHelper;
import com.wickedsik.personalworlds.util.SafeSpawnFinder;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;

public class CrashRecoveryHandler {
   public static void onPlayerJoin(class_3222 player) {
      MinecraftServer server = EntityCompat.getServer(player);
      if (server != null) {
         UUID playerUuid = player.method_5667();
         class_3218 currentWorld = EntityCompat.getServerWorld(player);
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         if (PortalHelper.isInPersonalDimension(currentWorld)) {
            handleLoginInPersonalDimension(player, server, currentWorld);
         } else {
            Optional<class_5321<class_1937>> expectedDimension = dataManager.getCurrentPocketDimension(playerUuid);
            if (expectedDimension.isPresent()) {
               handleMisplacedPlayer(player, server, (class_5321)expectedDimension.get());
            } else {
               if (dataManager.hasReturnData(playerUuid)) {
                  handleOrphanedReturnData(player, server, dataManager);
               }

            }
         }
      }
   }

   private static void handleLoginInPersonalDimension(class_3222 player, MinecraftServer server, class_3218 personalWorld) {
      UUID playerUuid = player.method_5667();
      Optional<UUID> ownerOpt = PortalHelper.getDimensionOwner(personalWorld);
      if (ownerOpt.isEmpty()) {
         PersonalWorldsMod.LOGGER.warn("Player {} in invalid personal dimension, evacuating", player.method_5477().getString());
         emergencyEvacuate(player, server, "Invalid dimension detected");
      } else {
         UUID ownerUuid = (UUID)ownerOpt.get();
         if (!playerUuid.equals(ownerUuid) && !InvitationManager.canVisit(server, playerUuid, ownerUuid)) {
            PersonalWorldsMod.LOGGER.info("Player {} no longer has permission to {}'s dimension, evacuating", player.method_5477().getString(), ownerUuid);
            player.method_7353(class_2561.method_43471("pocketislands.message.ejected_offline").method_27692(class_124.field_1065), false);
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            dataManager.clearCurrentPocketDimension(playerUuid);
            teleportToFallbackPosition(player, server, dataManager);
         } else {
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            dataManager.setCurrentPocketDimension(playerUuid, personalWorld.method_27983());
            PersonalWorldsMod.LOGGER.debug("Player {} logged in to personal dimension with valid permission", player.method_5477().getString());
         }
      }
   }

   private static void handleMisplacedPlayer(class_3222 player, MinecraftServer server, class_5321<class_1937> expectedDimension) {
      UUID playerUuid = player.method_5667();
      PlayerDataManager dataManager = PlayerDataManager.get(server);
      Optional<UUID> ownerOpt = PortalHelper.getDimensionOwner(expectedDimension);
      if (ownerOpt.isEmpty()) {
         PersonalWorldsMod.LOGGER.warn("Invalid pocket dimension key for player {}: {}", player.method_5477().getString(), expectedDimension.method_29177());
         dataManager.clearCurrentPocketDimension(playerUuid);
         teleportToFallbackPosition(player, server, dataManager);
      } else {
         UUID ownerUuid = (UUID)ownerOpt.get();
         if (!playerUuid.equals(ownerUuid) && !InvitationManager.canVisit(server, playerUuid, ownerUuid)) {
            PersonalWorldsMod.LOGGER.info("Player {} lost permission to dimension {}, using fallback", player.method_5477().getString(), ownerUuid);
            dataManager.clearCurrentPocketDimension(playerUuid);
            player.method_7353(class_2561.method_43471("pocketislands.message.ejected_offline").method_27692(class_124.field_1065), false);
            teleportToFallbackPosition(player, server, dataManager);
         } else {
            DimensionRegistry registry = DimensionRegistry.get(server);
            Optional<PlayerDimensionData> dimDataOpt = registry.getDimensionData(ownerUuid);
            if (dimDataOpt.isEmpty()) {
               PersonalWorldsMod.LOGGER.warn("No registry data for dimension {}, using fallback", ownerUuid);
               dataManager.clearCurrentPocketDimension(playerUuid);
               teleportToFallbackPosition(player, server, dataManager);
            } else {
               PlayerDimensionData dimData = (PlayerDimensionData)dimDataOpt.get();

               try {
                  class_3218 targetWorld = DimensionManager.getOrCreatePlayerDimension(server, ownerUuid, dimData.ownerName(), dimData.generatorType(), dimData.portalTypeIndex());
                  if (targetWorld == null) {
                     throw new RuntimeException("Failed to restore dimension - getOrCreatePlayerDimension returned null");
                  }

                  class_2338 safePos = SafeSpawnFinder.findSafePosition(targetWorld, dimData.spawnPoint());
                  TeleportCompat.teleportToBlockPreserveRotation(player, targetWorld, safePos);
                  PersonalWorldsMod.LOGGER.info("Restored player {} to pocket dimension after fallback spawn", player.method_5477().getString());
                  player.method_7353(class_2561.method_43471("pocketislands.message.dimension_restored"), false);
               } catch (Exception e) {
                  PersonalWorldsMod.LOGGER.error("Failed to restore dimension for {}: {}", player.method_5477().getString(), e.getMessage());
                  dataManager.clearCurrentPocketDimension(playerUuid);
                  teleportToFallbackPosition(player, server, dataManager);
               }

            }
         }
      }
   }

   private static void handleOrphanedReturnData(class_3222 player, MinecraftServer server, PlayerDataManager dataManager) {
      UUID playerUuid = player.method_5667();
      dataManager.clearReturnData(playerUuid);
      PersonalWorldsMod.LOGGER.debug("Cleared orphaned return data for player {}", player.method_5477().getString());
   }

   private static void teleportToFallbackPosition(class_3222 player, MinecraftServer server, PlayerDataManager dataManager) {
      UUID playerUuid = player.method_5667();
      float yaw = player.method_36454();
      float pitch = player.method_36455();
      Optional<ReturnData> returnDataOpt = dataManager.getReturnData(playerUuid);
      if (returnDataOpt.isPresent()) {
         ReturnData returnData = (ReturnData)returnDataOpt.get();
         class_3218 targetWorld = server.method_3847(returnData.dimension());
         if (targetWorld != null) {
            class_2338 safePos = SafeSpawnFinder.findSafePosition(targetWorld, returnData.position());
            class_243 targetPos = class_243.method_24953(safePos);
            yaw = returnData.yaw();
            pitch = returnData.pitch();
            dataManager.clearReturnData(playerUuid);
            teleportPlayer(player, targetWorld, targetPos, yaw, pitch);
            return;
         }

         dataManager.clearReturnData(playerUuid);
      }

      class_2338 bedPos = EntityCompat.getSpawnPointPosition(player);
      if (bedPos != null) {
         class_3218 bedWorld = server.method_3847(EntityCompat.getSpawnPointDimension(player));
         if (bedWorld != null) {
            class_2338 safePos = SafeSpawnFinder.findSafePosition(bedWorld, bedPos);
            class_243 targetPos = class_243.method_24953(safePos);
            teleportPlayer(player, bedWorld, targetPos, yaw, pitch);
            return;
         }
      }

      class_3218 targetWorld = server.method_30002();
      class_2338 safePos = SafeSpawnFinder.findSafePosition(targetWorld, WorldCompat.getSpawnPos(targetWorld));
      class_243 targetPos = class_243.method_24953(safePos);
      teleportPlayer(player, targetWorld, targetPos, yaw, pitch);
   }

   private static void teleportPlayer(class_3222 player, class_3218 world, class_243 pos, float yaw, float pitch) {
      TeleportCompat.teleport(player, world, pos, yaw, pitch);
      player.method_7353(class_2561.method_43471("pocketislands.message.returned_overworld"), true);
   }

   private static void evacuateToReturnPosition(class_3222 player, MinecraftServer server) {
      PlayerDataManager dataManager = PlayerDataManager.get(server);
      teleportToFallbackPosition(player, server, dataManager);
   }

   private static void emergencyEvacuate(class_3222 player, MinecraftServer server, String reason) {
      class_3218 overworld = server.method_30002();
      class_2338 safePos = SafeSpawnFinder.findSafePosition(overworld, WorldCompat.getSpawnPos(overworld));
      TeleportCompat.teleportToBlockPreserveRotation(player, overworld, safePos);
      player.method_7353(class_2561.method_43469("pocketislands.message.emergency_teleport", new Object[]{reason}).method_27692(class_124.field_1061), false);
      PlayerDataManager dataManager = PlayerDataManager.get(server);
      dataManager.clearReturnData(player.method_5667());
      dataManager.clearCurrentPocketDimension(player.method_5667());
   }
}
