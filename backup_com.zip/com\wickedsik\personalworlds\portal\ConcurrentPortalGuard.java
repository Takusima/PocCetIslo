package com.wickedsik.personalworlds.portal;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_3222;

public class ConcurrentPortalGuard {
   private static final Map<UUID, Long> playersInTransit = new ConcurrentHashMap();
   private static final Map<Long, UUID> portalsProcessing = new ConcurrentHashMap();
   private static final long TELEPORT_COOLDOWN_MS = 1000L;
   private static final long MAX_LOCK_TIME_MS = 5000L;

   public static boolean tryAcquire(class_3222 player, class_2338 portalPos) {
      UUID playerUuid = player.method_5667();
      long now = System.currentTimeMillis();
      long portalHash = hashPosition(portalPos);
      Long lastTeleport = (Long)playersInTransit.get(playerUuid);
      if (lastTeleport != null) {
         if (now - lastTeleport < 1000L) {
            PersonalWorldsMod.LOGGER.debug("Player {} blocked: teleport cooldown active", player.method_5477().getString());
            return false;
         }

         if (now - lastTeleport > 5000L) {
            PersonalWorldsMod.LOGGER.warn("Clearing stale transit lock for player {}", player.method_5477().getString());
         }
      }

      UUID processingPlayer = (UUID)portalsProcessing.get(portalHash);
      if (processingPlayer != null && !processingPlayer.equals(playerUuid)) {
         Long processingTime = (Long)playersInTransit.get(processingPlayer);
         if (processingTime != null && now - processingTime < 5000L) {
            PersonalWorldsMod.LOGGER.debug("Portal at {} being processed by another player", portalPos);
            return false;
         }
      }

      playersInTransit.put(playerUuid, now);
      portalsProcessing.put(portalHash, playerUuid);
      PersonalWorldsMod.LOGGER.debug("Acquired teleport lock for player {} at portal {}", player.method_5477().getString(), portalPos);
      return true;
   }

   public static void release(class_3222 player, class_2338 portalPos) {
      UUID playerUuid = player.method_5667();
      long portalHash = hashPosition(portalPos);
      portalsProcessing.remove(portalHash, playerUuid);
      PersonalWorldsMod.LOGGER.debug("Released portal lock for player {} at {}", player.method_5477().getString(), portalPos);
   }

   public static void forceRelease(UUID playerUuid) {
      playersInTransit.remove(playerUuid);
      portalsProcessing.values().removeIf((uuid) -> uuid.equals(playerUuid));
      PersonalWorldsMod.LOGGER.debug("Force released all locks for player {}", playerUuid);
   }

   public static void cleanup() {
      long now = System.currentTimeMillis();
      long staleThreshold = now - 5000L;
      playersInTransit.entrySet().removeIf((entry) -> (Long)entry.getValue() < staleThreshold);
      portalsProcessing.entrySet().removeIf((entry) -> !playersInTransit.containsKey(entry.getValue()));
   }

   static long hashPosition(class_2338 pos) {
      return ((long)pos.method_10263() & 67108863L) << 38 | ((long)pos.method_10264() & 65535L) << 20 | (long)pos.method_10260() & 16777215L;
   }

   static boolean tryAcquire(UUID playerUuid, class_2338 portalPos) {
      long now = System.currentTimeMillis();
      long portalHash = hashPosition(portalPos);
      Long lastTeleport = (Long)playersInTransit.get(playerUuid);
      if (lastTeleport != null && now - lastTeleport < 1000L) {
         return false;
      } else {
         UUID processingPlayer = (UUID)portalsProcessing.get(portalHash);
         if (processingPlayer != null && !processingPlayer.equals(playerUuid)) {
            Long processingTime = (Long)playersInTransit.get(processingPlayer);
            if (processingTime != null && now - processingTime < 5000L) {
               return false;
            }
         }

         playersInTransit.put(playerUuid, now);
         portalsProcessing.put(portalHash, playerUuid);
         return true;
      }
   }

   static void release(UUID playerUuid, class_2338 portalPos) {
      long portalHash = hashPosition(portalPos);
      portalsProcessing.remove(portalHash, playerUuid);
   }

   static void clearAllForTesting() {
      playersInTransit.clear();
      portalsProcessing.clear();
   }
}
