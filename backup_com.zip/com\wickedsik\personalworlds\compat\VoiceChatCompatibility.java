package com.wickedsik.personalworlds.compat;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import net.minecraft.class_3222;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Класс интеграции с модом Simple Voice Chat.
 * Обеспечивает автоматическое объединение игроков в аудио-группы
 * при принятии приглашения на посещение карманного измерения.
 *
 * Использует рефлексию для безопасного доступа к API Simple Voice Chat,
 * чтобы мод не падал при отсутствии голосового чата на сервере.
 *
 * API Simple Voice Chat:
 * - de.maxhenricg.voicechat.api.VoiceChatApi
 * - de.maxhenricg.voicechat.api.Group
 * - de.maxhenricg.voicechat.api.events.GroupEvent
 */
public final class VoiceChatCompatibility {

    // Флаг наличия Simple Voice Chat на сервере
    private static boolean voiceChatPresent = false;

    // Рефлексивные ссылки на классы и методы Simple Voice Chat API
    private static Class<?> voiceChatApiClass = null;
    private static Class<?> groupClass = null;
    private static Method getGroupMethod = null;
    private static Method createGroupMethod = null;
    private static Method addPlayerToGroupMethod = null;
    private static Method removePlayerFromGroupMethod = null;
    private static Method getApiInstanceMethod = null;

    // Префикс для групп голосового чата Pocket Islands
    private static final String GROUP_PREFIX = "pocketislands_";

    private VoiceChatCompatibility() {
        // Utility class - предотвращаем создание экпляров
    }

    /**
     * Инициализация интеграции с Simple Voice Chat.
     * Пытается загрузить классы API через рефлексию.
     * Если Simple Voice Chat не установлен, устанавливает флаг voiceChatPresent = false.
     */
    public static void initialize() {
        try {
            // Пытаемся загрузить основной класс API Simple Voice Chat
            voiceChatApiClass = Class.forName("de.maxhenricg.voicechat.api.VoiceChatApi");
            groupClass = Class.forName("de.maxhenricg.voicechat.api.Group");

            // Получаем методы API
            getApiInstanceMethod = voiceChatApiClass.getMethod("getInstance");
            getGroupMethod = voiceChatApiClass.getMethod("getGroup", String.class);
            createGroupMethod = voiceChatApiClass.getMethod("createGroup", String.class, boolean.class);
            addPlayerToGroupMethod = groupClass.getMethod("addPlayer", UUID.class);
            removePlayerFromGroupMethod = groupClass.getMethod("removePlayer", UUID.class);

            voiceChatPresent = true;
            PersonalWorldsMod.LOGGER.info("Simple Voice Chat integration initialized successfully!");
        } catch (ClassNotFoundException e) {
            voiceChatPresent = false;
            PersonalWorldsMod.LOGGER.info("Simple Voice Chat not found. Voice chat integration disabled.");
        } catch (NoSuchMethodException e) {
            voiceChatPresent = false;
            PersonalWorldsMod.LOGGER.warn("Simple Voice Chat API methods not found. Voice chat integration disabled.", e);
        } catch (Exception e) {
            voiceChatPresent = false;
            PersonalWorldsMod.LOGGER.error("Failed to initialize Simple Voice Chat integration", e);
        }
    }

    /**
     * Проверяет, доступен ли Simple Voice Chat на сервере.
     *
     * @return true если Simple Voice Chat установлен и инициализирован
     */
    public static boolean isVoiceChatPresent() {
        return voiceChatPresent;
    }

    /**
     * Создает скрытую аудио-группу для двух игроков.
     * Используется при принятии приглашения на посещение карманного измерения.
     *
     * @param player1Uuid UUID первого игрока (хозяин измерения)
     * @param player2Uuid UUID второго игрока (гость)
     * @param groupName Имя группы
     * @return true если группа успешно создана и игроки добавлены
     */
    public static boolean createVoiceGroup(UUID player1Uuid, UUID player2Uuid, String groupName) {
        if (!voiceChatPresent) {
            PersonalWorldsMod.LOGGER.debug("Voice chat not available, skipping group creation");
            return false;
        }

        try {
            // Получаем экземпляр API
            Object apiInstance = getApiInstanceMethod.invoke(null);
            if (apiInstance == null) {
                PersonalWorldsMod.LOGGER.warn("VoiceChatApi instance is null");
                return false;
            }

            // Формируем уникальное имя группы
            String fullGroupName = GROUP_PREFIX + groupName;

            // Проверяем, существует ли уже группа с таким именем
            Object existingGroup = getGroupMethod.invoke(apiInstance, fullGroupName);
            if (existingGroup != null) {
                // Группа уже существует, добавляем игроков в существующую группу
                addPlayerToGroupMethod.invoke(existingGroup, player1Uuid);
                addPlayerToGroupMethod.invoke(existingGroup, player2Uuid);
                PersonalWorldsMod.LOGGER.info("Added players to existing voice group: {}", fullGroupName);
                return true;
            }

            // Создаем новую скрытую группу
            // Параметры: groupName, isHidden
            Object newGroup = createGroupMethod.invoke(apiInstance, fullGroupName, true);
            if (newGroup == null) {
                PersonalWorldsMod.LOGGER.warn("Failed to create voice group: {}", fullGroupName);
                return false;
            }

            // Добавляем обоих игроков в группу
            addPlayerToGroupMethod.invoke(newGroup, player1Uuid);
            addPlayerToGroupMethod.invoke(newGroup, player2Uuid);

            PersonalWorldsMod.LOGGER.info("Created voice group '{}' for players {} and {}", fullGroupName, player1Uuid, player2Uuid);
            return true;

        } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to create voice group for players {} and {}", player1Uuid, player2Uuid, e);
            return false;
        }
    }

    /**
     * Создает скрытую аудио-группу для двух игроков по их серверным объектам.
     *
     * @param player1 Первый игрок (хозяин измерения)
     * @param player2 Второй игрок (гость)
     * @return true если группа успешно создана
     */
    public static boolean createVoiceGroup(class_3222 player1, class_3222 player2) {
        if (player1 == null || player2 == null) {
            PersonalWorldsMod.LOGGER.warn("Cannot create voice group: one or both players are null");
            return false;
        }

        String groupName = player1.method_5667().toString().substring(0, 8) + "_" +
                           player2.method_5667().toString().substring(0, 8);

        return createVoiceGroup(player1.method_5667(), player2.method_5667(), groupName);
    }

    /**
     * Удаляет игрока из аудио-группы.
     * Используется при выходе из карманного измерения или отзыве приглашения.
     *
     * @param playerUuid UUID игрока
     * @param groupName Имя группы
     * @return true если игрок успешно удален из группы
     */
    public static boolean removePlayerFromVoiceGroup(UUID playerUuid, String groupName) {
        if (!voiceChatPresent) {
            PersonalWorldsMod.LOGGER.debug("Voice chat not available, skipping player removal");
            return false;
        }

        try {
            // Получаем экземпляр API
            Object apiInstance = getApiInstanceMethod.invoke(null);
            if (apiInstance == null) {
                PersonalWorldsMod.LOGGER.warn("VoiceChatApi instance is null");
                return false;
            }

            // Формируем полное имя группы
            String fullGroupName = GROUP_PREFIX + groupName;

            // Получаем группу
            Object group = getGroupMethod.invoke(apiInstance, fullGroupName);
            if (group == null) {
                PersonalWorldsMod.LOGGER.debug("Voice group '{}' not found, nothing to remove", fullGroupName);
                return false;
            }

            // Удаляем игрока из группы
            removePlayerFromGroupMethod.invoke(group, playerUuid);

            PersonalWorldsMod.LOGGER.info("Removed player {} from voice group '{}'", playerUuid, fullGroupName);
            return true;

        } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to remove player {} from voice group", playerUuid, e);
            return false;
        }
    }

    /**
     * Удаляет игрока из всех аудио-групп Pocket Islands.
     * Используется при выходе из игры или телепортации обратно в Overworld.
     *
     * @param playerUuid UUID игрока
     * @return true если игрок успешно удален из всех групп
     */
    public static boolean removePlayerFromAllVoiceGroups(UUID playerUuid) {
        if (!voiceChatPresent) {
            PersonalWorldsMod.LOGGER.debug("Voice chat not available, skipping player removal from all groups");
            return false;
        }

        try {
            // Получаем экземпляр API
            Object apiInstance = getApiInstanceMethod.invoke(null);
            if (apiInstance == null) {
                PersonalWorldsMod.LOGGER.warn("VoiceChatApi instance is null");
                return false;
            }

            // Удаляем игрока из всех групп с префиксом Pocket Islands
            // Для этого используем рефлексию для получения всех групп
            try {
                Method getAllGroupsMethod = voiceChatApiClass.getMethod("getAllGroups");
                Object allGroups = getAllGroupsMethod.invoke(apiInstance);

                if (allGroups instanceof Iterable) {
                    for (Object group : (Iterable<?>) allGroups) {
                        try {
                            Method getNameMethod = groupClass.getMethod("getName");
                            String groupName = (String) getNameMethod.invoke(group);

                            if (groupName != null && groupName.startsWith(GROUP_PREFIX)) {
                                removePlayerFromGroupMethod.invoke(group, playerUuid);
                                PersonalWorldsMod.LOGGER.debug("Removed player {} from group '{}'", playerUuid, groupName);
                            }
                        } catch (Exception e) {
                            PersonalWorldsMod.LOGGER.debug("Error processing group for player removal", e);
                        }
                    }
                }
            } catch (NoSuchMethodException e) {
                // Метод getAllGroups может не существовать в некоторых версиях API
                PersonalWorldsMod.LOGGER.debug("getAllGroups method not found, trying alternative approach");
            }

            PersonalWorldsMod.LOGGER.info("Removed player {} from all Pocket Islands voice groups", playerUuid);
            return true;

        } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to remove player {} from all voice groups", playerUuid, e);
            return false;
        }
    }

    /**
     * Проверяет, находится ли игрок в аудио-группе Pocket Islands.
     *
     * @param playerUuid UUID игрока
     * @return true если игрок находится в группе Pocket Islands
     */
    public static boolean isInVoiceGroup(UUID playerUuid) {
        if (!voiceChatPresent) {
            return false;
        }

        try {
            // Получаем экземпляр API
            Object apiInstance = getApiInstanceMethod.invoke(null);
            if (apiInstance == null) {
                return false;
            }

            // Проверяем все группы с префиксом Pocket Islands
            try {
                Method getAllGroupsMethod = voiceChatApiClass.getMethod("getAllGroups");
                Object allGroups = getAllGroupsMethod.invoke(apiInstance);

                if (allGroups instanceof Iterable) {
                    for (Object group : (Iterable<?>) allGroups) {
                        try {
                            Method getNameMethod = groupClass.getMethod("getName");
                            String groupName = (String) getNameMethod.invoke(group);

                            if (groupName != null && groupName.startsWith(GROUP_PREFIX)) {
                                Method getPlayersMethod = groupClass.getMethod("getPlayers");
                                Object players = getPlayersMethod.invoke(group);

                                if (players instanceof Iterable) {
                                    for (Object player : (Iterable<?>) players) {
                                        if (player instanceof UUID && player.equals(playerUuid)) {
                                            return true;
                                        }
                                    }
                                }
                            }
                        } catch (Exception e) {
                            PersonalWorldsMod.LOGGER.debug("Error checking group membership", e);
                        }
                    }
                }
            } catch (NoSuchMethodException e) {
                PersonalWorldsMod.LOGGER.debug("getAllGroups method not found");
            }

            return false;

        } catch (Exception e) {
            PersonalWorldsMod.LOGGER.error("Failed to check voice group membership for player {}", playerUuid, e);
            return false;
        }
    }

    /**
     * Получает имя группы голосового чата для двух игроков.
     *
     * @param player1Uuid UUID первого игрока
     * @param player2Uuid UUID второго игрока
     * @return Имя группы
     */
    public static String getVoiceGroupName(UUID player1Uuid, UUID player2Uuid) {
        return GROUP_PREFIX +
               player1Uuid.toString().substring(0, 8) + "_" +
               player2Uuid.toString().substring(0, 8);
    }
}
