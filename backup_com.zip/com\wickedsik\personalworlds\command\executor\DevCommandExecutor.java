package com.wickedsik.personalworlds.command.executor;

import com.wickedsik.personalworlds.command.CommandResult;
import com.wickedsik.personalworlds.command.service.TeleportHelper;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.dimension.DimensionManager;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.dimension.WorldGenType;
import com.wickedsik.personalworlds.portal.PortalHelper;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class DevCommandExecutor {
   public CommandResult createDimension(class_3222 player, String typeStr) {
      WorldGenType type = WorldGenType.fromString(typeStr);
      UUID playerUuid = player.method_5667();
      String playerName = player.method_5477().getString();
      MinecraftServer server = EntityCompat.getServer(player);

      try {
         class_3218 dimension = DimensionManager.getOrCreatePlayerDimension(server, playerUuid, playerName, type, 0);
         TeleportCompat.teleport(player, dimension, TeleportHelper.toDefaultSpawn(dimension, player));
         return CommandResult.successBroadcast(class_2561.method_43469("pocketislands.command.info.dimension_created", new Object[]{type.name()}));
      } catch (Exception e) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.create_failed", new Object[]{e.getMessage()}));
      }
   }

   public CommandResult enterDimension(class_3222 player) {
      UUID playerUuid = player.method_5667();
      MinecraftServer server = EntityCompat.getServer(player);
      DimensionRegistry registry = DimensionRegistry.get(server);
      if (!registry.hasDimension(playerUuid)) {
         return CommandResult.error(class_2561.method_43471("pocketislands.command.error.no_dimension"));
      } else {
         Optional<PlayerDimensionData> optData = registry.getDimensionData(playerUuid);
         if (optData.isEmpty()) {
            return CommandResult.error(class_2561.method_43471("pocketislands.command.error.load_failed"));
         } else {
            PlayerDimensionData data = (PlayerDimensionData)optData.get();

            try {
               class_3218 dimension = DimensionManager.getOrCreatePlayerDimension(server, playerUuid, player.method_5477().getString(), data.generatorType(), data.portalTypeIndex());
               TeleportCompat.teleport(player, dimension, TeleportHelper.toBlockPos(dimension, data.spawnPoint(), player));
               return CommandResult.successBroadcast(class_2561.method_43471("pocketislands.command.enter.success"));
            } catch (Exception e) {
               return CommandResult.error(class_2561.method_43469("pocketislands.command.error.enter_failed", new Object[]{e.getMessage()}));
            }
         }
      }
   }

   public CommandResult leaveDimension(class_3222 player) {
      PortalHelper.teleportToReturnPosition(player, EntityCompat.getServer(player));
      return CommandResult.silent();
   }
}
