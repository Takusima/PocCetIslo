package com.wickedsik.personalworlds.compat;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_2960;

public final class BlockSettingsCompat {
   private BlockSettingsCompat() {
   }

   public static FabricBlockSettings create(class_2960 id) {
      return FabricBlockSettings.create();
   }

   /** @deprecated */
   @Deprecated
   public static FabricBlockSettings create() {
      return FabricBlockSettings.create();
   }
}
