package com.wickedsik.personalworlds.client.screen;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.wickedsik.personalworlds.network.ModNetworking;
import com.wickedsik.personalworlds.network.NetworkHandlerClient;
import com.wickedsik.personalworlds.portal.PortalColor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1043;
import net.minecraft.class_1046;
import net.minecraft.class_124;
import net.minecraft.class_1675;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

import java.util.*;

/**
 * Кастомный GUI-экран для управления карманным измерением.
 * Открывается по нажатию F7.
 *
 * Содержит:
 * - Палитру цветов портала (левый верхний угол)
 * - Список онлайн игроков с головами (центр/правая часть)
 * - Кнопки приглашения (иконка письма)
 * - Скроллбар для прокрутки списка
 */
@Environment(EnvType.CLIENT)
public class PocketDimensionScreen extends class_437 {

    // ============================================================
    //  Константы размеров
    // ============================================================

    private static final int BACKGROUND_WIDTH = 350;
    private static final int BACKGROUND_HEIGHT = 250;
    private static final int PALETTE_X = 10;
    private static final int PALETTE_Y = 30;
    private static final int COLOR_BUTTON_SIZE = 18;
    private static final int COLOR_BUTTON_SPACING = 2;
    private static final int COLORS_PER_ROW = 4;

    private static final int PLAYER_LIST_X = 100;
    private static final int PLAYER_LIST_Y = 30;
    private static final int PLAYER_LIST_WIDTH = 240;
    private static final int PLAYER_LIST_HEIGHT = 200;
    private static final int PLAYER_ENTRY_HEIGHT = 28;

    private static final int SCROLLBAR_WIDTH = 6;
    private static final int SCROLLBAR_HEIGHT = 200;
    private static final int SCROLLBAR_X = PLAYER_LIST_X + PLAYER_LIST_WIDTH + 2;

    // ============================================================
    //  Цвета палитры (соответствуют PortalColor)
    // ============================================================

    private static final Map<PortalColor, Integer> COLOR_MAP = new LinkedHashMap<>() {{
        put(PortalColor.WHITE, 0xFFFFFFFF);
        put(PortalColor.LIGHT_GRAY, 0xFFAAAAAA);
        put(PortalColor.GRAY, 0xFF555555);
        put(PortalColor.BLACK, 0xFF1A1A1A);
        put(PortalColor.BROWN, 0xFF8B4513);
        put(PortalColor.RED, 0xFFFF3333);
        put(PortalColor.ORANGE, 0xFFFF8800);
        put(PortalColor.YELLOW, 0xFFFFFF33);
        put(PortalColor.LIME, 0xFF88FF33);
        put(PortalColor.GREEN, 0xFF33AA33);
        put(PortalColor.CYAN, 0xFF33CCCC);
        put(PortalColor.LIGHT_BLUE, 0xFF6699FF);
        put(PortalColor.BLUE, 0xFF3355FF);
        put(PortalColor.PURPLE, 0xFF9933FF);
        put(PortalColor.MAGENTA, 0xFFFF33FF);
        put(PortalColor.PINK, 0xFFFF99CC);
    }};

    // ============================================================
    //  Поля
    // ============================================================

    private final class_310 client;
    private List<String> onlinePlayers = new ArrayList<>();
    private float scrollOffset = 0.0f;
    private boolean isDraggingScrollbar = false;
    private int selectedColorIndex = 5; // RED по умолчанию

    // Кнопки приглашения для каждого игрока
    private final Map<String, class_4185> inviteButtons = new HashMap<>();

    // Кэш голов игроков
    private final Map<String, class_2960> playerHeadCache = new HashMap<>();

    // ============================================================
    //  Конструктор
    // ============================================================

    public PocketDimensionScreen() {
        super(class_2561.method_43471("pocketislands.gui.pocket_dimension.title"));
        this.client = class_310.method_1551();
        this.onlinePlayers = new ArrayList<>(NetworkHandlerClient.getOnlinePlayers());
    }

    // ============================================================
    //  Инициализация
    // ============================================================

    @Override
    protected void method_25426() { // init
        super.method_25426();
        rebuildInviteButtons();
    }

    private void rebuildInviteButtons() {
        // Удаляем старые кнопки
        for (class_4185 button : inviteButtons.values()) {
            this.method_37067(button); // remove
        }
        inviteButtons.clear();

        // Создаем новые кнопки для каждого игрока
        for (String playerName : onlinePlayers) {
            class_4185 button = class_4185.method_46430(
                class_2561.method_43470("✉"), // Иконка письма
                btn -> sendInvitation(playerName)
            ).method_46434(0, 0, 20, 20).method_46431();
            button.field_22763 = false; // visible = false (будет показан при рендере)
            inviteButtons.put(playerName, button);
            this.method_37063(button); // addDrawableChild
        }
    }

    // ============================================================
    //  Рендеринг
    // ============================================================

    @Override
    public void method_25394(class_1675 guiGraphics, int mouseX, int mouseY, float delta) { // render
        // Фон
        this.method_25294(guiGraphics, 0, 0, this.field_22789, this.field_22788, 0xCC000000); // fill

        int panelX = (this.field_22789 - BACKGROUND_WIDTH) / 2;
        int panelY = (this.field_22788 - BACKGROUND_HEIGHT) / 2;

        // Основная панель
        guiGraphics.method_25294(panelX, panelY, panelX + BACKGROUND_WIDTH, panelY + BACKGROUND_HEIGHT, 0xFF1A1A2E);
        guiGraphics.method_25298(panelX, panelY, panelX + BACKGROUND_WIDTH, panelY + BACKGROUND_HEIGHT, 0xFF4A4A6A);

        // Заголовок
        class_2561 title = class_2561.method_43471("pocketislands.gui.pocket_dimension.title")
            .method_27692(class_124.field_1065);
        guiGraphics.method_27033(this.field_22793, title,
            panelX + BACKGROUND_WIDTH / 2 - this.field_22793.method_1727(title.getString()) / 2,
            panelY + 8, 0xFFFFFF);

        // Рендер компонентов
        renderColorPalette(guiGraphics, panelX + PALETTE_X, panelY + PALETTE_Y, mouseX, mouseY);
        renderPlayerList(guiGraphics, panelX + PLAYER_LIST_X, panelY + PLAYER_LIST_Y, mouseX, mouseY);
        renderScrollbar(guiGraphics, panelX + SCROLLBAR_X, panelY + PLAYER_LIST_Y);

        super.method_25394(guiGraphics, mouseX, mouseY, delta);
    }

    // ============================================================
    //  Рендер палитры цветов
    // ============================================================

    private void renderColorPalette(class_1675 guiGraphics, int startX, int startY, int mouseX, int mouseY) {
        // Заголовок палитры
        class_2561 paletteTitle = class_2561.method_43471("pocketislands.gui.palette.title")
            .method_27692(class_124.field_1075);
        guiGraphics.method_27033(this.field_22793, paletteTitle, startX, startY - 15, 0xFFFFFF);

        PortalColor[] colors = PortalColor.values();
        for (int i = 0; i < colors.length; i++) {
            int row = i / COLORS_PER_ROW;
            int col = i % COLORS_PER_ROW;
            int x = startX + col * (COLOR_BUTTON_SIZE + COLOR_BUTTON_SPACING);
            int y = startY + row * (COLOR_BUTTON_SIZE + COLOR_BUTTON_SPACING);

            PortalColor color = colors[i];
            int colorValue = COLOR_MAP.getOrDefault(color, 0xFFFFFFFF);

            // Фон кнопки
            boolean isHovered = mouseX >= x && mouseX < x + COLOR_BUTTON_SIZE && mouseY >= y && mouseY < y + COLOR_BUTTON_SIZE;
            boolean isSelected = i == selectedColorIndex;

            int bgColor = isSelected ? 0xFF666666 : (isHovered ? 0xFF444444 : 0xFF2A2A2E);
            guiGraphics.method_25294(x, y, x + COLOR_BUTTON_SIZE, y + COLOR_BUTTON_SIZE, bgColor);

            // Цветной квадрат
            int colorSize = COLOR_BUTTON_SIZE - 4;
            guiGraphics.method_25294(x + 2, y + 2, x + 2 + colorSize, y + 2 + colorSize, colorValue);

            // Рамка выбранного
            if (isSelected) {
                guiGraphics.method_25298(x, y, x + COLOR_BUTTON_SIZE, y + COLOR_BUTTON_SIZE, 0xFFFFFFFF);
            }
        }

        // Название выбранного цвета
        if (selectedColorIndex >= 0 && selectedColorIndex < colors.length) {
            PortalColor selected = colors[selectedColorIndex];
            class_2561 colorName = class_2561.method_43471("pocketislands.portal.color." + selected.method_15434())
                .method_27692(class_124.field_1054);
            int nameY = startY + (colors.length / COLORS_PER_ROW + 1) * (COLOR_BUTTON_SIZE + COLOR_BUTTON_SPACING) + 5;
            guiGraphics.method_27033(this.field_22793, colorName, startX, nameY, 0xCCCCCC);
        }
    }

    // ============================================================
    //  Рендер списка игроков
    // ============================================================

    private void renderPlayerList(class_1675 guiGraphics, int startX, int startY, int mouseX, int mouseY) {
        // Фон списка
        guiGraphics.method_25294(startX, startY, startX + PLAYER_LIST_WIDTH, startY + PLAYER_LIST_HEIGHT, 0xFF0E0E1A);

        // Заголовок списка
        class_2561 listTitle = class_2561.method_43471("pocketislands.gui.players.title")
            .method_27692(class_124.field_1075);
        guiGraphics.method_27033(this.field_22793, listTitle, startX, startY - 15, 0xFFFFFF);

        // Подсчет видимых элементов
        int maxVisiblePlayers = PLAYER_LIST_HEIGHT / PLAYER_ENTRY_HEIGHT;
        int totalPlayers = onlinePlayers.size();
        int maxScroll = Math.max(0, totalPlayers - maxVisiblePlayers);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        // Рендер видимых игроков
        int startIndex = (int) scrollOffset;
        int endIndex = Math.min(startIndex + maxVisiblePlayers + 1, totalPlayers);

        for (int i = startIndex; i < endIndex; i++) {
            String playerName = onlinePlayers.get(i);
            int entryY = startY + (i - startIndex) * PLAYER_ENTRY_HEIGHT;

            // Проверка выхода за границы
            if (entryY + PLAYER_ENTRY_HEIGHT > startY + PLAYER_LIST_HEIGHT) break;

            // Фон записи (чередование)
            int bgColor = (i % 2 == 0) ? 0xFF151525 : 0xFF1A1A2E;
            boolean isHovered = mouseX >= startX && mouseX < startX + PLAYER_LIST_WIDTH &&
                               mouseY >= entryY && mouseY < entryY + PLAYER_ENTRY_HEIGHT;
            if (isHovered) {
                bgColor = 0xFF2A2A4A;
            }
            guiGraphics.method_25294(startX, entryY, startX + PLAYER_LIST_WIDTH, entryY + PLAYER_ENTRY_HEIGHT, bgColor);

            // Рендер головы игрока
            renderPlayerHead(guiGraphics, startX + 4, entryY + 4, playerName);

            // Никнейм
            class_2561 nameText = class_2561.method_43470(playerName);
            guiGraphics.method_27033(this.field_22793, nameText, startX + 24, entryY + 8, 0xFFFFFF);

            // Кнопка приглашения (письмо)
            class_4185 inviteButton = inviteButtons.get(playerName);
            if (inviteButton != null) {
                inviteButton.field_22761 = startX + PLAYER_LIST_WIDTH - 28; // x
                inviteButton.field_22762 = entryY + 4; // y
                inviteButton.field_22763 = true; // visible
            }
        }

        // Сообщение если список пуст
        if (onlinePlayers.isEmpty()) {
            class_2561 emptyText = class_2561.method_43471("pocketislands.gui.players.empty")
                .method_27692(class_124.field_1080);
            guiGraphics.method_27033(this.field_22793, emptyText,
                startX + PLAYER_LIST_WIDTH / 2 - this.field_22793.method_1727(emptyText.getString()) / 2,
                startY + PLAYER_LIST_HEIGHT / 2, 0x888888);
        }
    }

    // ============================================================
    //  Рендер головы игрока
    // ============================================================

    private void renderPlayerHead(class_1675 guiGraphics, int x, int y, String playerName) {
        class_2960 skinTexture = playerHeadCache.get(playerName);

        if (skinTexture == null) {
            // Попытка загрузить скин
            loadPlayerSkin(playerName);
            // Пока загружается - используем стандартную текстуру
            skinTexture = new class_2960("textures/entity/steve.png");
        }

        // Рендер текстуры головы (16x16 пикселей, но рендерим как 20x20)
        guiGraphics.method_25297(skinTexture, x, y, 0, 8, 8, 20, 20, 64, 64);
        // Второй слой головы
        guiGraphics.method_25297(skinTexture, x, y, 40, 8, 20, 20, 64, 64);
    }

    private void loadPlayerSkin(String playerName) {
        // Асинхронная загрузка скина
        new Thread(() -> {
            try {
                class_1046 sessionService = this.client.method_1529(); // getSessionService
                GameProfile profile = new GameProfile(null, playerName);
                Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> textures =
                    sessionService.getTextures(profile, false);

                if (textures.containsKey(MinecraftProfileTexture.Type.SKIN)) {
                    MinecraftProfileTexture skinTexture = textures.get(MinecraftProfileTexture.Type.SKIN);
                    class_2960 textureId = this.client.method_1572(skinTexture.getUrl(), new class_2960("skins/" + playerName));
                    playerHeadCache.put(playerName, textureId);
                }
            } catch (Exception e) {
                // Используем стандартную текстуру при ошибке
            }
        }).start();
    }

    // ============================================================
    //  Рендер скроллбара
    // ============================================================

    private void renderScrollbar(class_1675 guiGraphics, int x, int y) {
        int maxVisiblePlayers = PLAYER_LIST_HEIGHT / PLAYER_ENTRY_HEIGHT;
        int totalPlayers = onlinePlayers.size();

        if (totalPlayers <= maxVisiblePlayers) {
            // Скроллбар не нужен
            guiGraphics.method_25294(x, y, x + SCROLLBAR_WIDTH, y + SCROLLBAR_HEIGHT, 0xFF0E0E1A);
            return;
        }

        // Фон скроллбара
        guiGraphics.method_25294(x, y, x + SCROLLBAR_WIDTH, y + SCROLLBAR_HEIGHT, 0xFF0E0E1A);

        // Ползунок
        int maxScroll = totalPlayers - maxVisiblePlayers;
        float scrollPercent = maxScroll > 0 ? scrollOffset / maxScroll : 0;
        int thumbHeight = Math.max(20, (int) ((float) maxVisiblePlayers / totalPlayers * SCROLLBAR_HEIGHT));
        int thumbY = y + (int) (scrollPercent * (SCROLLBAR_HEIGHT - thumbHeight));

        guiGraphics.method_25294(x, thumbY, x + SCROLLBAR_WIDTH, thumbY + thumbHeight, 0xFF666688);
        guiGraphics.method_25298(x, thumbY, x + SCROLLBAR_WIDTH, thumbY + thumbHeight, 0xFF8888AA);
    }

    // ============================================================
    //  Обработка ввода
    // ============================================================

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) { // mouseClicked
        int panelX = (this.field_22789 - BACKGROUND_WIDTH) / 2;
        int panelY = (this.field_22788 - BACKGROUND_HEIGHT) / 2;

        // Проверка клика по палитре цветов
        if (handlePaletteClick(panelX + PALETTE_X, panelY + PALETTE_Y, (int) mouseX, (int) mouseY)) {
            return true;
        }

        // Проверка клика по скроллбару
        int scrollbarX = panelX + SCROLLBAR_X;
        int scrollbarY = panelY + PLAYER_LIST_Y;
        if (mouseX >= scrollbarX && mouseX < scrollbarX + SCROLLBAR_WIDTH &&
            mouseY >= scrollbarY && mouseY < scrollbarY + SCROLLBAR_HEIGHT) {
            isDraggingScrollbar = true;
            updateScrollFromMouse((int) mouseY, scrollbarY);
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button) { // mouseReleased
        if (isDraggingScrollbar) {
            isDraggingScrollbar = false;
            return true;
        }
        return super.method_25403(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) { // mouseScrolled
        int panelX = (this.field_22789 - BACKGROUND_WIDTH) / 2;
        int panelY = (this.field_22788 - BACKGROUND_HEIGHT) / 2;
        int listX = panelX + PLAYER_LIST_X;
        int listY = panelY + PLAYER_LIST_Y;

        // Проверка что мышь над списком игроков
        if (mouseX >= listX && mouseX < listX + PLAYER_LIST_WIDTH &&
            mouseY >= listY && mouseY < listY + PLAYER_LIST_HEIGHT) {

            int maxVisiblePlayers = PLAYER_LIST_HEIGHT / PLAYER_ENTRY_HEIGHT;
            int maxScroll = Math.max(0, onlinePlayers.size() - maxVisiblePlayers);

            scrollOffset -= verticalAmount;
            scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
            return true;
        }

        return super.method_25406(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY, double deltaX, double deltaY) { // mouseDragged
        if (isDraggingScrollbar) {
            int panelY = (this.field_22788 - BACKGROUND_HEIGHT) / 2;
            int scrollbarY = panelY + PLAYER_LIST_Y;
            updateScrollFromMouse((int) mouseY, scrollbarY);
            return true;
        }
        return super.method_25405(mouseX, mouseY, deltaX, deltaY);
    }

    private void updateScrollFromMouse(int mouseY, int scrollbarY) {
        int maxVisiblePlayers = PLAYER_LIST_HEIGHT / PLAYER_ENTRY_HEIGHT;
        int maxScroll = Math.max(0, onlinePlayers.size() - maxVisiblePlayers);

        if (maxScroll > 0) {
            float scrollPercent = (float) (mouseY - scrollbarY) / SCROLLBAR_HEIGHT;
            scrollPercent = Math.max(0, Math.min(scrollPercent, 1));
            scrollOffset = scrollPercent * maxScroll;
        }
    }

    // ============================================================
    //  Обработка клика по палитре
    // ============================================================

    private boolean handlePaletteClick(int startX, int startY, int mouseX, int mouseY) {
        PortalColor[] colors = PortalColor.values();
        for (int i = 0; i < colors.length; i++) {
            int row = i / COLORS_PER_ROW;
            int col = i % COLORS_PER_ROW;
            int x = startX + col * (COLOR_BUTTON_SIZE + COLOR_BUTTON_SPACING);
            int y = startY + row * (COLOR_BUTTON_SIZE + COLOR_BUTTON_SPACING);

            if (mouseX >= x && mouseX < x + COLOR_BUTTON_SIZE &&
                mouseY >= y && mouseY < y + COLOR_BUTTON_SIZE) {
                selectedColorIndex = i;
                sendColorChange(colors[i]);
                return true;
            }
        }
        return false;
    }

    // ============================================================
    //  Сетевые запросы
    // ============================================================

    private void sendColorChange(PortalColor color) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(color.method_15434()); // writeString
        ModNetworking.sendToServer(ModNetworking.CHANGE_PORTAL_COLOR, buf);
    }

    private void sendInvitation(String targetName) {
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(targetName); // writeString
        ModNetworking.sendToServer(ModNetworking.SEND_INVITATION_REQUEST, buf);
    }

    // ============================================================
    //  Обновление данных
    // ============================================================

    public void updatePlayerList(List<String> players) {
        this.onlinePlayers = new ArrayList<>(players);
        rebuildInviteButtons();
    }

    // ============================================================
    //  Прочее
    // ============================================================

    @Override
    public boolean method_25401() { // shouldCloseOnEsc
        return true;
    }

    @Override
    public boolean method_25422() { // shouldPause
        return false;
    }
}
