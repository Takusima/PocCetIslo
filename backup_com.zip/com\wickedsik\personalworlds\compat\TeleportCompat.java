package com.wickedsik.personalworlds.compat;

import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5454;

public final class TeleportCompat {
   private TeleportCompat() {
   }

   public static void teleport(class_3222 player, class_3218 targetWorld, class_243 position, float yaw, float pitch) {
      class_5454 target = new class_5454(position, class_243.field_1353, yaw, pitch);
      teleport(player, targetWorld, target);
   }

   public static void teleport(class_3222 player, class_3218 targetWorld, class_5454 target) {
      FabricDimensions.teleport(player, targetWorld, target);
   }

   public static void teleportToBlock(class_3222 player, class_3218 targetWorld, class_2338 blockPos, float yaw, float pitch) {
      class_243 position = class_243.method_24953(blockPos);
      teleport(player, targetWorld, position, yaw, pitch);
   }

   public static void teleportPreserveRotation(class_3222 player, class_3218 targetWorld, class_243 position) {
      teleport(player, targetWorld, position, player.method_36454(), player.method_36455());
   }

   public static void teleportToBlockPreserveRotation(class_3222 player, class_3218 targetWorld, class_2338 blockPos) {
      class_243 position = class_243.method_24953(blockPos);
      teleportPreserveRotation(player, targetWorld, position);
   }
}
