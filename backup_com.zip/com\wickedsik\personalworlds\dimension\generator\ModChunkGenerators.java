package com.wickedsik.personalworlds.dimension.generator;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModChunkGenerators {
   public static final class_2960 VOID_ISLAND_ID = IdentifierCompat.modId("void_island");

   public static void register() {
      class_2378.method_10230(class_7923.field_41157, VOID_ISLAND_ID, VoidIslandChunkGenerator.CODEC);
      PersonalWorldsMod.LOGGER.info("Registered chunk generators");
   }
}
