package com.wickedsik.personalworlds.mixin;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.network.NetworkHandler;
import net.minecraft.class_3222;
import net.minecraft.class_7470;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Серверный миксин для перехвата входящих чат-сообщений.
 * Перехватывает сообщения "Prunus" и "Malus" (без символа /)
 * и перенаправляет их в NetworkHandler для обработки.
 *
 * Миксинится в ServerPlayNetworkHandler (class_7470) для перехвата
 * метода обработки чат-сообщений до их широковещательной рассылки.
 */
@Mixin(class_7470.class)
public class ServerPlayNetworkHandlerMixin {

    /**
     * Ссылка на серверного игрока, связанного с этим обработчиком.
     */
    @Shadow
    public class_3222 field_37268;

    /**
     * Перехват входящего чат-сообщения.
     * Вызывается когда клиент отправляет чат-сообщение на сервер.
     * Если сообщение является командой "Prunus" или "Malus",
     * отменяет стандартную обработку и выполняет телепортацию.
     *
     * @param message Текст сообщения
     * @param acknowledgement Подтверждение доставки
     * @param ci CallbackInfo для отмены обработки
     */
    @Inject(method = "method_45064", at = @At("HEAD"), cancellable = true)
    private void onChatMessage(String message, class_7470.class_7648 acknowledgement, CallbackInfo ci) {
        if (message == null || message.isEmpty()) {
            return;
        }

        String trimmedMessage = message.trim();
        String commandToCheck = trimmedMessage.toLowerCase();

        boolean isPrunus = commandToCheck.equals("prunus");
        boolean isMalus = commandToCheck.equals("malus");

        if (isPrunus || isMalus) {
            PersonalWorldsMod.LOGGER.info("Intercepted chat command '{}' from player: {}", trimmedMessage, this.field_37268.method_5477().getString());

            // Отменяем стандартную обработку - сообщение не будет отправлено в чат
            ci.cancel();

            // Выполняем команду через NetworkHandler
            if (isPrunus) {
                NetworkHandler.handlePrunusCommand(this.field_37268);
            } else {
                NetworkHandler.handleMalusCommand(this.field_37268);
            }
        }
    }
}
