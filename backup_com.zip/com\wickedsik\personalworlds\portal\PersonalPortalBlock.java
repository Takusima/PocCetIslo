package com.wickedsik.personalworlds.portal;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_2350.class_2351;

public class PersonalPortalBlock extends class_2248 {
   public static final class_2754<class_2350.class_2351> AXIS;
   public static final class_2754<PortalColor> COLOR;
   protected static final class_265 X_SHAPE;
   protected static final class_265 Z_SHAPE;
   private static final int PORTAL_COOLDOWN = 100;

   public PersonalPortalBlock(class_4970.class_2251 settings) {
      super(settings);
      this.method_9590((class_2680)((class_2680)((class_2680)this.method_9595().method_11664()).method_11657(AXIS, class_2351.field_11048)).method_11657(COLOR, PortalColor.RED));
   }

   protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{AXIS, COLOR});
   }

   public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
      return state.method_11654(AXIS) == class_2351.field_11051 ? Z_SHAPE : X_SHAPE;
   }

   public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
      this.handleEntityCollision(state, world, pos, entity);
   }

   private void handleEntityCollision(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
      if (!world.method_8608()) {
         if (entity instanceof class_3222) {
            class_3222 player = (class_3222)entity;
            if (player.method_5765()) {
               player.method_7353(class_2561.method_43471("pocketislands.portal.dismount_required"), true);
            } else if (!player.method_30230()) {
               PortalHelper.handlePortalEntry(player, pos);
               player.method_51850(100);
            }
         }
      }
   }

   public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
      this.handleNeighborUpdate(state, world, pos);
   }

   private void handleNeighborUpdate(class_2680 state, class_1937 world, class_2338 pos) {
      if (!world.method_8608()) {
         class_2350.class_2351 axis = (class_2350.class_2351)state.method_11654(AXIS);
         if (!PortalHelper.isFrameValidForPortal(world, pos, axis)) {
            world.method_8650(pos, false);
            PersonalWorldsMod.LOGGER.debug("Portal block removed at {} - frame broken", pos);
         }

      }
   }

   public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
      if (!state.method_27852(newState.method_26204()) && world instanceof class_3218 serverWorld) {
         PortalOwnershipManager ownershipManager = PortalOwnershipManager.get(serverWorld.method_8503());
         ownershipManager.removePortal(world, pos);
      }

      super.method_9536(state, world, pos, newState, moved);
   }

   public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
      return true;
   }

   public static class_2350.class_2351 getAxis(class_2680 state) {
      return (class_2350.class_2351)state.method_11654(AXIS);
   }

   static {
      AXIS = class_2741.field_12529;
      COLOR = class_2754.method_11850("color", PortalColor.class);
      X_SHAPE = class_2248.method_9541((double)0.0F, (double)0.0F, (double)6.0F, (double)16.0F, (double)16.0F, (double)10.0F);
      Z_SHAPE = class_2248.method_9541((double)6.0F, (double)0.0F, (double)0.0F, (double)10.0F, (double)16.0F, (double)16.0F);
   }
}
