package com.wickedsik.personalworlds.dimension;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import net.minecraft.class_2338;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;

public class DimensionMetadataFile {
   private static final String FILENAME = "personalworlds_metadata.json";
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final int METADATA_VERSION = 1;

   public static void write(MinecraftServer server, PlayerDimensionData data) {
      Path metadataPath = getMetadataPath(server, data.ownerUuid());
      if (metadataPath != null) {
         try {
            Files.createDirectories(metadataPath.getParent());
            MetadataJson json = DimensionMetadataFile.MetadataJson.fromPlayerData(data);
            String content = GSON.toJson(json);
            Files.writeString(metadataPath, content);
            PersonalWorldsMod.LOGGER.debug("Wrote dimension metadata for {} to {}", data.ownerName(), metadataPath);
         } catch (IOException e) {
            PersonalWorldsMod.LOGGER.error("Failed to write dimension metadata for {}: {}", data.ownerUuid(), e.getMessage());
         }

      }
   }

   public static Optional<PlayerDimensionData> read(MinecraftServer server, UUID playerUuid) {
      Path metadataPath = getMetadataPath(server, playerUuid);
      if (metadataPath != null && Files.exists(metadataPath, new LinkOption[0])) {
         try {
            String content = Files.readString(metadataPath);
            MetadataJson json = (MetadataJson)GSON.fromJson(content, MetadataJson.class);
            if (json != null && json.ownerUuid != null) {
               PlayerDimensionData data = json.toPlayerData();
               PersonalWorldsMod.LOGGER.debug("Read dimension metadata for {} from {}", data.ownerName(), metadataPath);
               return Optional.of(data);
            } else {
               PersonalWorldsMod.LOGGER.warn("Metadata file for {} is empty or invalid", playerUuid);
               return Optional.empty();
            }
         } catch (IOException e) {
            PersonalWorldsMod.LOGGER.error("Failed to read dimension metadata for {}: {}", playerUuid, e.getMessage());
            return Optional.empty();
         } catch (JsonSyntaxException e) {
            PersonalWorldsMod.LOGGER.warn("Corrupted metadata file for {}: {}", playerUuid, e.getMessage());
            return Optional.empty();
         } catch (IllegalArgumentException e) {
            PersonalWorldsMod.LOGGER.warn("Invalid data in metadata file for {}: {}", playerUuid, e.getMessage());
            return Optional.empty();
         }
      } else {
         return Optional.empty();
      }
   }

   public static boolean exists(MinecraftServer server, UUID playerUuid) {
      Path metadataPath = getMetadataPath(server, playerUuid);
      return metadataPath != null && Files.exists(metadataPath, new LinkOption[0]);
   }

   public static void delete(MinecraftServer server, UUID playerUuid) {
      Path metadataPath = getMetadataPath(server, playerUuid);
      if (metadataPath != null) {
         try {
            if (Files.deleteIfExists(metadataPath)) {
               PersonalWorldsMod.LOGGER.debug("Deleted dimension metadata for {}", playerUuid);
            }
         } catch (IOException e) {
            PersonalWorldsMod.LOGGER.error("Failed to delete dimension metadata for {}: {}", playerUuid, e.getMessage());
         }

      }
   }

   private static Path getMetadataPath(MinecraftServer server, UUID playerUuid) {
      try {
         Path worldRoot = server.method_27050(class_5218.field_24188);
         String var10000 = playerUuid.toString();
         String folderName = "pw_" + var10000.replace("-", "");
         return worldRoot.resolve("dimensions").resolve("personalworlds").resolve(folderName).resolve("personalworlds_metadata.json");
      } catch (Exception e) {
         PersonalWorldsMod.LOGGER.error("Failed to determine metadata path for {}: {}", playerUuid, e.getMessage());
         return null;
      }
   }

   public static Path getDimensionFolderPath(MinecraftServer server, UUID playerUuid) {
      Path worldRoot = server.method_27050(class_5218.field_24188);
      String var10000 = playerUuid.toString();
      String folderName = "pw_" + var10000.replace("-", "");
      return worldRoot.resolve("dimensions").resolve("personalworlds").resolve(folderName);
   }

   public static Path getDimensionsRootPath(MinecraftServer server) {
      Path worldRoot = server.method_27050(class_5218.field_24188);
      return worldRoot.resolve("dimensions").resolve("personalworlds");
   }

   public static boolean deleteDimensionFolder(MinecraftServer server, UUID playerUuid) {
      Path dimensionFolder = getDimensionFolderPath(server, playerUuid);
      if (!Files.exists(dimensionFolder, new LinkOption[0])) {
         PersonalWorldsMod.LOGGER.debug("Dimension folder does not exist: {}", dimensionFolder);
         return false;
      } else {
         try {
            deleteDirectoryRecursively(dimensionFolder);
            PersonalWorldsMod.LOGGER.info("Permanently deleted dimension folder for {}: {}", playerUuid, dimensionFolder);
            return true;
         } catch (IOException e) {
            PersonalWorldsMod.LOGGER.error("Failed to delete dimension folder for {}: {}", playerUuid, e.getMessage());
            return false;
         }
      }
   }

   private static void deleteDirectoryRecursively(Path directory) throws IOException {
      if (Files.exists(directory, new LinkOption[0])) {
         Stream<Path> stream = Files.walk(directory);

         try {
            stream.sorted((a, b) -> b.compareTo(a)).forEach((path) -> {
               try {
                  Files.delete(path);
                  PersonalWorldsMod.LOGGER.debug("Deleted: {}", path);
               } catch (IOException e) {
                  PersonalWorldsMod.LOGGER.warn("Failed to delete: {} - {}", path, e.getMessage());
               }

            });
         } catch (Throwable var5) {
            if (stream != null) {
               try {
                  stream.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (stream != null) {
            stream.close();
         }

      }
   }

   private static class MetadataJson {
      String ownerUuid;
      String ownerName;
      String dimensionId;
      long createdAt;
      int spawnX;
      int spawnY;
      int spawnZ;
      String generatorType;
      Integer portalTypeIndex;
      int metadataVersion;

      static MetadataJson fromPlayerData(PlayerDimensionData data) {
         MetadataJson json = new MetadataJson();
         json.ownerUuid = data.ownerUuid().toString();
         json.ownerName = data.ownerName();
         json.dimensionId = data.dimensionId().toString();
         json.createdAt = data.createdAt();
         json.spawnX = data.spawnPoint().method_10263();
         json.spawnY = data.spawnPoint().method_10264();
         json.spawnZ = data.spawnPoint().method_10260();
         json.generatorType = data.generatorType().name();
         json.portalTypeIndex = data.portalTypeIndex();
         json.metadataVersion = 1;
         return json;
      }

      PlayerDimensionData toPlayerData() {
         int portalType = this.portalTypeIndex != null ? this.portalTypeIndex : 0;
         return new PlayerDimensionData(UUID.fromString(this.ownerUuid), this.ownerName, IdentifierCompat.fromNbtString(this.dimensionId), this.createdAt, new class_2338(this.spawnX, this.spawnY, this.spawnZ), WorldGenType.fromString(this.generatorType), portalType);
      }
   }
}
