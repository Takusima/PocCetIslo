package com.wickedsik.personalworlds.player;

import com.wickedsik.personalworlds.compat.NbtCompat;
import java.util.UUID;
import net.minecraft.class_2487;

public record InvitationData(UUID ownerUuid, String ownerName, long invitedAt, boolean alwaysWelcome) {
   public InvitationData(UUID ownerUuid, String ownerName, long invitedAt) {
      this(ownerUuid, ownerName, invitedAt, false);
   }

   public InvitationData withToggledAlwaysWelcome() {
      return new InvitationData(this.ownerUuid, this.ownerName, this.invitedAt, !this.alwaysWelcome);
   }

   public class_2487 toNbt() {
      class_2487 nbt = new class_2487();
      NbtCompat.putUuid(nbt, "OwnerUuid", this.ownerUuid);
      nbt.method_10582("OwnerName", this.ownerName);
      nbt.method_10544("InvitedAt", this.invitedAt);
      nbt.method_10556("AlwaysWelcome", this.alwaysWelcome);
      return nbt;
   }

   public static InvitationData fromNbt(class_2487 nbt) {
      boolean alwaysWelcome = NbtCompat.getBoolean(nbt, "AlwaysWelcome", false);
      return new InvitationData(NbtCompat.getUuid(nbt, "OwnerUuid"), NbtCompat.getString(nbt, "OwnerName", "Unknown"), NbtCompat.getLong(nbt, "InvitedAt", 0L), alwaysWelcome);
   }
}
