package com.wickedsik.personalworlds.player;

import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.compat.NbtCompat;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public record ReturnData(class_5321<class_1937> dimension, class_2338 position, float yaw, float pitch) {
   public class_2487 toNbt() {
      class_2487 nbt = new class_2487();
      nbt.method_10582("Dimension", this.dimension.method_29177().toString());
      nbt.method_10569("X", this.position.method_10263());
      nbt.method_10569("Y", this.position.method_10264());
      nbt.method_10569("Z", this.position.method_10260());
      nbt.method_10548("Yaw", this.yaw);
      nbt.method_10548("Pitch", this.pitch);
      return nbt;
   }

   public static ReturnData fromNbt(class_2487 nbt) {
      class_2960 dimId = IdentifierCompat.fromNbtString(NbtCompat.getString(nbt, "Dimension", "minecraft:overworld"));
      class_5321<class_1937> dimension = class_5321.method_29179(class_7924.field_41223, dimId);
      class_2338 position = new class_2338(NbtCompat.getInt(nbt, "X", 0), NbtCompat.getInt(nbt, "Y", 64), NbtCompat.getInt(nbt, "Z", 0));
      float yaw = NbtCompat.getFloat(nbt, "Yaw", 0.0F);
      float pitch = NbtCompat.getFloat(nbt, "Pitch", 0.0F);
      return new ReturnData(dimension, position, yaw, pitch);
   }
}
