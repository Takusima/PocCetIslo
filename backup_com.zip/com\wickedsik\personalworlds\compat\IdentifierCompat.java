package com.wickedsik.personalworlds.compat;

import java.util.UUID;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public final class IdentifierCompat {
   private IdentifierCompat() {
   }

   public static class_2960 create(String namespace, String path) {
      return new class_2960(namespace, path);
   }

   public static class_2960 modId(String path) {
      return create("personalworlds", path);
   }

   public static class_2960 dimensionId(UUID playerUuid) {
      return modId("pw_" + playerUuid.toString());
   }

   public static @Nullable class_2960 tryParse(String id) {
      return id != null && !id.isEmpty() ? class_2960.method_12829(id) : null;
   }

   public static class_2960 fromNbtString(String value) {
      return new class_2960(value);
   }
}
