package com.wickedsik.personalworlds.client.screen;

import com.wickedsik.personalworlds.network.ModNetworking;
import com.wickedsik.personalworlds.network.NetworkHandlerClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Экран запроса на посещение карманного измерения.
 * Показывается когда другой игрок хочет прийти к вам в измерение.
 * Содержит кнопки "Принять" и "Отказ".
 */
@Environment(EnvType.CLIENT)
public class VisitRequestScreen extends class_437 {

    private static final int BACKGROUND_WIDTH = 300;
    private static final int BACKGROUND_HEIGHT = 120;

    private final String requesterName;
    private int x;
    private int y;

    public VisitRequestScreen(String requesterName) {
        super(class_2561.method_43471("pocketislands.gui.visit_request.title"));
        this.requesterName = requesterName;
    }

    @Override
    protected void method_25426() { // init
        super.method_25426();

        this.x = (this.field_22789 - BACKGROUND_WIDTH) / 2; // width
        this.y = (this.field_22788 - BACKGROUND_HEIGHT) / 2; // height

        // Кнопка "Принять"
        class_4185 acceptButton = class_4185.method_46430(
            class_2561.method_43471("pocketislands.gui.visit_request.accept"),
            button -> handleAccept()
        ).method_46434(this.x + 20, this.y + 80, 120, 20).method_46431();

        // Кнопка "Отказ"
        class_4185 denyButton = class_4185.method_46430(
            class_2561.method_43471("pocketislands.gui.visit_request.deny"),
            button -> handleDeny()
        ).method_46434(this.x + 160, this.y + 80, 120, 20).method_46431();

        this.method_37063(acceptButton); // addDrawableChild
        this.method_37063(denyButton); // addDrawableChild
    }

    @Override
    public void method_25394(class_1675 guiGraphics, int mouseX, int mouseY, float delta) { // render
        // Фон
        this.method_25294(guiGraphics, 0, 0, this.field_22789, this.field_22788, 0x88000000); // fill

        // Панель
        guiGraphics.method_25294(this.x, this.y, this.x + BACKGROUND_WIDTH, this.y + BACKGROUND_HEIGHT, 0xFF1A1A2E);
        guiGraphics.method_25298(this.x, this.y, this.x + BACKGROUND_WIDTH, this.y + BACKGROUND_HEIGHT, 0xFF4A4A6A);

        // Заголовок
        class_2561 title = class_2561.method_43471("pocketislands.gui.visit_request.title")
            .method_27692(class_124.field_1065);
        guiGraphics.method_27033(this.field_22793, title, this.x + BACKGROUND_WIDTH / 2 - this.field_22793.method_1727(title.getString()) / 2, this.y + 10, 0xFFFFFF);

        // Текст запроса
        class_2561 requestText = class_2561.method_43469("pocketislands.gui.visit_request.message", new Object[]{requesterName})
            .method_27692(class_124.field_1054);
        guiGraphics.method_27033(this.field_22793, requestText, this.x + BACKGROUND_WIDTH / 2 - this.field_22793.method_1727(requestText.getString()) / 2, this.y + 35, 0xFFFFFF);

        // Подсказка
        class_2561 hint = class_2561.method_43471("pocketislands.gui.visit_request.hint")
            .method_27692(class_124.field_1080);
        guiGraphics.method_27033(this.field_22793, hint, this.x + BACKGROUND_WIDTH / 2 - this.field_22793.method_1727(hint.getString()) / 2, this.y + 58, 0xAAAAAA);

        super.method_25394(guiGraphics, mouseX, mouseY, delta);
    }

    private void handleAccept() {
        // Отправка ответа на сервер
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(requesterName); // writeString
        buf.method_10794(true); // writeBoolean - accepted
        ModNetworking.sendToServer(ModNetworking.INVITATION_RESPONSE, buf);

        NetworkHandlerClient.clearCurrentVisitRequest();
        this.field_22787.method_1507(null); // client.setScreen(null)
    }

    private void handleDeny() {
        // Отправка ответа на сервер
        class_2540 buf = ModNetworking.createBuf();
        buf.method_10804(requesterName); // writeString
        buf.method_10794(false); // writeBoolean - denied
        ModNetworking.sendToServer(ModNetworking.INVITATION_RESPONSE, buf);

        NetworkHandlerClient.clearVisitRequest();
        this.field_22787.method_1507(null); // client.setScreen(null)
    }

    @Override
    public boolean method_25401() { // shouldCloseOnEsc
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) { // keyPressed
        if (keyCode == 256) { // GLFW_KEY_ESCAPE
            handleDeny();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
