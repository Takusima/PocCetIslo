package com.wickedsik.personalworlds.compat;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public final class WorldCompat {
   private WorldCompat() {
   }

   public static class_2338 getSpawnPos(class_3218 world) {
      return world.method_43126();
   }

   public static int getTopY(class_1937 world) {
      return world.method_31600();
   }
}
