package com.wickedsik.personalworlds.compat;

import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public final class CommandCompat {
   private CommandCompat() {
   }

   public static boolean hasPermissionLevel(class_2168 source, int level) {
      return source.method_9259(level);
   }

   public static boolean hasPermissionLevel(class_3222 player, int level) {
      return player.method_5687(level);
   }

   public static Predicate<class_2168> requiresLevel(int level) {
      return (source) -> hasPermissionLevel(source, level);
   }
}
