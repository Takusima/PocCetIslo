package com.wickedsik.personalworlds.compat;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_26;

public final class PersistentStateCompat {
   private PersistentStateCompat() {
   }

   public static <T extends class_18> T getOrCreate(class_26 stateManager, String name, Supplier<T> constructor, Function<class_2487, T> deserializer) {
      return (T)stateManager.method_17924(deserializer, constructor, name);
   }
}
