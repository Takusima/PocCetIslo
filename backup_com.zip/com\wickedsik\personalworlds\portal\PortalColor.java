package com.wickedsik.personalworlds.portal;

import net.minecraft.class_3542;

public enum PortalColor implements class_3542 {
   WHITE("white"),
   LIGHT_GRAY("light_gray"),
   GRAY("gray"),
   BLACK("black"),
   BROWN("brown"),
   RED("red"),
   ORANGE("orange"),
   YELLOW("yellow"),
   LIME("lime"),
   GREEN("green"),
   CYAN("cyan"),
   LIGHT_BLUE("light_blue"),
   BLUE("blue"),
   PURPLE("purple"),
   MAGENTA("magenta"),
   PINK("pink");

   private final String name;

   private PortalColor(String name) {
      this.name = name;
   }

   public String method_15434() {
      return this.name;
   }

   public String getTextureName() {
      return "personal_portal_" + this.name;
   }

   public String getDisplayName() {
      String[] parts = this.name.split("_");
      StringBuilder sb = new StringBuilder();

      for(int i = 0; i < parts.length; ++i) {
         if (i > 0) {
            sb.append(" ");
         }

         if (!parts[i].isEmpty()) {
            sb.append(Character.toUpperCase(parts[i].charAt(0)));
            sb.append(parts[i].substring(1));
         }
      }

      return sb.toString();
   }

   public static PortalColor fromString(String name) {
      if (name != null && !name.isEmpty()) {
         for(PortalColor color : values()) {
            if (color.name.equalsIgnoreCase(name)) {
               return color;
            }
         }

         return RED;
      } else {
         return RED;
      }
   }

   // $FF: synthetic method
   private static PortalColor[] $values() {
      return new PortalColor[]{WHITE, LIGHT_GRAY, GRAY, BLACK, BROWN, RED, ORANGE, YELLOW, LIME, GREEN, CYAN, LIGHT_BLUE, BLUE, PURPLE, MAGENTA, PINK};
   }
}
