package com.wickedsik.personalworlds.compat;

import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

public final class TextCompat {
   private TextCompat() {
   }

   public static class_2558 runCommand(String command) {
      return new class_2558(class_2559.field_11750, command);
   }

   public static class_2558 suggestCommand(String command) {
      return new class_2558(class_2559.field_11745, command);
   }

   public static class_2558 openUrl(String url) {
      return new class_2558(class_2559.field_11749, url);
   }

   public static class_2568 showText(class_2561 text) {
      return new class_2568(class_5247.field_24342, text);
   }
}
