package com.wickedsik.personalworlds.util;

import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4969;

/**
 * Утилитарный класс для воспроизведения визуальных эффектов.
 * Содержит методы для создания частиц, звуков и эффектов статуса
 * при телепортации и активации портала.
 *
 * Включает:
 * - Красные редстоун-частицы (RedstoneParticleEffect) для эффекта "магического тумана"
 * - Эффект Blindness III для затемнения экрана при телепортации
 * - Эффект Nausea для тошноты после телепортации
 * - Звуковые эффекты для телепортации
 */
public final class VisualEffects {

    // Длительность эффекта тошноты в тиках (10 секунд = 200 тиков)
    private static final int NAUSEA_DURATION = 200;

    // Усиление эффекта слепоты (amplifier 2 = Blindness III)
    private static final int BLINDNESS_AMPLIFIER = 2;

    // Длительность эффекта слепоты в тиках (достаточно для перехода между измерениями)
    private static final int BLINDNESS_DURATION = 60;

    // Количество редстоун-частиц для эффекта тумана
    private static final int REDSTONE_PARTICLE_COUNT = 150;

    // Распределение частиц по осям
    private static final double REDSTONE_SPREAD_X = 0.8;
    private static final double REDSTONE_SPREAD_Y = 1.5;
    private static final double REDSTONE_SPREAD_Z = 0.8;

    // Скорость частиц
    private static final double REDSTONE_SPEED = 0.05;

    private VisualEffects() {
        // Utility class - предотвращаем создание экземпляров
    }

    /**
     * Воспроизводит эффекты отправления при телепортации.
     * Включает красные редстоун-частицы и звук.
     *
     * @param player Игрок, который телепортируется
     */
    public static void playTeleportDepartureEffects(class_3222 player) {
        ModConfig config = ModConfig.get();
        class_3218 world = EntityCompat.getServerWorld(player);
        class_243 pos = EntityCompat.getPos(player);

        // Красные редстоун-частицы для эффекта "магического тумана"
        if (config.enableTeleportParticles) {
            spawnRedstoneParticleFog(world, pos);
        }

        // Звук телепортации
        if (config.enableTeleportSounds) {
            world.method_8396(
                (class_1657) null,
                player.method_24515(),
                class_3417.field_14879,
                class_3419.field_15248,
                1.0F,
                1.0F
            );
        }
    }

    /**
     * Воспроизводит эффекты прибытия при телепортации.
     * Включает красные редстоун-частицы, звук и эффект тошноты.
     *
     * @param player Игрок, который прибыл в пункт назначения
     */
    public static void playTeleportArrivalEffects(class_3222 player) {
        ModConfig config = ModConfig.get();
        class_3218 world = EntityCompat.getServerWorld(player);
        class_243 pos = EntityCompat.getPos(player);

        // Красные редстоун-частицы для эффекта "магического тумана"
        if (config.enableTeleportParticles) {
            spawnRedstoneParticleFog(world, pos);
        }

        // Звук прибытия
        if (config.enableTeleportSounds) {
            world.method_8396(
                (class_1657) null,
                player.method_24515(),
                class_3417.field_14879,
                class_3419.field_15248,
                0.8F,
                1.2F
            );
        }
    }

    /**
     * Создает густой туман из красных редстоун-частиц вокруг игрока.
     * Используется для создания драматического "магического тумана" при телепортации.
     *
     * @param world Мир, в котором создаются частицы
     * @param pos Позиция, вокруг которой создаются частицы
     */
    public static void spawnRedstoneParticleFog(class_3218 world, class_243 pos) {
        // Создаем густой туман из красных редстоун-частиц
        // Используем field_23190 (REDSTONE) для красных частиц
        world.method_14199(
            class_2398.field_23190,
            pos.field_1352,
            pos.field_1351 + 1.0,
            pos.field_1350,
            REDSTONE_PARTICLE_COUNT,
            REDSTONE_SPREAD_X,
            REDSTONE_SPREAD_Y,
            REDSTONE_SPREAD_Z,
            REDSTONE_SPEED
        );

        // Дополнительный слой частиц для более густого эффекта
        world.method_14199(
            class_2398.field_23190,
            pos.field_1352,
            pos.field_1351 + 0.5,
            pos.field_1350,
            REDSTONE_PARTICLE_COUNT / 2,
            REDSTONE_SPREAD_X * 0.5,
            REDSTONE_SPREAD_Y * 0.5,
            REDSTONE_SPREAD_Z * 0.5,
            REDSTONE_SPEED * 0.5
        );
    }

    /**
     * Применяет эффект слепоты III уровня к игроку.
     * Используется для затемнения экрана при переходе между измерениями.
     *
     * @param player Игрок, которому применяется эффект
     */
    public static void applyBlindnessEffect(class_3222 player) {
        // StatusEffects.BLINDNESS = field_23102 (class_4969)
        // Длительность BLINDNESS_DURATION тиков, усиление BLINDNESS_AMPLIFIER (2 = III уровень)
        player.method_6092(
            new net.minecraft.class_1293(
                class_4969.field_23102, // BLINDNESS
                BLINDNESS_DURATION,
                BLINDNESS_AMPLIFIER,
                false, // Не является эффектом от маяка
                true,  // Показывать частицы
                true   // Показывать иконку
            )
        );
    }

    /**
     * Удаляет эффект слепоты у игрока.
     * Вызывается после завершения телепортации, чтобы игрок снова мог видеть.
     *
     * @param player Игрок, у которого удаляется эффект
     */
    public static void removeBlindnessEffect(class_3222 player) {
        if (player.method_6112(class_4969.field_23102)) {
            player.method_6016(class_4969.field_23102);
        }
    }

    /**
     * Применяет эффект тошноты к игроку на 10 секунд.
     * Используется как "налог" за телепортацию.
     *
     * @param player Игрок, которому применяется эффект
     */
    public static void applyNauseaEffect(class_3222 player) {
        // StatusEffects.NAUSEA (CONFUSION) = field_23106 (class_4969)
        player.method_6092(
            new net.minecraft.class_1293(
                class_4969.field_23106, // NAUSEA (CONFUSION)
                NAUSEA_DURATION,
                0,     // Усиление 0 = базовый уровень
                false, // Не является эффектом от маяка
                true,  // Показывать частицы
                true   // Показывать иконку
            )
        );
    }

    /**
     * Воспроизводит полную кинематографическую последовательность телепортации.
     * Включает:
     * 1. Красные редстоун-частицы в точке отправления
     * 2. Эффект Blindness III для затемнения экрана
     * 3. Звук телепортации
     *
     * @param player Игрок, который телепортируется
     */
    public static void playTeleportSequenceStart(class_3222 player) {
        ModConfig config = ModConfig.get();
        class_3218 world = EntityCompat.getServerWorld(player);
        class_243 pos = EntityCompat.getPos(player);

        // Красные редстоун-частицы для эффекта "магического тумана"
        if (config.enableTeleportParticles) {
            spawnRedstoneParticleFog(world, pos);
        }

        // Применяем эффект слепоты для затемнения экрана
        applyBlindnessEffect(player);

        // Звук телепортации
        if (config.enableTeleportSounds) {
            world.method_8396(
                (class_1657) null,
                player.method_24515(),
                class_3417.field_14879,
                class_3419.field_15248,
                1.0F,
                1.0F
            );
        }
    }

    /**
     * Воспроизводит завершение кинематографической последовательности телепортации.
     * Включает:
     * 1. Красные редстоун-частицы в точке прибытия
     * 2. Удаление эффекта Blindness
     * 3. Эффект Nausea на 10 секунд
     * 4. Звук прибытия
     *
     * @param player Игрок, который прибыл в пункт назначения
     */
    public static void playTeleportSequenceEnd(class_3222 player) {
        ModConfig config = ModConfig.get();
        class_3218 world = EntityCompat.getServerWorld(player);
        class_243 pos = EntityCompat.getPos(player);

        // Красные редстоун-частицы для эффекта "магического тумана"
        if (config.enableTeleportParticles) {
            spawnRedstoneParticleFog(world, pos);
        }

        // Удаляем эффект слепоты - игрок снова может видеть
        removeBlindnessEffect(player);

        // Применяем эффект тошноты на 10 секунд
        applyNauseaEffect(player);

        // Звук прибытия
        if (config.enableTeleportSounds) {
            world.method_8396(
                (class_1657) null,
                player.method_24515(),
                class_3417.field_14879,
                class_3419.field_15248,
                0.8F,
                1.2F
            );
        }
    }

    /**
     * Воспроизводит эффекты активации портала.
     * Используется при активации портала изумрудом.
     *
     * @param world Мир, в котором находится портал
     * @param center Центр портала
     */
    public static void playPortalActivationEffects(class_1937 world, class_2338 center) {
        if (ModConfig.get().enablePortalActivationEffects) {
            if (world instanceof class_3218) {
                class_3218 serverWorld = (class_3218) world;

                // Красные редстоун-частицы
                serverWorld.method_14199(
                    class_2398.field_23190,
                    (double) center.method_10263() + 0.5,
                    (double) center.method_10264() + 1.5,
                    (double) center.method_10260() + 0.5,
                    100,
                    1.0,
                    2.0,
                    1.0,
                    0.1
                );

                // Частицы портала
                serverWorld.method_14199(
                    class_2398.field_11215,
                    (double) center.method_10263() + 0.5,
                    (double) center.method_10264() + 2.0,
                    (double) center.method_10260() + 0.5,
                    50,
                    1.0,
                    0.5,
                    1.0,
                    0.5
                );
            }
        }
    }

    /**
     * Воспроизводит эффект получения приглашения.
     *
     * @param guest Игрок, получивший приглашение
     */
    public static void playInvitationReceivedEffect(class_3222 guest) {
        if (ModConfig.get().enableInvitationNotifications) {
            guest.method_17356(
                class_3417.field_14627,
                class_3419.field_15248,
                0.5F,
                1.2F
            );
        }
    }

    /**
     * Воспроизводит эффект отзыва приглашения.
     *
     * @param guest Игрок, у которого отозвали приглашение
     */
    public static void playInvitationRevokedEffect(class_3222 guest) {
        if (ModConfig.get().enableInvitationNotifications) {
            guest.method_17356(
                (class_3414) class_3417.field_14624.comp_349(),
                class_3419.field_15248,
                0.7F,
                0.5F
            );
        }
    }

    /**
     * Воспроизводит эффект отправки приглашения.
     *
     * @param owner Игрок, отправивший приглашение
     */
    public static void playInvitationSentEffect(class_3222 owner) {
        if (ModConfig.get().enableInvitationNotifications) {
            owner.method_17356(
                class_3417.field_14627,
                class_3419.field_15248,
                0.3F,
                1.5F
            );
        }
    }

    /**
     * Воспроизводит эффект входа в измерение.
     *
     * @param player Игрок, входящий в измерение
     */
    public static void playDimensionEntryEffect(class_3222 player) {
        if (ModConfig.get().enableTeleportSounds) {
            player.method_17356(
                class_3417.field_14703,
                class_3419.field_15256,
                0.5F,
                1.5F
            );
        }
    }

    /**
     * Воспроизводит эффект выхода из измерения.
     *
     * @param player Игрок, выходящий из измерения
     */
    public static void playDimensionExitEffect(class_3222 player) {
        if (ModConfig.get().enableTeleportSounds) {
            player.method_17356(
                class_3417.field_19344,
                class_3419.field_15256,
                0.3F,
                1.2F
            );
        }
    }

    /**
     * Воспроизводит эффект предупреждения для администратора.
     *
     * @param admin Администратор
     */
    public static void playAdminWarningEffect(class_3222 admin) {
        admin.method_17356(
            (class_3414) class_3417.field_14622.comp_349(),
            class_3419.field_15250,
            1.0F,
            0.5F
        );
    }

    /**
     * Воспроизводит эффект успешного действия администратора.
     *
     * @param admin Администратор
     */
    public static void playAdminSuccessEffect(class_3222 admin) {
        admin.method_17356(
            class_3417.field_14709,
            class_3419.field_15250,
            0.3F,
            2.0F
        );
    }
}
