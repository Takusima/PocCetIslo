package com.wickedsik.personalworlds.command.executor;

import com.wickedsik.personalworlds.command.CommandResult;
import com.wickedsik.personalworlds.command.service.PlayerLookupService;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.player.InvitationManager;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import com.wickedsik.personalworlds.portal.PortalColor;
import com.wickedsik.personalworlds.registry.ModBlocks;
import com.wickedsik.personalworlds.registry.ModItems;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;

public class PlayerCommandExecutor {
   private final PlayerLookupService playerLookup;

   public PlayerCommandExecutor(PlayerLookupService playerLookup) {
      this.playerLookup = playerLookup;
   }

   public CommandResult invite(class_3222 owner, class_3222 guest, boolean alwaysWelcome) {
      InvitationManager.invite(EntityCompat.getServer(owner), owner, guest, alwaysWelcome);
      return CommandResult.silent();
   }

   public CommandResult uninvite(class_3222 owner, String guestName) {
      MinecraftServer server = EntityCompat.getServer(owner);
      Optional<PlayerLookupService.PlayerReference> playerRef = this.playerLookup.findInInvitations(server, owner.method_5667(), guestName);
      if (playerRef.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.player_not_found", new Object[]{guestName}));
      } else {
         PlayerLookupService.PlayerReference ref = (PlayerLookupService.PlayerReference)playerRef.get();
         InvitationManager.uninvite(server, owner, ref.uuid(), ref.resolvedName());
         return CommandResult.silent();
      }
   }

   public CommandResult toggleWelcome(class_3222 owner, String guestName) {
      MinecraftServer server = EntityCompat.getServer(owner);
      Optional<PlayerLookupService.PlayerReference> playerRef = this.playerLookup.findInInvitations(server, owner.method_5667(), guestName);
      if (playerRef.isEmpty()) {
         return CommandResult.error(class_2561.method_43469("pocketislands.command.error.not_invited_by_you", new Object[]{guestName}));
      } else {
         PlayerLookupService.PlayerReference ref = (PlayerLookupService.PlayerReference)playerRef.get();
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         Optional<Boolean> newValue = dataManager.toggleAlwaysWelcome(owner.method_5667(), ref.uuid());
         if (newValue.isEmpty()) {
            return CommandResult.error(class_2561.method_43469("pocketislands.command.error.not_invited_by_you", new Object[]{ref.resolvedName()}));
         } else {
            String messageKey = (Boolean)newValue.get() ? "pocketislands.command.toggle_welcome_on" : "pocketislands.command.toggle_welcome_off";
            return CommandResult.success(class_2561.method_43469(messageKey, new Object[]{ref.resolvedName()}));
         }
      }
   }

   public CommandResult showInvitations(class_3222 player) {
      InvitationManager.showInvitations(player);
      return CommandResult.silent();
   }

   public void showPortals(class_3222 player, class_2168 source) {
      List<ModConfig.PortalConfig> portalTypes = ModConfig.get().portalTypes;
      source.method_9226(() -> class_2561.method_43471("pocketislands.command.portals.header").method_27692(class_124.field_1065), false);
      if (portalTypes.isEmpty()) {
         source.method_9226(() -> class_2561.method_43471("pocketislands.command.portals.no_portals").method_27692(class_124.field_1080), false);
      } else {
         for(int i = 0; i < portalTypes.size(); ++i) {
            this.sendPortalTypeInfo(source, i, (ModConfig.PortalConfig)portalTypes.get(i));
         }
      }

      source.method_9226(() -> class_2561.method_43471("pocketislands.command.portals.your_island_header").method_27692(class_124.field_1065), false);
      DimensionRegistry registry = DimensionRegistry.get(source.method_9211());
      Optional<PlayerDimensionData> islandData = registry.getDimensionData(player.method_5667());
      if (islandData.isEmpty()) {
         source.method_9226(() -> class_2561.method_43471("pocketislands.command.portals.no_island").method_27692(class_124.field_1080), false);
      } else {
         PlayerDimensionData data = (PlayerDimensionData)islandData.get();
         int typeIndex = data.portalTypeIndex();
         List<ModConfig.PortalConfig> currentTypes = ModConfig.get().portalTypes;
         if (typeIndex >= 0 && typeIndex < currentTypes.size()) {
            class_2248 frameBlock = ModBlocks.getFrameBlock(typeIndex);
            class_2561 frameName = class_2561.method_43471(frameBlock.method_9539());
            PortalColor color = ModBlocks.getPortalColor(typeIndex);
            String colorName = formatColorName(color);
            source.method_9226(() -> class_2561.method_43469("pocketislands.command.portals.your_type", new Object[]{frameName, colorName}).method_27692(class_124.field_1060), false);
         } else {
            source.method_9226(() -> class_2561.method_43471("pocketislands.command.portals.your_type_unknown").method_27692(class_124.field_1061), false);
         }
      }

   }

   private void sendPortalTypeInfo(class_2168 source, int index, ModConfig.PortalConfig config) {
      class_2248 frameBlock = ModBlocks.getFrameBlock(index);
      class_2561 frameName = class_2561.method_43471(frameBlock.method_9539());
      PortalColor color = ModBlocks.getPortalColor(index);
      String colorName = formatColorName(color);
      source.method_9226(() -> class_2561.method_43469("pocketislands.command.portals.type_header", new Object[]{index + 1, frameName, colorName}).method_27692(class_124.field_1054), false);
      class_1792 activationItem = ModItems.getActivationItem(index);
      class_2561 itemName = class_2561.method_43471(activationItem.method_7876());
      source.method_9226(() -> class_2561.method_43469("pocketislands.command.portals.activate", new Object[]{itemName}).method_27692(class_124.field_1080), false);
      class_2561 layersText = buildLayersText(config.islandLayers);
      source.method_9226(() -> class_2561.method_43469("pocketislands.command.portals.layers", new Object[]{layersText}).method_27692(class_124.field_1080), false);
   }

   private static class_2561 buildLayersText(String[] layers) {
      if (layers != null && layers.length != 0) {
         class_5250 result = class_2561.method_43473();

         for(int i = 0; i < layers.length; ++i) {
            if (i > 0) {
               result.method_27693(", ");
            }

            class_2960 id = IdentifierCompat.tryParse(layers[i]);
            if (id != null) {
               class_2248 block = (class_2248)class_7923.field_41175.method_10223(id);
               if (block == class_2246.field_10124 && !"minecraft:air".equals(layers[i])) {
                  result.method_10852(class_2561.method_43470(layers[i]));
               } else {
                  result.method_10852(class_2561.method_43471(block.method_9539()));
               }
            } else {
               result.method_10852(class_2561.method_43470(layers[i]));
            }
         }

         return result;
      } else {
         return class_2561.method_43470("None");
      }
   }

   private static String formatColorName(PortalColor color) {
      return color.getDisplayName();
   }
}
