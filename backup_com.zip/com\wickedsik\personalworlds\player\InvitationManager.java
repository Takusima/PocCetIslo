package com.wickedsik.personalworlds.player;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.CommandCompat;
import com.wickedsik.personalworlds.compat.EntityCompat;
import com.wickedsik.personalworlds.compat.TeleportCompat;
import com.wickedsik.personalworlds.compat.TextCompat;
import com.wickedsik.personalworlds.compat.WorldCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.portal.PortalHelper;
import com.wickedsik.personalworlds.util.VisualEffects;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

public class InvitationManager {
   public static boolean canVisit(MinecraftServer server, UUID visitorUuid, UUID ownerUuid) {
      if (visitorUuid.equals(ownerUuid)) {
         return true;
      } else {
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         return dataManager.hasInvitationFrom(visitorUuid, ownerUuid);
      }
   }

   public static VisitDenialReason checkVisitAccess(MinecraftServer server, class_3222 visitor, UUID ownerUuid) {
      UUID visitorUuid = visitor.method_5667();
      if (CommandCompat.hasPermissionLevel((class_3222)visitor, 2)) {
         return VisitDenialReason.ALLOWED;
      } else if (visitorUuid.equals(ownerUuid)) {
         return VisitDenialReason.ALLOWED;
      } else {
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         if (!dataManager.hasInvitationFrom(visitorUuid, ownerUuid)) {
            return VisitDenialReason.NOT_INVITED;
         } else if (ModConfig.get().enableAlwaysWelcome && dataManager.isAlwaysWelcome(ownerUuid, visitorUuid)) {
            return VisitDenialReason.ALLOWED;
         } else {
            class_3222 host = server.method_3760().method_14602(ownerUuid);
            if (host == null) {
               return VisitDenialReason.HOST_OFFLINE;
            } else {
               return !ModConfig.get().allowVisitWhenHostNotHome && !isPlayerHome(host, ownerUuid) ? VisitDenialReason.HOST_NOT_HOME : VisitDenialReason.ALLOWED;
            }
         }
      }
   }

   private static boolean isPlayerHome(class_3222 player, UUID playerUuid) {
      class_3218 world = EntityCompat.getServerWorld(player);
      if (!PortalHelper.isInPersonalDimension(world)) {
         return false;
      } else {
         Optional<UUID> dimensionOwner = PortalHelper.getDimensionOwner(world);
         return dimensionOwner.isPresent() && ((UUID)dimensionOwner.get()).equals(playerUuid);
      }
   }

   public static void notifyHostOfVisitAttempt(MinecraftServer server, UUID ownerUuid, String visitorName, VisitDenialReason reason) {
      if (reason == VisitDenialReason.HOST_NOT_HOME) {
         class_3222 host = server.method_3760().method_14602(ownerUuid);
         if (host != null) {
            host.method_7353(class_2561.method_43469("pocketislands.visit.attempted.not_home", new Object[]{visitorName}).method_27692(class_124.field_1080), false);
         }

      }
   }

   public static boolean invite(MinecraftServer server, class_3222 owner, class_3222 guest) {
      return invite(server, owner, guest, false);
   }

   public static boolean invite(MinecraftServer server, class_3222 owner, class_3222 guest, boolean alwaysWelcome) {
      UUID ownerUuid = owner.method_5667();
      UUID guestUuid = guest.method_5667();
      if (ownerUuid.equals(guestUuid)) {
         owner.method_7353(class_2561.method_43471("pocketislands.message.cannot_invite_self").method_27692(class_124.field_1061), false);
         return false;
      } else {
         String ownerName = owner.method_5477().getString();
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         boolean added = dataManager.addInvitation(ownerUuid, ownerName, guestUuid, alwaysWelcome);
         if (added) {
            String messageKey = alwaysWelcome ? "pocketislands.command.invited_always_welcome" : "pocketislands.message.invite_sent";
            owner.method_7353(class_2561.method_43469(messageKey, new Object[]{guest.method_5477().getString()}), false);
            guest.method_7353(class_2561.method_43469("pocketislands.message.invite_received", new Object[]{ownerName}), false);
            VisualEffects.playInvitationSentEffect(owner);
            VisualEffects.playInvitationReceivedEffect(guest);
            PersonalWorldsMod.LOGGER.info("{} invited {} to their dimension (alwaysWelcome={})", new Object[]{ownerName, guest.method_5477().getString(), alwaysWelcome});
         } else {
            owner.method_7353(class_2561.method_43469("pocketislands.message.already_invited", new Object[]{guest.method_5477().getString()}), false);
         }

         return added;
      }
   }

   public static boolean uninvite(MinecraftServer server, class_3222 owner, UUID guestUuid, String guestName) {
      UUID ownerUuid = owner.method_5667();
      PlayerDataManager dataManager = PlayerDataManager.get(server);
      boolean removed = dataManager.removeInvitation(ownerUuid, guestUuid);
      if (removed) {
         owner.method_7353(class_2561.method_43469("pocketislands.message.invite_revoked", new Object[]{guestName}), false);
         class_3222 guest = server.method_3760().method_14602(guestUuid);
         if (guest != null) {
            handleRevocationWhileVisiting(server, owner, guest);
         }

         PersonalWorldsMod.LOGGER.info("{} revoked {}'s invitation", owner.method_5477().getString(), guestName);
      } else {
         owner.method_7353(class_2561.method_43469("pocketislands.message.not_invited", new Object[]{guestName}), false);
      }

      return removed;
   }

   private static void handleRevocationWhileVisiting(MinecraftServer server, class_3222 owner, class_3222 guest) {
      class_3218 guestWorld = EntityCompat.getServerWorld(guest);
      if (PortalHelper.isInPersonalDimension(guestWorld)) {
         String dimPath = guestWorld.method_27983().method_29177().method_12832();
         String ownerDimPath = "pw_" + owner.method_5667().toString();
         if (dimPath.equals(ownerDimPath)) {
            VisualEffects.playInvitationRevokedEffect(guest);
            guest.method_7353(class_2561.method_43471("pocketislands.message.ejected").method_27692(class_124.field_1065), false);
            PlayerDataManager dataManager = PlayerDataManager.get(server);
            Optional<ReturnData> returnDataOpt = dataManager.getReturnData(guest.method_5667());
            class_3218 targetWorld;
            class_243 targetPos;
            float yaw;
            float pitch;
            if (returnDataOpt.isPresent()) {
               ReturnData returnData = (ReturnData)returnDataOpt.get();
               targetWorld = server.method_3847(returnData.dimension());
               if (targetWorld == null) {
                  targetWorld = server.method_30002();
                  targetPos = class_243.method_24953(WorldCompat.getSpawnPos(targetWorld));
                  yaw = guest.method_36454();
                  pitch = guest.method_36455();
               } else {
                  targetPos = class_243.method_24953(returnData.position());
                  yaw = returnData.yaw();
                  pitch = returnData.pitch();
               }

               dataManager.clearReturnData(guest.method_5667());
            } else {
               targetWorld = server.method_30002();
               targetPos = class_243.method_24953(WorldCompat.getSpawnPos(targetWorld));
               yaw = guest.method_36454();
               pitch = guest.method_36455();
            }

            TeleportCompat.teleport(guest, targetWorld, targetPos, yaw, pitch);
            PersonalWorldsMod.LOGGER.info("Ejected {} from {}'s dimension due to revoked invitation", guest.method_5477().getString(), owner.method_5477().getString());
         }
      }
   }

   public static void showInvitations(class_3222 player) {
      MinecraftServer server = EntityCompat.getServer(player);
      if (server != null) {
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         UUID playerUuid = player.method_5667();
         player.method_7353(class_2561.method_43471("pocketislands.invitations.header").method_27692(class_124.field_1065), false);
         Set<UUID> sent = dataManager.getSentInvitations(playerUuid);
         player.method_7353(class_2561.method_43470(""), false);
         player.method_7353(class_2561.method_43471("pocketislands.invitations.sent.header").method_27692(class_124.field_1060), false);
         if (sent.isEmpty()) {
            player.method_7353(class_2561.method_43471("pocketislands.invitations.sent.none").method_27692(class_124.field_1080), false);
         } else {
            boolean alwaysWelcomeEnabled = ModConfig.get().enableAlwaysWelcome;

            for(UUID guestUuid : sent) {
               String guestName = getPlayerName(server, guestUuid);
               class_5250 entryText = class_2561.method_43470(guestName).method_27692(class_124.field_1054);
               if (alwaysWelcomeEnabled) {
                  boolean isAlwaysWelcome = dataManager.isAlwaysWelcome(playerUuid, guestUuid);
                  String toggleIcon = isAlwaysWelcome ? "★" : "☆";
                  class_124 toggleColor = isAlwaysWelcome ? class_124.field_1060 : class_124.field_1080;
                  String toggleTooltipKey = isAlwaysWelcome ? "pocketislands.invitations.sent.toggle_off_tooltip" : "pocketislands.invitations.sent.toggle_on_tooltip";
                  class_5250 toggleButton = class_2561.method_43470("[" + toggleIcon + "]").method_27692(toggleColor).method_27694((style) -> style.method_10958(TextCompat.runCommand("/pi togglewelcome " + guestName)).method_10949(TextCompat.showText(class_2561.method_43471(toggleTooltipKey))));
                  entryText = entryText.method_27693(" ").method_10852(toggleButton);
               }

               class_5250 revokeButton = class_2561.method_43471("pocketislands.invitations.sent.revoke_button").method_27692(class_124.field_1061).method_27694((style) -> style.method_10958(TextCompat.runCommand("/pw uninvite " + guestName)).method_10949(TextCompat.showText(class_2561.method_43471("pocketislands.invitations.sent.revoke_tooltip"))));
               entryText = entryText.method_27693(" ").method_10852(revokeButton);
               player.method_7353(class_2561.method_43469("pocketislands.invitations.sent.entry", new Object[]{entryText}), false);
            }
         }

         List<InvitationData> received = dataManager.getReceivedInvitations(playerUuid);
         player.method_7353(class_2561.method_43470(""), false);
         player.method_7353(class_2561.method_43471("pocketislands.invitations.received.header").method_27692(class_124.field_1075), false);
         if (received.isEmpty()) {
            player.method_7353(class_2561.method_43471("pocketislands.invitations.received.none").method_27692(class_124.field_1080), false);
         } else {
            for(InvitationData inv : received) {
               class_5250 worldLink = class_2561.method_43469("pocketislands.invitations.received.world_name", new Object[]{inv.ownerName()}).method_27692(class_124.field_1054).method_27694((style) -> style.method_10958(TextCompat.runCommand("/pw go " + inv.ownerName())).method_10949(TextCompat.showText(class_2561.method_43469("pocketislands.invitations.received.visit_tooltip", new Object[]{inv.ownerName()}))));
               player.method_7353(class_2561.method_43469("pocketislands.invitations.received.entry", new Object[]{worldLink}), false);
            }
         }

      }
   }

   private static String getPlayerName(MinecraftServer server, UUID playerUuid) {
      class_3222 player = server.method_3760().method_14602(playerUuid);
      if (player != null) {
         return player.method_5477().getString();
      } else {
         DimensionRegistry registry = DimensionRegistry.get(server);
         Optional<PlayerDimensionData> data = registry.getDimensionData(playerUuid);
         return data.isPresent() ? ((PlayerDimensionData)data.get()).ownerName() : playerUuid.toString().substring(0, 8);
      }
   }
}
