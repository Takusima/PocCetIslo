package com.wickedsik.personalworlds.network;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.client.screen.PocketDimensionScreen;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

import java.util.List;

/**
 * Обработчик клиентских сетевых пакетов.
 * Обрабатывает пакеты, полученные от сервера, и обновляет GUI.
 */
public final class NetworkHandlerClient {

    // Список онлайн игроков (синхронизируется с сервера)
    private static List<String> onlinePlayers = new java.util.ArrayList<>();

    // Текущий запрос на посещение
    private static String currentVisitRequest = null;

    private NetworkHandlerClient() {
        // Utility class
    }

    // ============================================================
    //  Обработка входящих пакетов
    // ============================================================

    /**
     * Обработка входящего запроса на посещение.
     * Показывает диалоговое окно с кнопками "Принять" и "Отказ".
     */
    public static void handleVisitRequest(String requesterName) {
        PersonalWorldsMod.LOGGER.info("Received visit request from: {}", requesterName);
        currentVisitRequest = requesterName;

        class_310 client = class_310.method_1551();
        if (client.field_9614 != null) { // player != null
            // Показываем диалог на клиенте
            client.method_1507(new VisitRequestScreen(requesterName));
        }
    }

    /**
     * Обработка уведомления об отказе.
     */
    public static void handleVisitDenied(String ownerName, String reasonKey) {
        PersonalWorldsMod.LOGGER.info("Visit denied by {}: {}", ownerName, reasonKey);

        class_310 client = class_310.method_1551();
        if (client.field_9614 != null) { // player != null
            class_2561 message = class_2561.method_43469("pocketislands.gui.visit_denied", new Object[]{ownerName})
                .method_27692(class_124.field_1061);
            client.field_9614.method_7353(message, false);
        }
    }

    /**
     * Обработка подтверждения телепортации.
     */
    public static void handleTeleportConfirm() {
        PersonalWorldsMod.LOGGER.info("Teleport confirmed by server");

        class_310 client = class_310.method_1551();
        if (client.field_9614 != null) { // player != null
            class_2561 message = class_2561.method_43471("pocketislands.gui.teleport_confirm")
                .method_27692(class_124.field_1060);
            client.field_9614.method_7353(message, false);
        }
    }

    /**
     * Обработка синхронизации списка игроков.
     */
    public static void handlePlayerListSync(List<String> playerNames) {
        PersonalWorldsMod.LOGGER.info("Received player list sync: {} players", playerNames.size());
        onlinePlayers = new java.util.ArrayList<>(playerNames);

        // Обновляем GUI, если оно открыто
        class_310 client = class_310.method_1551();
        if (client.field_9587 instanceof PocketDimensionScreen) { // currentScreen
            ((PocketDimensionScreen) client.field_9587).updatePlayerList(onlinePlayers);
        }
    }

    /**
     * Обработка уведомления о смене цвета портала.
     */
    public static void handlePortalColorChanged(String colorName, String playerName) {
        PersonalWorldsMod.LOGGER.info("Portal color changed to {} by {}", colorName, playerName);

        class_310 client = class_310.method_1551();
        if (client.field_9614 != null) { // player != null
            class_2561 message = class_2561.method_43469("pocketislands.gui.color_changed_broadcast", new Object[]{
                playerName,
                class_2561.method_43471("pocketislands.portal.color." + colorName)
            }).method_27692(class_124.field_1075);
            client.field_9614.method_7353(message, false);
        }
    }

    /**
     * Обработка результата выполнения команды.
     */
    public static void handleCommandResult(boolean success, String messageKey) {
        PersonalWorldsMod.LOGGER.info("Command result: {} - {}", success, messageKey);

        class_310 client = class_310.method_1551();
        if (client.field_9614 != null) { // player != null
            class_124 color = success ? class_124.field_1060 : class_124.field_1061;
            class_2561 message = class_2561.method_43471(messageKey).method_27692(color);
            client.field_9614.method_7353(message, false);
        }
    }

    // ============================================================
    //  Геттеры
    // ============================================================

    public static List<String> getOnlinePlayers() {
        return onlinePlayers;
    }

    public static String getCurrentVisitRequest() {
        return currentVisitRequest;
    }

    public static void clearCurrentVisitRequest() {
        currentVisitRequest = null;
    }
}
