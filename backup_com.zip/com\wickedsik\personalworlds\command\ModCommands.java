package com.wickedsik.personalworlds.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.wickedsik.personalworlds.command.executor.AdminCommandExecutor;
import com.wickedsik.personalworlds.command.executor.DebugCommandExecutor;
import com.wickedsik.personalworlds.command.executor.DevCommandExecutor;
import com.wickedsik.personalworlds.command.executor.PlayerCommandExecutor;
import com.wickedsik.personalworlds.command.service.PlayerLookupService;
import com.wickedsik.personalworlds.compat.CommandCompat;
import com.wickedsik.personalworlds.config.ModConfig;
import com.wickedsik.personalworlds.util.PermissionHelper;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2300;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ModCommands {
   private static DevCommandExecutor devExecutor;
   private static PlayerCommandExecutor playerExecutor;
   private static AdminCommandExecutor adminExecutor;
   private static DebugCommandExecutor debugExecutor;

   public static void register() {
      CommandRegistrationCallback.EVENT.register((CommandRegistrationCallback)(dispatcher, registryAccess, environment) -> {
         initializeExecutors();
         registerCommands(dispatcher);
      });
   }

   private static void initializeExecutors() {
      PlayerLookupService playerLookup = new PlayerLookupService();
      devExecutor = new DevCommandExecutor();
      playerExecutor = new PlayerCommandExecutor(playerLookup);
      adminExecutor = new AdminCommandExecutor(playerLookup);
      debugExecutor = new DebugCommandExecutor();
   }

   private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
      dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)class_2170.method_9247("pi").then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)class_2170.method_9247("create").requires(PermissionHelper.require("pocketislands.player.create", 2))).executes((ctx) -> handleCreate((class_2168)ctx.getSource(), "OVERWORLD"))).then(class_2170.method_9244("type", StringArgumentType.word()).executes((ctx) -> handleCreate((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "type")))))).then(((LiteralArgumentBuilder)class_2170.method_9247("enter").requires(PermissionHelper.require("pocketislands.player.create", 2))).executes((ctx) -> handleEnter((class_2168)ctx.getSource())))).then(((LiteralArgumentBuilder)class_2170.method_9247("leave").requires(PermissionHelper.require("pocketislands.player.create", 2))).executes((ctx) -> handleLeave((class_2168)ctx.getSource())))).then(buildInviteCommand())).then(class_2170.method_9247("uninvite").then(class_2170.method_9244("player", StringArgumentType.word()).executes((ctx) -> handleUninvite((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player")))))).then(buildToggleWelcomeCommand())).then(class_2170.method_9247("invites").executes((ctx) -> handleInvites((class_2168)ctx.getSource())))).then(class_2170.method_9247("portals").executes((ctx) -> handlePortals((class_2168)ctx.getSource())))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)class_2170.method_9247("admin").then(((LiteralArgumentBuilder)class_2170.method_9247("list").requires(PermissionHelper.require("pocketislands.admin.list", 2))).executes((ctx) -> handleAdminList((class_2168)ctx.getSource())))).then(((LiteralArgumentBuilder)class_2170.method_9247("info").requires(PermissionHelper.require("pocketislands.admin.info", 2))).then(class_2170.method_9244("player", StringArgumentType.word()).executes((ctx) -> handleAdminInfo((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player")))))).then(((LiteralArgumentBuilder)class_2170.method_9247("delete").requires(PermissionHelper.require("pocketislands.admin.delete", 4))).then(((RequiredArgumentBuilder)class_2170.method_9244("player", StringArgumentType.word()).executes((ctx) -> handleAdminDeletePrompt((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player")))).then(class_2170.method_9247("confirm").executes((ctx) -> handleAdminDeleteConfirm((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player"))))))).then(((LiteralArgumentBuilder)class_2170.method_9247("tp").requires(PermissionHelper.require("pocketislands.admin.teleport", 2))).then(class_2170.method_9244("player", StringArgumentType.word()).executes((ctx) -> handleAdminTeleport((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player")))))).then(((LiteralArgumentBuilder)class_2170.method_9247("reload").requires(PermissionHelper.require("pocketislands.admin.reload", 3))).executes((ctx) -> handleAdminReload((class_2168)ctx.getSource()))))).then(((LiteralArgumentBuilder)class_2170.method_9247("debug").requires(CommandCompat.requiresLevel(4))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)class_2170.method_9247("perf").then(class_2170.method_9247("enable").executes((ctx) -> debugExecutor.enablePerf().applyTo((class_2168)ctx.getSource())))).then(class_2170.method_9247("disable").executes((ctx) -> debugExecutor.disablePerf().applyTo((class_2168)ctx.getSource())))).then(class_2170.method_9247("status").executes((ctx) -> {
         debugExecutor.showStatus((class_2168)ctx.getSource(), ((class_2168)ctx.getSource()).method_9211());
         return 1;
      }))).then(class_2170.method_9247("reset").executes((ctx) -> debugExecutor.resetCounters().applyTo((class_2168)ctx.getSource()))))));
   }

   private static LiteralArgumentBuilder<class_2168> buildInviteCommand() {
      RequiredArgumentBuilder<class_2168, class_2300> playerArg = (RequiredArgumentBuilder)class_2170.method_9244("player", class_2186.method_9305()).executes((ctx) -> handleInvite((class_2168)ctx.getSource(), class_2186.method_9315(ctx, "player"), false));
      if (ModConfig.get().enableAlwaysWelcome) {
         playerArg = (RequiredArgumentBuilder)playerArg.then(class_2170.method_9247("always").executes((ctx) -> handleInvite((class_2168)ctx.getSource(), class_2186.method_9315(ctx, "player"), true)));
      }

      return (LiteralArgumentBuilder)class_2170.method_9247("invite").then(playerArg);
   }

   private static LiteralArgumentBuilder<class_2168> buildToggleWelcomeCommand() {
      return !ModConfig.get().enableAlwaysWelcome ? (LiteralArgumentBuilder)class_2170.method_9247("togglewelcome").requires((source) -> false) : (LiteralArgumentBuilder)class_2170.method_9247("togglewelcome").then(class_2170.method_9244("player", StringArgumentType.word()).executes((ctx) -> handleToggleWelcome((class_2168)ctx.getSource(), StringArgumentType.getString(ctx, "player"))));
   }

   private static int handleCreate(class_2168 source, String typeStr) {
      class_1297 var3 = source.method_9228();
      if (var3 instanceof class_3222 player) {
         return devExecutor.createDimension(player, typeStr).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleEnter(class_2168 source) {
      class_1297 var2 = source.method_9228();
      if (var2 instanceof class_3222 player) {
         return devExecutor.enterDimension(player).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleLeave(class_2168 source) {
      class_1297 var2 = source.method_9228();
      if (var2 instanceof class_3222 player) {
         return devExecutor.leaveDimension(player).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleInvite(class_2168 source, class_3222 guest, boolean alwaysWelcome) {
      class_1297 var4 = source.method_9228();
      if (var4 instanceof class_3222 owner) {
         return playerExecutor.invite(owner, guest, alwaysWelcome).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleToggleWelcome(class_2168 source, String guestName) {
      class_1297 var3 = source.method_9228();
      if (var3 instanceof class_3222 owner) {
         return playerExecutor.toggleWelcome(owner, guestName).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleUninvite(class_2168 source, String guestName) {
      class_1297 var3 = source.method_9228();
      if (var3 instanceof class_3222 owner) {
         return playerExecutor.uninvite(owner, guestName).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleInvites(class_2168 source) {
      class_1297 var2 = source.method_9228();
      if (var2 instanceof class_3222 player) {
         return playerExecutor.showInvitations(player).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handlePortals(class_2168 source) {
      class_1297 var2 = source.method_9228();
      if (var2 instanceof class_3222 player) {
         playerExecutor.showPortals(player, source);
         return 1;
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleAdminList(class_2168 source) {
      adminExecutor.list(source);
      return 1;
   }

   private static int handleAdminInfo(class_2168 source, String playerName) {
      return adminExecutor.info(source, playerName).applyTo(source);
   }

   private static int handleAdminDeletePrompt(class_2168 source, String playerName) {
      return adminExecutor.deletePrompt(source, playerName).applyTo(source);
   }

   private static int handleAdminDeleteConfirm(class_2168 source, String playerName) {
      return adminExecutor.deleteConfirm(source, playerName).applyTo(source);
   }

   private static int handleAdminTeleport(class_2168 source, String playerName) {
      class_1297 var3 = source.method_9228();
      if (var3 instanceof class_3222 admin) {
         return adminExecutor.teleport(admin, playerName).applyTo(source);
      } else {
         source.method_9213(class_2561.method_43471("pocketislands.command.error.must_be_player"));
         return 0;
      }
   }

   private static int handleAdminReload(class_2168 source) {
      return adminExecutor.reload(source).applyTo(source);
   }
}
