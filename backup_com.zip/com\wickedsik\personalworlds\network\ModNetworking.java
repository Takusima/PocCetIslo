package com.wickedsik.personalworlds.network;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;

/**
 * Центральный класс для регистрации и обработки сетевых пакетов.
 */
public final class ModNetworking {

    public static final class_2960 CHANGE_PORTAL_COLOR = new class_2960(PersonalWorldsMod.MOD_ID, "change_portal_color");
    public static final class_2960 SEND_INVITATION_REQUEST = new class_2960(PersonalWorldsMod.MOD_ID, "send_invitation_request");
    public static final class_2960 INVITATION_RESPONSE = new class_2960(PersonalWorldsMod.MOD_ID, "invitation_response");
    public static final class_2960 VISIT_REQUEST = new class_2960(PersonalWorldsMod.MOD_ID, "visit_request");
    public static final class_2960 VISIT_DENIED = new class_2960(PersonalWorldsMod.MOD_ID, "visit_denied");
    public static final class_2960 TELEPORT_CONFIRM = new class_2960(PersonalWorldsMod.MOD_ID, "teleport_confirm");
    public static final class_2960 OPEN_GUI = new class_2960(PersonalWorldsMod.MOD_ID, "open_gui");
    public static final class_2960 SYNC_PLAYER_LIST = new class_2960(PersonalWorldsMod.MOD_ID, "sync_player_list");
    public static final class_2960 PORTAL_COLOR_CHANGED = new class_2960(PersonalWorldsMod.MOD_ID, "portal_color_changed");
    public static final class_2960 COMMAND_PRUNUS = new class_2960(PersonalWorldsMod.MOD_ID, "command_prunus");
    public static final class_2960 COMMAND_MALUS = new class_2960(PersonalWorldsMod.MOD_ID, "command_malus");
    public static final class_2960 COMMAND_RESULT = new class_2960(PersonalWorldsMod.MOD_ID, "command_result");

    private ModNetworking() {}

    public static void registerServerReceivers() {
        PersonalWorldsMod.LOGGER.info("Registering server network receivers...");

        ServerPlayNetworking.registerGlobalReceiver(CHANGE_PORTAL_COLOR, (server, player, handler, buf, responseSender) -> {
            String colorName = buf.method_10810();
            server.execute(() -> NetworkHandler.handleChangePortalColor(player, colorName));
        });

        ServerPlayNetworking.registerGlobalReceiver(SEND_INVITATION_REQUEST, (server, player, handler, buf, responseSender) -> {
            String targetName = buf.method_10810();
            server.execute(() -> NetworkHandler.handleInvitationRequest(player, targetName));
        });

        ServerPlayNetworking.registerGlobalReceiver(INVITATION_RESPONSE, (server, player, handler, buf, responseSender) -> {
            String senderName = buf.method_10810();
            boolean accepted = buf.method_10795();
            server.execute(() -> NetworkHandler.handleInvitationResponse(player, senderName, accepted));
        });

        ServerPlayNetworking.registerGlobalReceiver(OPEN_GUI, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> NetworkHandler.handleOpenGui(player));
        });

        ServerPlayNetworking.registerGlobalReceiver(COMMAND_PRUNUS, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> NetworkHandler.handlePrunusCommand(player));
        });

        ServerPlayNetworking.registerGlobalReceiver(COMMAND_MALUS, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> NetworkHandler.handleMalusCommand(player));
        });

        PersonalWorldsMod.LOGGER.info("Server network receivers registered successfully");
    }

    public static void registerClientReceivers() {
        PersonalWorldsMod.LOGGER.info("Registering client network receivers...");

        ClientPlayNetworking.registerGlobalReceiver(VISIT_REQUEST, (client, handler, buf, responseSender) -> {
            String requesterName = buf.method_10810();
            client.execute(() -> NetworkHandlerClient.handleVisitRequest(requesterName));
        });

        ClientPlayNetworking.registerGlobalReceiver(VISIT_DENIED, (client, handler, buf, responseSender) -> {
            String ownerName = buf.method_10810();
            String reason = buf.method_10810();
            client.execute(() -> NetworkHandlerClient.handleVisitDenied(ownerName, reason));
        });

        ClientPlayNetworking.registerGlobalReceiver(TELEPORT_CONFIRM, (client, handler, buf, responseSender) -> {
            client.execute(() -> NetworkHandlerClient.handleTeleportConfirm());
        });

        ClientPlayNetworking.registerGlobalReceiver(SYNC_PLAYER_LIST, (client, handler, buf, responseSender) -> {
            int count = buf.method_10815();
            java.util.List<String> playerNames = new java.util.ArrayList<>();
            for (int i = 0; i < count; i++) {
                playerNames.add(buf.method_10810());
            }
            client.execute(() -> NetworkHandlerClient.handlePlayerListSync(playerNames));
        });

        ClientPlayNetworking.registerGlobalReceiver(PORTAL_COLOR_CHANGED, (client, handler, buf, responseSender) -> {
            String colorName = buf.method_10810();
            String playerName = buf.method_10810();
            client.execute(() -> NetworkHandlerClient.handlePortalColorChanged(colorName, playerName));
        });

        ClientPlayNetworking.registerGlobalReceiver(COMMAND_RESULT, (client, handler, buf, responseSender) -> {
            boolean success = buf.method_10795();
            String message = buf.method_10810();
            client.execute(() -> NetworkHandlerClient.handleCommandResult(success, message));
        });

        PersonalWorldsMod.LOGGER.info("Client network receivers registered successfully");
    }

    public static void sendToServer(class_2960 channel, net.fabricmc.fabric.api.networking.v1.PacketByteBuf buf) {
        ClientPlayNetworking.send(channel, buf);
    }

    public static net.fabricmc.fabric.api.networking.v1.PacketByteBuf createBuf() {
        return PacketByteBufs.create();
    }
}
