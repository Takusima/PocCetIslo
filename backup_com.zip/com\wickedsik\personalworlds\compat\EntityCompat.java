package com.wickedsik.personalworlds.compat;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public final class EntityCompat {
   private EntityCompat() {
   }

   public static MinecraftServer getServer(class_3222 player) {
      return player.method_5682();
   }

   public static class_3218 getServerWorld(class_3222 player) {
      return player.method_51469();
   }

   public static class_243 getPos(class_3222 player) {
      return player.method_19538();
   }

   public static @Nullable class_2338 getSpawnPointPosition(class_3222 player) {
      return player.method_26280();
   }

   public static @Nullable class_5321<class_1937> getSpawnPointDimension(class_3222 player) {
      return player.method_26281();
   }
}
