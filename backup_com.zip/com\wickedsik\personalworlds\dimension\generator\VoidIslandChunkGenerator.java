package com.wickedsik.personalworlds.dimension.generator;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_1966;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5539;
import net.minecraft.class_6748;
import net.minecraft.class_7138;

public class VoidIslandChunkGenerator extends class_2794 {
   public static final Codec<VoidIslandChunkGenerator> CODEC = RecordCodecBuilder.create((instance) -> instance.group(class_1966.field_24713.fieldOf("biome_source").forGetter(class_2794::method_12098), class_2680.field_24734.listOf().xmap((list) -> (class_2680[])list.toArray(new class_2680[0]), Arrays::asList).fieldOf("island_layers").forGetter((generator) -> generator.islandLayers)).apply(instance, VoidIslandChunkGenerator::new));
   private static final int ISLAND_MIN_CHUNK = -4;
   private static final int ISLAND_MAX_CHUNK = 3;
   private static final int ISLAND_Y = 64;
   private final class_2680[] islandLayers;

   public VoidIslandChunkGenerator(class_1966 biomeSource, class_2680[] islandLayers) {
      super(biomeSource);
      this.islandLayers = islandLayers;
   }

   protected Codec<? extends class_2794> method_28506() {
      return CODEC;
   }

   public CompletableFuture<class_2791> method_12088(Executor executor, class_6748 blender, class_7138 noiseConfig, class_5138 structureAccessor, class_2791 chunk) {
      int chunkX = chunk.method_12004().field_9181;
      int chunkZ = chunk.method_12004().field_9180;
      if (this.isIslandChunk(chunkX, chunkZ)) {
         this.generateIslandSection(chunk);
      }

      return CompletableFuture.completedFuture(chunk);
   }

   private boolean isIslandChunk(int chunkX, int chunkZ) {
      return chunkX >= -4 && chunkX <= 3 && chunkZ >= -4 && chunkZ <= 3;
   }

   private void generateIslandSection(class_2791 chunk) {
      for(int x = 0; x < 16; ++x) {
         for(int z = 0; z < 16; ++z) {
            for(int layerIdx = 0; layerIdx < this.islandLayers.length; ++layerIdx) {
               class_2338 pos = new class_2338(chunk.method_12004().method_8326() + x, 64 - layerIdx, chunk.method_12004().method_8328() + z);
               chunk.method_12010(pos, this.islandLayers[layerIdx], false);
            }
         }
      }

   }

   public void method_12110(class_3233 region, class_5138 structures, class_7138 noiseConfig, class_2791 chunk) {
   }

   public void method_12108(class_3233 chunkRegion, long seed, class_7138 noiseConfig, class_4543 biomeAccess, class_5138 structureAccessor, class_2791 chunk, class_2893.class_2894 carverStep) {
   }

   public void method_12107(class_3233 region) {
   }

   public int method_16397(int x, int z, class_2902.class_2903 heightmap, class_5539 world, class_7138 noiseConfig) {
      int chunkX = x >> 4;
      int chunkZ = z >> 4;
      return this.isIslandChunk(chunkX, chunkZ) ? 65 : world.method_31607();
   }

   public class_4966 method_26261(int x, int z, class_5539 world, class_7138 noiseConfig) {
      int chunkX = x >> 4;
      int chunkZ = z >> 4;
      int height = world.method_31605();
      int bottomY = world.method_31607();
      class_2680[] states = new class_2680[height];

      for(int i = 0; i < height; ++i) {
         states[i] = class_2246.field_10124.method_9564();
      }

      if (this.isIslandChunk(chunkX, chunkZ)) {
         for(int layerIdx = 0; layerIdx < this.islandLayers.length; ++layerIdx) {
            int y = 64 - layerIdx;
            int stateIndex = y - bottomY;
            if (stateIndex >= 0 && stateIndex < height) {
               states[stateIndex] = this.islandLayers[layerIdx];
            }
         }
      }

      return new class_4966(bottomY, states);
   }

   public int method_12104() {
      return 384;
   }

   public int method_33730() {
      return -64;
   }

   public int method_16398() {
      return 63;
   }

   public void method_40450(List<String> text, class_7138 noiseConfig, class_2338 pos) {
      text.add("VoidIsland Generator");
      int chunkX = pos.method_10263() >> 4;
      int chunkZ = pos.method_10260() >> 4;
      boolean var10001 = this.isIslandChunk(chunkX, chunkZ);
      text.add("Island chunk: " + var10001);
   }
}
