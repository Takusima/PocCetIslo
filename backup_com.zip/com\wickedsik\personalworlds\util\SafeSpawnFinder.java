package com.wickedsik.personalworlds.util;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.WorldCompat;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_2902.class_2903;

public class SafeSpawnFinder {
   private static final int SEARCH_RADIUS = 16;
   private static final int MAX_Y_SEARCH = 32;

   public static class_2338 findSafePosition(class_3218 world, class_2338 target) {
      if (isSafeSpawn(world, target)) {
         return target;
      } else {
         class_2338 vertical = searchVertically(world, target);
         if (vertical != null) {
            return vertical;
         } else {
            class_2338 spiral = searchSpiral(world, target);
            if (spiral != null) {
               return spiral;
            } else {
               class_2338 worldSpawn = findSafeNearSpawn(world);
               if (worldSpawn != null) {
                  PersonalWorldsMod.LOGGER.warn("Using world spawn as fallback for {}", target);
                  return worldSpawn;
               } else {
                  PersonalWorldsMod.LOGGER.error("No safe spawn found near {}, using emergency position", target);
                  return new class_2338(0, 100, 0);
               }
            }
         }
      }
   }

   public static boolean isSafeSpawn(class_3218 world, class_2338 pos) {
      class_2680 ground = world.method_8320(pos.method_10074());
      if (!ground.method_26212(world, pos.method_10074())) {
         return false;
      } else {
         class_2680 feet = world.method_8320(pos);
         class_2680 head = world.method_8320(pos.method_10084());
         if (feet.method_26215() && head.method_26215()) {
            return !ground.method_26227().method_15771();
         } else {
            return false;
         }
      }
   }

   private static class_2338 searchVertically(class_3218 world, class_2338 target) {
      for(int dy = 0; dy <= 32; ++dy) {
         class_2338 check = target.method_10086(dy);
         if (check.method_10264() < WorldCompat.getTopY(world) && isSafeSpawn(world, check)) {
            return check;
         }
      }

      for(int dy = 1; dy <= 32; ++dy) {
         class_2338 check = target.method_10087(dy);
         if (check.method_10264() > world.method_31607() && isSafeSpawn(world, check)) {
            return check;
         }
      }

      return null;
   }

   private static class_2338 searchSpiral(class_3218 world, class_2338 target) {
      for(int radius = 1; radius <= 16; ++radius) {
         for(int dx = -radius; dx <= radius; ++dx) {
            for(int dz = -radius; dz <= radius; ++dz) {
               if (Math.abs(dx) == radius || Math.abs(dz) == radius) {
                  class_2338 horizontal = target.method_10069(dx, 0, dz);
                  int surfaceY = world.method_8624(class_2903.field_13197, horizontal.method_10263(), horizontal.method_10260());
                  class_2338 surface = new class_2338(horizontal.method_10263(), surfaceY, horizontal.method_10260());
                  if (isSafeSpawn(world, surface)) {
                     return surface;
                  }

                  class_2338 vertical = searchVertically(world, horizontal);
                  if (vertical != null) {
                     return vertical;
                  }
               }
            }
         }
      }

      return null;
   }

   private static class_2338 findSafeNearSpawn(class_3218 world) {
      class_2338 spawn = WorldCompat.getSpawnPos(world);
      return isSafeSpawn(world, spawn) ? spawn : searchSpiral(world, spawn);
   }
}
