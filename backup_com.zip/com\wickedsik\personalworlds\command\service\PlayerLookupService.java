package com.wickedsik.personalworlds.command.service;

import com.wickedsik.personalworlds.dimension.DimensionRegistry;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.player.PlayerDataManager;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class PlayerLookupService {
   public Optional<PlayerReference> findByName(MinecraftServer server, String name) {
      class_3222 onlinePlayer = server.method_3760().method_14566(name);
      if (onlinePlayer != null) {
         return Optional.of(new PlayerReference(onlinePlayer.method_5667(), onlinePlayer.method_5477().getString(), true));
      } else {
         DimensionRegistry registry = DimensionRegistry.get(server);

         for(PlayerDimensionData data : registry.getAllDimensions().values()) {
            if (data.ownerName().equalsIgnoreCase(name)) {
               return Optional.of(new PlayerReference(data.ownerUuid(), data.ownerName(), false));
            }
         }

         return Optional.empty();
      }
   }

   public Optional<PlayerReference> findInInvitations(MinecraftServer server, UUID ownerUuid, String name) {
      class_3222 onlinePlayer = server.method_3760().method_14566(name);
      if (onlinePlayer != null) {
         return Optional.of(new PlayerReference(onlinePlayer.method_5667(), onlinePlayer.method_5477().getString(), true));
      } else {
         PlayerDataManager dataManager = PlayerDataManager.get(server);
         Set<UUID> sentInvites = dataManager.getSentInvitations(ownerUuid);
         DimensionRegistry registry = DimensionRegistry.get(server);

         for(UUID uuid : sentInvites) {
            Optional<PlayerDimensionData> data = registry.getDimensionData(uuid);
            if (data.isPresent() && ((PlayerDimensionData)data.get()).ownerName().equalsIgnoreCase(name)) {
               return Optional.of(new PlayerReference(uuid, ((PlayerDimensionData)data.get()).ownerName(), false));
            }
         }

         return Optional.empty();
      }
   }

   public Optional<PlayerDimensionData> findDimensionByOwnerName(MinecraftServer server, String ownerName) {
      DimensionRegistry registry = DimensionRegistry.get(server);

      for(PlayerDimensionData data : registry.getAllDimensions().values()) {
         if (data.ownerName().equalsIgnoreCase(ownerName)) {
            return Optional.of(data);
         }
      }

      return Optional.empty();
   }

   public static record PlayerReference(UUID uuid, String resolvedName, boolean online) {
   }
}
