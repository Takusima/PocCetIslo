package com.wickedsik.personalworlds.util;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.compat.IdentifierCompat;
import com.wickedsik.personalworlds.dimension.PlayerDimensionData;
import com.wickedsik.personalworlds.dimension.WorldGenType;
import com.wickedsik.personalworlds.player.InvitationData;
import com.wickedsik.personalworlds.player.ReturnData;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.server.MinecraftServer;

public final class DataValidator {
   private DataValidator() {
   }

   public static Optional<UUID> validateUuid(String uuidString) {
      if (uuidString != null && !uuidString.isEmpty()) {
         try {
            return Optional.of(UUID.fromString(uuidString));
         } catch (IllegalArgumentException var2) {
            PersonalWorldsMod.LOGGER.warn("Invalid UUID string: {}", uuidString);
            return Optional.empty();
         }
      } else {
         return Optional.empty();
      }
   }

   public static boolean isValidUuid(UUID uuid) {
      return uuid != null;
   }

   public static Optional<class_2960> validateIdentifier(String namespace, String path) {
      if (namespace != null && path != null) {
         try {
            return Optional.of(IdentifierCompat.create(namespace, path));
         } catch (Exception var3) {
            PersonalWorldsMod.LOGGER.warn("Invalid identifier: {}:{}", namespace, path);
            return Optional.empty();
         }
      } else {
         return Optional.empty();
      }
   }

   public static boolean isValidBlockPos(class_2338 pos, MinecraftServer server) {
      if (pos == null) {
         return false;
      } else {
         int maxX = 30000000;
         int minY = -64;
         int maxY = 320;
         return pos.method_10263() >= -maxX && pos.method_10263() <= maxX && pos.method_10264() >= minY && pos.method_10264() <= maxY && pos.method_10260() >= -maxX && pos.method_10260() <= maxX;
      }
   }

   public static class_2338 sanitizeBlockPos(class_2338 pos) {
      if (pos == null) {
         return new class_2338(0, 64, 0);
      } else {
         int x = Math.max(-30000000, Math.min(30000000, pos.method_10263()));
         int y = Math.max(-64, Math.min(320, pos.method_10264()));
         int z = Math.max(-30000000, Math.min(30000000, pos.method_10260()));
         return new class_2338(x, y, z);
      }
   }

   public static boolean isValidDimensionData(PlayerDimensionData data) {
      if (data == null) {
         return false;
      } else if (!isValidUuid(data.ownerUuid())) {
         PersonalWorldsMod.LOGGER.warn("Invalid owner UUID in dimension data");
         return false;
      } else if (data.ownerName() != null && !data.ownerName().isEmpty()) {
         if (data.dimensionId() == null) {
            PersonalWorldsMod.LOGGER.warn("Null dimension ID in dimension data");
            return false;
         } else if (data.spawnPoint() == null) {
            PersonalWorldsMod.LOGGER.warn("Null spawn point in dimension data");
            return false;
         } else if (data.generatorType() == null) {
            PersonalWorldsMod.LOGGER.warn("Null generator type in dimension data");
            return false;
         } else if (data.createdAt() < 0L) {
            PersonalWorldsMod.LOGGER.warn("Invalid creation timestamp in dimension data");
            return false;
         } else {
            return true;
         }
      } else {
         PersonalWorldsMod.LOGGER.warn("Empty owner name in dimension data");
         return false;
      }
   }

   public static PlayerDimensionData sanitizeDimensionData(PlayerDimensionData data, UUID ownerUuid) {
      if (data == null) {
         String var12 = ownerUuid.toString();
         String dimPath = "pw_" + var12.replace("-", "");
         return new PlayerDimensionData(ownerUuid, "Unknown (" + ownerUuid.toString().substring(0, 8) + ")", IdentifierCompat.modId(dimPath), System.currentTimeMillis(), new class_2338(0, 65, 0), WorldGenType.VOID, 0);
      } else {
         UUID uuid = data.ownerUuid() != null ? data.ownerUuid() : ownerUuid;
         String name = data.ownerName() != null && !data.ownerName().isEmpty() ? data.ownerName() : "Unknown";
         class_2960 var10000;
         if (data.dimensionId() != null) {
            var10000 = data.dimensionId();
         } else {
            String var11 = uuid.toString();
            var10000 = IdentifierCompat.modId("pw_" + var11.replace("-", ""));
         }

         class_2960 dimId = var10000;
         long createdAt = data.createdAt() > 0L ? data.createdAt() : System.currentTimeMillis();
         class_2338 spawn = sanitizeBlockPos(data.spawnPoint());
         WorldGenType genType = data.generatorType() != null ? data.generatorType() : WorldGenType.VOID;
         int portalTypeIndex = data.portalTypeIndex();
         return new PlayerDimensionData(uuid, name, dimId, createdAt, spawn, genType, portalTypeIndex);
      }
   }

   public static boolean isValidReturnData(ReturnData data, MinecraftServer server) {
      if (data == null) {
         return false;
      } else if (data.dimension() == null) {
         return false;
      } else if (server.method_3847(data.dimension()) == null) {
         PersonalWorldsMod.LOGGER.debug("Return dimension {} no longer exists", data.dimension().method_29177());
         return false;
      } else {
         return isValidBlockPos(data.position(), server);
      }
   }

   public static boolean isValidInvitationData(InvitationData data) {
      if (data == null) {
         return false;
      } else if (!isValidUuid(data.ownerUuid())) {
         return false;
      } else if (data.ownerName() != null && !data.ownerName().isEmpty()) {
         return data.invitedAt() > 0L;
      } else {
         return false;
      }
   }

   public static String sanitizePlayerName(String name) {
      if (name != null && !name.isEmpty()) {
         String sanitized = name.replaceAll("[^\\p{Print}]", "");
         return sanitized.substring(0, Math.min(sanitized.length(), 32)).trim();
      } else {
         return "Unknown";
      }
   }
}
