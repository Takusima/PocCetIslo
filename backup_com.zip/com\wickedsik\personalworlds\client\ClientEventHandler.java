package com.wickedsik.personalworlds.client;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.client.screen.PocketDimensionScreen;
import com.wickedsik.personalworlds.network.ModNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2540;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Клиентский обработчик событий.
 * Регистрирует клавишу F7 для открытия GUI карманного измерения.
 */
@Environment(EnvType.CLIENT)
public class ClientEventHandler implements ClientModInitializer {

    // Клавиша F7 для открытия GUI
    private static class_304 guiKeyBinding;

    // Флаг для предотвращения повторных срабатываний
    private static boolean wasKeyPressed = false;

    @Override
    public void onInitializeClient() {
        PersonalWorldsMod.LOGGER.info("Initializing client event handler...");

        // Регистрация клавиши F7
        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.personalworlds.open_gui", // Идентификатор клавиши
            class_3675.class_307.field_1668, // Тип ввода - клавиатура
            GLFW.GLFW_KEY_F7, // Код клавиши F7
            "category.personalworlds.general" // Категория
        ));

        // Регистрация обработчика тиков клиента
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        // Регистрация клиентских сетевых обработчиков
        ModNetworking.registerClientReceivers();

        PersonalWorldsMod.LOGGER.info("Client event handler initialized");
    }

    /**
     * Обработка тика клиента.
     * Проверяет нажатие клавиши F7.
     */
    private void onClientTick(class_310 client) {
        if (client.field_9614 == null) { // player == null
            return;
        }

        boolean isKeyPressed = guiKeyBinding.method_1416(); // isPressed()

        // Проверяем нажатие (не удержание)
        if (isKeyPressed && !wasKeyPressed) {
            onGuiKeyPressed(client);
        }

        wasKeyPressed = isKeyPressed;
    }

    /**
     * Обработка нажатия клавиши GUI.
     * Отправляет запрос на сервер и открывает экран.
     */
    private void onGuiKeyPressed(class_310 client) {
        PersonalWorldsMod.LOGGER.info("GUI key pressed - requesting player list from server");

        // Отправляем запрос на сервер для получения списка игроков
        class_2540 buf = ModNetworking.createBuf();
        ModNetworking.sendToServer(ModNetworking.OPEN_GUI, buf);

        // Открываем GUI (список игроков обновится когда придёт ответ от сервера)
        client.method_1507(new PocketDimensionScreen());
    }

    /**
     * Получение привязки клавиши GUI.
     */
    public static class_304 getGuiKeyBinding() {
        return guiKeyBinding;
    }
}
