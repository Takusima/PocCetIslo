package com.wickedsik.personalworlds.command.service;

import com.wickedsik.personalworlds.compat.WorldCompat;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5454;

public final class TeleportHelper {
   private TeleportHelper() {
   }

   public static class_5454 toPosition(class_3218 world, class_243 pos, class_3222 player) {
      return new class_5454(pos, class_243.field_1353, player.method_36454(), player.method_36455());
   }

   public static class_5454 toPosition(class_3218 world, class_243 pos, float yaw, float pitch) {
      return new class_5454(pos, class_243.field_1353, yaw, pitch);
   }

   public static class_5454 toBlockPos(class_3218 world, class_2338 blockPos, class_3222 player) {
      class_243 pos = new class_243((double)blockPos.method_10263() + (double)0.5F, (double)blockPos.method_10264(), (double)blockPos.method_10260() + (double)0.5F);
      return new class_5454(pos, class_243.field_1353, player.method_36454(), player.method_36455());
   }

   public static class_5454 toBlockPos(class_3218 world, class_2338 blockPos, float yaw, float pitch) {
      class_243 pos = new class_243((double)blockPos.method_10263() + (double)0.5F, (double)blockPos.method_10264(), (double)blockPos.method_10260() + (double)0.5F);
      return new class_5454(pos, class_243.field_1353, yaw, pitch);
   }

   public static class_5454 toWorldSpawn(class_3218 world, class_3222 player) {
      class_243 spawnPos = class_243.method_24953(WorldCompat.getSpawnPos(world));
      return new class_5454(spawnPos, class_243.field_1353, player.method_36454(), player.method_36455());
   }

   public static class_5454 toDefaultSpawn(class_3218 world, class_3222 player) {
      class_243 pos = new class_243((double)0.5F, (double)65.0F, (double)0.5F);
      return new class_5454(pos, class_243.field_1353, player.method_36454(), player.method_36455());
   }
}
