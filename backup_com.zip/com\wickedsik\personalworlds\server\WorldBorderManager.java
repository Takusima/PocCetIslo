package com.wickedsik.personalworlds.server;

import com.wickedsik.personalworlds.PersonalWorldsMod;
import com.wickedsik.personalworlds.portal.PortalHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_2960;

/**
 * Менеджер границ мира для карманных измерений.
 *
 * Ограничивает размер карманного измерения до 6 чанков (96x96 блоков).
 * Центр границы находится на координатах (0, 0).
 *
 * Граница устанавливается при загрузке мира и при входе игрока.
 */
public final class WorldBorderManager {

    // Размер границы в блоках (6 чанков = 96 блоков)
    // Радиус 48 блоков от центра (0, 0) = всего 96 блоков
    private static final double BORDER_SIZE = 96.0;
    private static final double BORDER_RADIUS = BORDER_SIZE / 2.0; // 48 блоков

    private WorldBorderManager() {
        // Utility class
    }

    /**
     * Регистрация обработчиков событий.
     */
    public static void register() {
        PersonalWorldsMod.LOGGER.info("Registering World Border Manager...");

        // Установка границы при загрузке мира
        ServerWorldEvents.LOAD.register((server, world) -> {
            if (isPersonalDimension(world)) {
                setupBorder(world);
            }
        });

        PersonalWorldsMod.LOGGER.info("World Border Manager registered");
    }

    /**
     * Установка границы мира для карманного измерения.
     *
     * @param world Мир карманного измерения
     */
    public static void setupBorder(class_3218 world) {
        if (!isPersonalDimension(world)) {
            return;
        }

        PersonalWorldsMod.LOGGER.info("Setting up world border for personal dimension: {}", world.method_27983().method_29177());

        // Получаем или создаём границу мира
        net.minecraft.class_2784 border = world.method_8501(); // getWorldBorder()

        // Устанавливаем центр границы на (0, 0)
        border.method_11952(0.0, 0.0); // setCenter

        // Устанавливаем размер границы (96x96 блоков)
        border.method_11954(BORDER_SIZE); // setSize

        // Устанавливаем предупреждение
        border.method_11956(5.0); // setWarningDistance
        border.method_11957(10); // setWarningTime

        // Устанавливаем урон за границей
        border.method_11955(0.5); // setDamagePerBlock

        PersonalWorldsMod.LOGGER.info("World border set: center=(0, 0), size={}, radius={}", BORDER_SIZE, BORDER_RADIUS);
    }

    /**
     * Проверка, является ли мир карманным измерением.
     *
     * @param world Мир для проверки
     * @return true если это карманное измерение
     */
    private static boolean isPersonalDimension(class_1937 world) {
        if (world instanceof class_3218) {
            return PortalHelper.isInPersonalDimension((class_3218) world);
        }
        return false;
    }

    /**
     * Проверка, находится ли позиция внутри границы.
     *
     * @param x Координата X
     * @param z Координата Z
     * @return true если позиция внутри границы
     */
    public static boolean isInsideBorder(double x, double z) {
        return Math.abs(x) <= BORDER_RADIUS && Math.abs(z) <= BORDER_RADIUS;
    }

    /**
     * Получение размера границы.
     *
     * @return Размер границы в блоках
     */
    public static double getBorderSize() {
        return BORDER_SIZE;
    }

    /**
     * Получение радиуса границы.
     *
     * @return Радиус границы в блоках
     */
    public static double getBorderRadius() {
        return BORDER_RADIUS;
    }

    /**
     * Получение минимальной координаты X.
     *
     * @return Минимальная координата X
     */
    public static double getMinX() {
        return -BORDER_RADIUS;
    }

    /**
     * Получение максимальной координаты X.
     *
     * @return Максимальная координата X
     */
    public static double getMaxX() {
        return BORDER_RADIUS;
    }

    /**
     * Получение минимальной координаты Z.
     *
     * @return Минимальная координата Z
     */
    public static double getMinZ() {
        return -BORDER_RADIUS;
    }

    /**
     * Получение максимальной координаты Z.
     *
     * @return Максимальная координата Z
     */
    public static double getMaxZ() {
        return BORDER_RADIUS;
    }
}
